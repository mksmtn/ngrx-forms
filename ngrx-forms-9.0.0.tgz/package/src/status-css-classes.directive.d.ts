import { AbstractControlState } from './state';
import * as i0 from "@angular/core";
/**
 * Lists the available status class names based on the property
 * they are depending on.
 */
export declare const NGRX_STATUS_CLASS_NAMES: {
    isValid: string;
    isInvalid: string;
    isDirty: string;
    isPristine: string;
    isTouched: string;
    isUntouched: string;
    isSubmitted: string;
    isUnsubmitted: string;
    isValidationPending: string;
};
export declare class NgrxStatusCssClassesDirective {
    private state;
    set ngrxFormControlState(state: AbstractControlState<any>);
    set ngrxFormState(state: AbstractControlState<any>);
    get isValid(): boolean;
    get isInvalid(): boolean;
    get isDirty(): boolean;
    get isPristine(): boolean;
    get isTouched(): boolean;
    get isUntouched(): boolean;
    get isSubmitted(): boolean;
    get isUnsubmitted(): boolean;
    get isValidationPending(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxStatusCssClassesDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxStatusCssClassesDirective, "form[ngrxFormState],[ngrxFormControlState]", never, { "ngrxFormControlState": { "alias": "ngrxFormControlState"; "required": false; }; "ngrxFormState": { "alias": "ngrxFormState"; "required": false; }; }, {}, never, never, false, never>;
}
