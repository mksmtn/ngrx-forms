import { ActionType } from "@ngrx/store";
import { Actions } from "../../actions";
import { FormArrayState } from "../../state";
export declare function setErrorsReducer<TValue>(state: FormArrayState<TValue>, action: ActionType<Actions>): FormArrayState<TValue>;
