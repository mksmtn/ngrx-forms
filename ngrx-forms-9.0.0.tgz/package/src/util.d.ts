export declare function isEmpty(obj: object): boolean;
export interface DeepEqualsOptions {
    treatUndefinedAndMissingKeyAsSame?: boolean;
}
export declare function deepEquals<T>(_1: T, _2: T, options?: DeepEqualsOptions): boolean;
