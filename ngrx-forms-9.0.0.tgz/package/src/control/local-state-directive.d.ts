import { ElementRef, EventEmitter } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { Actions } from "../actions";
import { FormViewAdapter } from "../view-adapter/view-adapter";
import { Document, NgrxFormControlDirective } from "./directive";
import { ActionType } from "@ngrx/store";
import * as i0 from "@angular/core";
export declare class NgrxLocalFormControlDirective<TStateValue, TViewValue = TStateValue> extends NgrxFormControlDirective<TStateValue, TViewValue> {
    ngrxFormsAction: EventEmitter<ActionType<Actions>>;
    constructor(el: ElementRef, dom: Document | null, viewAdapters: FormViewAdapter[], valueAccessors: ControlValueAccessor[]);
    protected dispatchAction(action: ActionType<Actions>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxLocalFormControlDirective<any, any>, [null, { optional: true; }, { optional: true; self: true; }, { optional: true; self: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxLocalFormControlDirective<any, any>, "[ngrxFormControlState][ngrxFormsAction]", never, {}, { "ngrxFormsAction": "ngrxFormsAction"; }, never, never, false, never>;
}
