import { AfterViewInit, ElementRef, OnInit } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { ActionsSubject, ActionType } from "@ngrx/store";
import { Actions } from "../actions";
import { FormControlState, FormControlValueTypes } from "../state";
import { FormViewAdapter } from "../view-adapter/view-adapter";
import { NgrxValueConverter } from "./value-converter";
import * as i0 from "@angular/core";
export interface Document {
    activeElement: any;
}
export declare enum NGRX_UPDATE_ON_TYPE {
    CHANGE = "change",
    BLUR = "blur",
    NEVER = "never"
}
export type NgrxFormControlValueType<TStateValue> = TStateValue extends FormControlValueTypes ? TStateValue : never;
export declare class NgrxFormControlDirective<TStateValue, TViewValue = TStateValue> implements AfterViewInit, OnInit {
    private el;
    private dom;
    private actionsSubject;
    private isInitialized;
    private focusTrackingIsEnabled;
    set ngrxFormControlState(newState: FormControlState<NgrxFormControlValueType<TStateValue>>);
    ngrxUpdateOn: NGRX_UPDATE_ON_TYPE;
    set ngrxEnableFocusTracking(value: boolean);
    ngrxValueConverter: NgrxValueConverter<TViewValue, TStateValue>;
    get focusRegionStartAttr(): "" | null;
    state: FormControlState<NgrxFormControlValueType<TStateValue>>;
    private viewAdapter;
    private viewValue;
    private stateValue;
    constructor(el: ElementRef, dom: Document | null, actionsSubject: ActionsSubject | null, viewAdapters: FormViewAdapter[], valueAccessors: ControlValueAccessor[]);
    updateViewIfControlIdChanged(newState: FormControlState<NgrxFormControlValueType<TStateValue>>, oldState: FormControlState<NgrxFormControlValueType<TStateValue>> | undefined): void;
    updateViewIfValueChanged(newState: FormControlState<NgrxFormControlValueType<TStateValue>>, _: FormControlState<NgrxFormControlValueType<TStateValue>> | undefined): void;
    updateViewIfIsDisabledChanged(newState: FormControlState<NgrxFormControlValueType<TStateValue>>, oldState: FormControlState<NgrxFormControlValueType<TStateValue>> | undefined): void;
    updateViewIfIsFocusedChanged(newState: FormControlState<NgrxFormControlValueType<TStateValue>>, oldState: FormControlState<NgrxFormControlValueType<TStateValue>> | undefined): void;
    protected dispatchAction(action: ActionType<Actions>): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    onFocusChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxFormControlDirective<any, any>, [null, { optional: true; }, { optional: true; }, { optional: true; self: true; }, { optional: true; self: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxFormControlDirective<any, any>, ":not([ngrxFormsAction])[ngrxFormControlState]", never, { "ngrxFormControlState": { "alias": "ngrxFormControlState"; "required": false; }; "ngrxUpdateOn": { "alias": "ngrxUpdateOn"; "required": false; }; "ngrxEnableFocusTracking": { "alias": "ngrxEnableFocusTracking"; "required": false; }; "ngrxValueConverter": { "alias": "ngrxValueConverter"; "required": false; }; }, {}, never, never, false, never>;
}
