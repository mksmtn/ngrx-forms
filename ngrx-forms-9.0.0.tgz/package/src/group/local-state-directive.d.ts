import { EventEmitter } from "@angular/core";
import { Actions } from "../actions";
import { KeyValue } from "../state";
import { NgrxFormDirective } from "./directive";
import { ActionType } from "@ngrx/store";
import * as i0 from "@angular/core";
export declare class NgrxLocalFormDirective<TStateValue extends KeyValue> extends NgrxFormDirective<TStateValue> {
    ngrxFormsAction: EventEmitter<ActionType<Actions>>;
    constructor();
    protected dispatchAction(action: ActionType<Actions>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxLocalFormDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxLocalFormDirective<any>, "form[ngrxFormState][ngrxFormsAction]", never, {}, { "ngrxFormsAction": "ngrxFormsAction"; }, never, never, false, never>;
}
