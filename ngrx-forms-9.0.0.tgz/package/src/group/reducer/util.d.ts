import { ActionType } from "@ngrx/store";
import { Actions } from "../../actions";
import { FormGroupControls, FormGroupState, KeyValue } from "../../state";
export declare function dispatchActionPerChild<TValue extends KeyValue>(controls: FormGroupControls<TValue>, actionCreator: (controlId: string) => ActionType<Actions>): FormGroupControls<TValue>;
export declare function childReducer<TValue extends KeyValue>(state: FormGroupState<TValue>, action: ActionType<Actions>): FormGroupState<TValue>;
