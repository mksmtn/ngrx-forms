import { ActionType } from "@ngrx/store";
import { Actions } from "../../actions";
import { FormGroupState, KeyValue } from "../../state";
export declare function clearAsyncErrorReducer<TValue extends KeyValue>(state: FormGroupState<TValue>, action: ActionType<Actions>): FormGroupState<TValue>;
