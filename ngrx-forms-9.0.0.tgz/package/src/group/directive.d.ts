import { OnInit } from "@angular/core";
import { ActionType, ActionsSubject } from "@ngrx/store";
import { Actions } from "../actions";
import { FormGroupState, KeyValue } from "../state";
import * as i0 from "@angular/core";
interface CustomEvent extends Event {
}
export declare class NgrxFormDirective<TStateValue extends KeyValue> implements OnInit {
    private actionsSubject;
    state: FormGroupState<TStateValue>;
    constructor(actionsSubject: ActionsSubject | null);
    protected dispatchAction(action: ActionType<Actions>): void;
    ngOnInit(): void;
    onSubmit(event: CustomEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxFormDirective<any>, [{ optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxFormDirective<any>, "form:not([ngrxFormsAction])[ngrxFormState]", never, { "state": { "alias": "ngrxFormState"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
