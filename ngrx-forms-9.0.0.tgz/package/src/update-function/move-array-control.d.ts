import { FormArrayState } from "../state";
/**
 * This update function takes a source index, a destination index, and returns a projection function
 * that moves the child control at the source index to the destination index from a form array state.
 */
export declare function moveArrayControl(fromIndex: number, toIndex: number): <TValue>(state: FormArrayState<TValue>) => FormArrayState<TValue>;
/**
 * This update function takes a form array state, a source index, a destination index and moves the
 * child control at the source index to the destination index in the form array state.
 */
export declare function moveArrayControl<TValue>(state: FormArrayState<TValue>, fromIndex: number, toIndex: number): FormArrayState<TValue>;
