import { FormArrayState } from "../state";
/**
 * This update function takes two indices and returns a projection function that swaps the
 * child controls at those indices in a form array state.
 */
export declare function swapArrayControl(fromIndex: number, toIndex: number): <TValue>(state: FormArrayState<TValue>) => FormArrayState<TValue>;
/**
 * This update function takes a form array state and two indices and swaps the
 * child controls at those indices in the state.
 */
export declare function swapArrayControl<TValue>(state: FormArrayState<TValue>, fromIndex: number, toIndex: number): FormArrayState<TValue>;
