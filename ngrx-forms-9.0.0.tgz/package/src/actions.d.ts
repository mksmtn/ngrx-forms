import { Action } from "@ngrx/store";
import { KeyValue, NgrxFormControlId, ValidationErrors } from "./state";
export declare const setValueAction: import("@ngrx/store").ActionCreator<"ngrx/forms/SET_VALUE", (props: {
    controlId: NgrxFormControlId;
    value: unknown;
}) => {
    controlId: NgrxFormControlId;
    value: unknown;
} & Action<"ngrx/forms/SET_VALUE">>;
export declare const setErrorsAction: import("@ngrx/store").ActionCreator<"ngrx/forms/SET_ERRORS", (props: {
    controlId: NgrxFormControlId;
    errors: ValidationErrors;
}) => {
    controlId: NgrxFormControlId;
    errors: ValidationErrors;
} & Action<"ngrx/forms/SET_ERRORS">>;
export declare const setAsyncErrorAction: import("@ngrx/store").ActionCreator<"ngrx/forms/SET_ASYNC_ERROR", (props: {
    controlId: NgrxFormControlId;
    name: string;
    value: unknown;
}) => {
    controlId: NgrxFormControlId;
    name: string;
    value: unknown;
} & Action<"ngrx/forms/SET_ASYNC_ERROR">>;
export declare const clearAsyncErrorAction: import("@ngrx/store").ActionCreator<"ngrx/forms/CLEAR_ASYNC_ERROR", (props: {
    controlId: NgrxFormControlId;
    name: string;
}) => {
    controlId: NgrxFormControlId;
    name: string;
} & Action<"ngrx/forms/CLEAR_ASYNC_ERROR">>;
export declare const startAsyncValidationAction: import("@ngrx/store").ActionCreator<"ngrx/forms/START_ASYNC_VALIDATION", (props: {
    controlId: NgrxFormControlId;
    name: string;
}) => {
    controlId: NgrxFormControlId;
    name: string;
} & Action<"ngrx/forms/START_ASYNC_VALIDATION">>;
export declare const markAsDirtyAction: import("@ngrx/store").ActionCreator<"ngrx/forms/MARK_AS_DIRTY", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/MARK_AS_DIRTY">>;
export declare const markAsPristineAction: import("@ngrx/store").ActionCreator<"ngrx/forms/MARK_AS_PRISTINE", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/MARK_AS_PRISTINE">>;
export declare const enableAction: import("@ngrx/store").ActionCreator<"ngrx/forms/ENABLE", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/ENABLE">>;
export declare const disableAction: import("@ngrx/store").ActionCreator<"ngrx/forms/DISABLE", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/DISABLE">>;
export declare const markAsTouchedAction: import("@ngrx/store").ActionCreator<"ngrx/forms/MARK_AS_TOUCHED", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/MARK_AS_TOUCHED">>;
export declare const markAsUntouchedAction: import("@ngrx/store").ActionCreator<"ngrx/forms/MARK_AS_UNTOUCHED", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/MARK_AS_UNTOUCHED">>;
export declare const focusAction: import("@ngrx/store").ActionCreator<"ngrx/forms/FOCUS", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/FOCUS">>;
export declare const unfocusAction: import("@ngrx/store").ActionCreator<"ngrx/forms/UNFOCUS", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/UNFOCUS">>;
export declare const markAsSubmittedAction: import("@ngrx/store").ActionCreator<"ngrx/forms/MARK_AS_SUBMITTED", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/MARK_AS_SUBMITTED">>;
export declare const markAsUnsubmittedAction: import("@ngrx/store").ActionCreator<"ngrx/forms/MARK_AS_UNSUBMITTED", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/MARK_AS_UNSUBMITTED">>;
export declare const addArrayControlAction: import("@ngrx/store").ActionCreator<"ngrx/forms/ADD_ARRAY_CONTROL", (props: {
    controlId: NgrxFormControlId;
    value: unknown;
    index?: number | undefined;
}) => {
    controlId: NgrxFormControlId;
    value: unknown;
    index?: number | undefined;
} & Action<"ngrx/forms/ADD_ARRAY_CONTROL">>;
export declare const addGroupControlAction: import("@ngrx/store").ActionCreator<"ngrx/forms/ADD_GROUP_CONTROL", (props: {
    controlId: NgrxFormControlId;
    name: keyof KeyValue;
    value: unknown;
}) => {
    controlId: NgrxFormControlId;
    name: keyof KeyValue;
    value: unknown;
} & Action<"ngrx/forms/ADD_GROUP_CONTROL">>;
export declare const removeArrayControlAction: import("@ngrx/store").ActionCreator<"ngrx/forms/REMOVE_ARRAY_CONTROL", (props: {
    controlId: NgrxFormControlId;
    index: number;
}) => {
    controlId: NgrxFormControlId;
    index: number;
} & Action<"ngrx/forms/REMOVE_ARRAY_CONTROL">>;
export declare const swapArrayControlAction: import("@ngrx/store").ActionCreator<"ngrx/forms/SWAP_ARRAY_CONTROL", (props: {
    controlId: NgrxFormControlId;
    fromIndex: number;
    toIndex: number;
}) => {
    controlId: NgrxFormControlId;
    fromIndex: number;
    toIndex: number;
} & Action<"ngrx/forms/SWAP_ARRAY_CONTROL">>;
export declare const moveArrayControlAction: import("@ngrx/store").ActionCreator<"ngrx/forms/MOVE_ARRAY_CONTROL", (props: {
    controlId: NgrxFormControlId;
    fromIndex: number;
    toIndex: number;
}) => {
    controlId: NgrxFormControlId;
    fromIndex: number;
    toIndex: number;
} & Action<"ngrx/forms/MOVE_ARRAY_CONTROL">>;
export declare const removeGroupControlAction: import("@ngrx/store").ActionCreator<"ngrx/forms/REMOVE_CONTROL", (props: {
    controlId: NgrxFormControlId;
    name: keyof KeyValue;
}) => {
    controlId: NgrxFormControlId;
    name: keyof KeyValue;
} & Action<"ngrx/forms/REMOVE_CONTROL">>;
export declare const setUserDefinedPropertyAction: import("@ngrx/store").ActionCreator<"ngrx/forms/SET_USER_DEFINED_PROPERTY", (props: {
    controlId: NgrxFormControlId;
    name: string;
    value: unknown;
}) => {
    controlId: NgrxFormControlId;
    name: string;
    value: unknown;
} & Action<"ngrx/forms/SET_USER_DEFINED_PROPERTY">>;
export declare const resetAction: import("@ngrx/store").ActionCreator<"ngrx/forms/RESET", (props: {
    controlId: NgrxFormControlId;
}) => {
    controlId: NgrxFormControlId;
} & Action<"ngrx/forms/RESET">>;
export type Actions = typeof setValueAction | typeof setErrorsAction | typeof setAsyncErrorAction | typeof clearAsyncErrorAction | typeof startAsyncValidationAction | typeof markAsDirtyAction | typeof markAsPristineAction | typeof enableAction | typeof disableAction | typeof markAsTouchedAction | typeof markAsUntouchedAction | typeof focusAction | typeof unfocusAction | typeof markAsSubmittedAction | typeof markAsUnsubmittedAction | typeof addGroupControlAction | typeof removeGroupControlAction | typeof addArrayControlAction | typeof removeArrayControlAction | typeof setUserDefinedPropertyAction | typeof resetAction | typeof swapArrayControlAction | typeof moveArrayControlAction;
export declare function isNgrxFormsAction(action: Action): boolean;
export declare const ALL_NGRX_FORMS_ACTION_TYPES: Actions["type"][];
