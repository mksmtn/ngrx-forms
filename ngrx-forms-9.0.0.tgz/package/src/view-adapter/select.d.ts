import { AfterViewInit, ElementRef, OnDestroy, Renderer2 } from '@angular/core';
import { FormControlState } from '../state';
import { FormViewAdapter } from './view-adapter';
import * as i0 from "@angular/core";
export declare class NgrxSelectViewAdapter implements FormViewAdapter, AfterViewInit {
    private renderer;
    private elementRef;
    private state;
    private optionMap;
    private idCounter;
    private selectedId;
    private value;
    private nativeIdWasSet;
    onChangeFn: (value: any) => void;
    onTouched: () => void;
    set ngrxFormControlState(value: FormControlState<any>);
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngAfterViewInit(): void;
    setViewValue(value: any): void;
    onChange({ target }: {
        target: HTMLOptionElement;
    }): void;
    setOnChangeCallback(fn: (value: any) => void): void;
    setOnTouchedCallback(fn: () => void): void;
    setIsDisabled(isDisabled: boolean): void;
    createOptionId(): string;
    updateOptionValue(id: string, value: any): void;
    deregisterOption(id: string): void;
    private getOptionId;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxSelectViewAdapter, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxSelectViewAdapter, "select:not([multiple])[ngrxFormControlState]", never, { "ngrxFormControlState": { "alias": "ngrxFormControlState"; "required": false; }; }, {}, never, never, false, never>;
}
export declare class NgrxSelectOption implements OnDestroy {
    private element;
    private renderer;
    private viewAdapter;
    private isInitialized;
    id: string;
    constructor(element: ElementRef, renderer: Renderer2, viewAdapter: NgrxSelectViewAdapter);
    set value(value: any);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxSelectOption, [null, null, { optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxSelectOption, "option", never, { "value": { "alias": "value"; "required": false; }; }, {}, never, never, false, never>;
}
