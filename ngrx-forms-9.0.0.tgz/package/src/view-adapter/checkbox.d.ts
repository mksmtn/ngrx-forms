import { AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
import { FormControlState } from '../state';
import { FormViewAdapter } from './view-adapter';
import * as i0 from "@angular/core";
export declare class NgrxCheckboxViewAdapter implements FormViewAdapter, AfterViewInit {
    private renderer;
    private elementRef;
    private state;
    private nativeIdWasSet;
    onChange: (value: any) => void;
    onTouched: () => void;
    set ngrxFormControlState(value: FormControlState<any>);
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngAfterViewInit(): void;
    setViewValue(value: any): void;
    setOnChangeCallback(fn: (value: any) => void): void;
    setOnTouchedCallback(fn: () => void): void;
    setIsDisabled(isDisabled: boolean): void;
    handleInput({ target }: {
        target: HTMLInputElement;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxCheckboxViewAdapter, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxCheckboxViewAdapter, "input[type=checkbox][ngrxFormControlState]", never, { "ngrxFormControlState": { "alias": "ngrxFormControlState"; "required": false; }; }, {}, never, never, false, never>;
}
