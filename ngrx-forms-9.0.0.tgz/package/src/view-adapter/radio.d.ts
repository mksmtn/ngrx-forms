import { AfterViewInit, ElementRef, OnInit, Renderer2 } from '@angular/core';
import { FormControlState } from '../state';
import { FormViewAdapter } from './view-adapter';
import * as i0 from "@angular/core";
export declare class NgrxRadioViewAdapter implements FormViewAdapter, OnInit, AfterViewInit {
    private renderer;
    private elementRef;
    private state;
    private nativeNameWasSet;
    set value(val: any);
    set ngrxFormControlState(value: FormControlState<any>);
    private latestValue;
    private isChecked;
    onChange: () => void;
    onTouched: () => void;
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    setViewValue(value: any): void;
    setOnChangeCallback(fn: (_: any) => void): void;
    setOnTouchedCallback(fn: () => void): void;
    setIsDisabled(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxRadioViewAdapter, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxRadioViewAdapter, "input[type=radio][ngrxFormControlState]", never, { "value": { "alias": "value"; "required": false; }; "ngrxFormControlState": { "alias": "ngrxFormControlState"; "required": false; }; }, {}, never, never, false, never>;
}
