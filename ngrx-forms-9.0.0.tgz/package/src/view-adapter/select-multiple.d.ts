import { AfterViewInit, ElementRef, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { FormControlState } from '../state';
import { FormViewAdapter } from './view-adapter';
import * as i0 from "@angular/core";
export declare class NgrxSelectMultipleViewAdapter implements FormViewAdapter, AfterViewInit {
    private renderer;
    private elementRef;
    private state;
    private options;
    private optionValues;
    private idCounter;
    private selectedIds;
    private nativeIdWasSet;
    onChangeFn: (value: any) => void;
    onTouched: () => void;
    set ngrxFormControlState(value: FormControlState<any>);
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngAfterViewInit(): void;
    setViewValue(value: any): void;
    onChange(): void;
    setOnChangeCallback(fn: (value: any) => void): void;
    setOnTouchedCallback(fn: () => void): void;
    setIsDisabled(isDisabled: boolean): void;
    registerOption(option: NgrxSelectMultipleOption): string;
    updateOptionValue(id: string, value: any): void;
    deregisterOption(id: string): void;
    private getOptionId;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxSelectMultipleViewAdapter, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxSelectMultipleViewAdapter, "select[multiple][ngrxFormControlState]", never, { "ngrxFormControlState": { "alias": "ngrxFormControlState"; "required": false; }; }, {}, never, never, false, never>;
}
export declare class NgrxSelectMultipleOption implements OnInit, OnDestroy {
    private element;
    private renderer;
    private viewAdapter;
    id: string;
    constructor(element: ElementRef, renderer: Renderer2, viewAdapter: NgrxSelectMultipleViewAdapter);
    set value(value: any);
    set isSelected(selected: boolean);
    get isSelected(): boolean;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxSelectMultipleOption, [null, null, { optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxSelectMultipleOption, "option", never, { "value": { "alias": "value"; "required": false; }; }, {}, never, never, false, never>;
}
