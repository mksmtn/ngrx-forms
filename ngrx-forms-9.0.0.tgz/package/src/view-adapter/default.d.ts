import { AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
import { FormControlState } from '../state';
import { FormViewAdapter } from './view-adapter';
import * as i0 from "@angular/core";
export interface Navigator {
    userAgent: string;
}
export declare class NgrxDefaultViewAdapter implements FormViewAdapter, AfterViewInit {
    private renderer;
    private elementRef;
    private platformId;
    private state;
    private nativeIdWasSet;
    onChange: (value: any) => void;
    onTouched: () => void;
    set ngrxFormControlState(value: FormControlState<any>);
    /** Whether the user is creating a composition string (IME events). */
    private isComposing;
    private isCompositionSupported;
    constructor(renderer: Renderer2, elementRef: ElementRef, platformId?: string | null, navigator?: Navigator | null);
    ngAfterViewInit(): void;
    setViewValue(value: any): void;
    setOnChangeCallback(fn: (value: any) => void): void;
    setOnTouchedCallback(fn: () => void): void;
    setIsDisabled(isDisabled: boolean): void;
    handleInput({ target }: {
        target: HTMLInputElement;
    }): void;
    compositionStart(): void;
    compositionEnd({ target }: {
        target: HTMLInputElement;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxDefaultViewAdapter, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgrxDefaultViewAdapter, "input:not([type=checkbox]):not([type=number]):not([type=radio]):not([type=range])[ngrxFormControlState],textarea[ngrxFormControlState]", never, { "ngrxFormControlState": { "alias": "ngrxFormControlState"; "required": false; }; }, {}, never, never, false, never>;
}
