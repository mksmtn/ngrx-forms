import * as i0 from "@angular/core";
import * as i1 from "./control/directive";
import * as i2 from "./control/local-state-directive";
import * as i3 from "./group/directive";
import * as i4 from "./group/local-state-directive";
import * as i5 from "./view-adapter/checkbox";
import * as i6 from "./view-adapter/default";
import * as i7 from "./view-adapter/number";
import * as i8 from "./view-adapter/radio";
import * as i9 from "./view-adapter/range";
import * as i10 from "./view-adapter/select-multiple";
import * as i11 from "./view-adapter/select";
import * as i12 from "./view-adapter/option";
import * as i13 from "./status-css-classes.directive";
export declare class NgrxFormsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgrxFormsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgrxFormsModule, [typeof i1.NgrxFormControlDirective, typeof i2.NgrxLocalFormControlDirective, typeof i3.NgrxFormDirective, typeof i4.NgrxLocalFormDirective, typeof i5.NgrxCheckboxViewAdapter, typeof i6.NgrxDefaultViewAdapter, typeof i7.NgrxNumberViewAdapter, typeof i8.NgrxRadioViewAdapter, typeof i9.NgrxRangeViewAdapter, typeof i10.NgrxSelectMultipleOption, typeof i10.NgrxSelectMultipleViewAdapter, typeof i11.NgrxSelectOption, typeof i11.NgrxSelectViewAdapter, typeof i12.NgrxFallbackSelectOption, typeof i13.NgrxStatusCssClassesDirective], never, [typeof i1.NgrxFormControlDirective, typeof i2.NgrxLocalFormControlDirective, typeof i3.NgrxFormDirective, typeof i4.NgrxLocalFormDirective, typeof i5.NgrxCheckboxViewAdapter, typeof i6.NgrxDefaultViewAdapter, typeof i7.NgrxNumberViewAdapter, typeof i8.NgrxRadioViewAdapter, typeof i9.NgrxRangeViewAdapter, typeof i10.NgrxSelectMultipleOption, typeof i10.NgrxSelectMultipleViewAdapter, typeof i11.NgrxSelectOption, typeof i11.NgrxSelectViewAdapter, typeof i12.NgrxFallbackSelectOption, typeof i13.NgrxStatusCssClassesDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgrxFormsModule>;
}
