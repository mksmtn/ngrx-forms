import * as i1 from '@ngrx/store';
import { createAction, props, ActionsSubject } from '@ngrx/store';
import * as i0 from '@angular/core';
import { InjectionToken, forwardRef, Directive, HostListener, Input, PLATFORM_ID, Optional, Inject, Host, Self, HostBinding, EventEmitter, Output, NgModule } from '@angular/core';
import { isPlatformBrowser, DOCUMENT } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const setValueAction = createAction("ngrx/forms/SET_VALUE", props());
const setErrorsAction = createAction("ngrx/forms/SET_ERRORS", props());
const setAsyncErrorAction = createAction("ngrx/forms/SET_ASYNC_ERROR", props());
const clearAsyncErrorAction = createAction("ngrx/forms/CLEAR_ASYNC_ERROR", props());
const startAsyncValidationAction = createAction("ngrx/forms/START_ASYNC_VALIDATION", props());
const markAsDirtyAction = createAction("ngrx/forms/MARK_AS_DIRTY", props());
const markAsPristineAction = createAction("ngrx/forms/MARK_AS_PRISTINE", props());
const enableAction = createAction("ngrx/forms/ENABLE", props());
const disableAction = createAction("ngrx/forms/DISABLE", props());
const markAsTouchedAction = createAction("ngrx/forms/MARK_AS_TOUCHED", props());
const markAsUntouchedAction = createAction("ngrx/forms/MARK_AS_UNTOUCHED", props());
const focusAction = createAction("ngrx/forms/FOCUS", props());
const unfocusAction = createAction("ngrx/forms/UNFOCUS", props());
const markAsSubmittedAction = createAction("ngrx/forms/MARK_AS_SUBMITTED", props());
const markAsUnsubmittedAction = createAction("ngrx/forms/MARK_AS_UNSUBMITTED", props());
const addArrayControlAction = createAction("ngrx/forms/ADD_ARRAY_CONTROL", props());
const addGroupControlAction = createAction("ngrx/forms/ADD_GROUP_CONTROL", props());
const removeArrayControlAction = createAction("ngrx/forms/REMOVE_ARRAY_CONTROL", props());
const swapArrayControlAction = createAction("ngrx/forms/SWAP_ARRAY_CONTROL", props());
const moveArrayControlAction = createAction("ngrx/forms/MOVE_ARRAY_CONTROL", props());
const removeGroupControlAction = createAction("ngrx/forms/REMOVE_CONTROL", props());
const setUserDefinedPropertyAction = createAction("ngrx/forms/SET_USER_DEFINED_PROPERTY", props());
const resetAction = createAction("ngrx/forms/RESET", props());
function isNgrxFormsAction(action) {
    return !!action.type && action.type.startsWith("ngrx/forms/");
}
const ALL_NGRX_FORMS_ACTION_TYPES = [
    setValueAction.type,
    setErrorsAction.type,
    setAsyncErrorAction.type,
    clearAsyncErrorAction.type,
    startAsyncValidationAction.type,
    markAsDirtyAction.type,
    markAsPristineAction.type,
    enableAction.type,
    disableAction.type,
    markAsTouchedAction.type,
    markAsUntouchedAction.type,
    focusAction.type,
    unfocusAction.type,
    markAsSubmittedAction.type,
    markAsUnsubmittedAction.type,
    addGroupControlAction.type,
    removeGroupControlAction.type,
    addArrayControlAction.type,
    removeArrayControlAction.type,
    setUserDefinedPropertyAction.type,
    resetAction.type,
    swapArrayControlAction.type,
    moveArrayControlAction.type,
];

function isBoxed(value) {
    return !!value && value.__boxed === '';
}
function box(value) {
    return {
        __boxed: '',
        value,
    };
}
function unbox(value) {
    if (['string', 'boolean', 'number', 'undefined'].indexOf(typeof value) >= 0 || value === null || value === undefined) {
        return value;
    }
    if (isBoxed(value)) {
        return value.value;
    }
    if (Array.isArray(value)) {
        return value.map(unbox);
    }
    return Object.keys(value).reduce((a, k) => Object.assign(a, { [k]: unbox(value[k]) }), {});
}

function isEmpty(obj) {
    return Object.keys(obj).length === 0;
}
const defaultOptions = {
    treatUndefinedAndMissingKeyAsSame: false,
};
function deepEquals(_1, _2, options = {}) {
    const { treatUndefinedAndMissingKeyAsSame } = Object.assign({}, defaultOptions, options);
    const leftChain = [];
    const rightChain = [];
    function compare2Objects(x, y) {
        let p;
        // remember that NaN === NaN returns false
        // and isNaN(undefined) returns true
        if (isNaN(x) && isNaN(y) && typeof x === 'number' && typeof y === 'number') {
            return true;
        }
        // Compare primitives and functions.
        // Check if both arguments link to the same object.
        // Especially useful on the step where we compare prototypes
        if (x === y) {
            return true;
        }
        // Works in case when functions are created in constructor.
        // Comparing dates is a common scenario. Another built-ins?
        // We can even handle functions passed across iframes
        if ((typeof x === 'function' && typeof y === 'function') ||
            (x instanceof Date && y instanceof Date) ||
            (x instanceof RegExp && y instanceof RegExp) ||
            (x instanceof String && y instanceof String) ||
            (x instanceof Number && y instanceof Number)) {
            return x.toString() === y.toString();
        }
        // At last checking prototypes as good as we can
        if (!(x instanceof Object && y instanceof Object)) {
            return false;
        }
        if (x.isPrototypeOf(y) || y.isPrototypeOf(x)) {
            return false;
        }
        if (x.constructor !== y.constructor) {
            return false;
        }
        // Check for infinitive linking loops
        if (leftChain.indexOf(x) > -1 || rightChain.indexOf(y) > -1) {
            return false;
        }
        // Quick checking of one object being a subset of another.
        for (p in y) {
            if (treatUndefinedAndMissingKeyAsSame && y.hasOwnProperty(p) && !x.hasOwnProperty(p) && y[p] === undefined) {
                continue;
            }
            if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
                return false;
            }
            else if (typeof y[p] !== typeof x[p]) {
                return false;
            }
        }
        // tslint:disable:forin
        for (p in x) {
            if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
                if (!treatUndefinedAndMissingKeyAsSame || !x.hasOwnProperty(p) || y.hasOwnProperty(p) || x[p] !== undefined) {
                    return false;
                }
            }
            switch (typeof (x[p])) {
                case 'object':
                case 'function':
                    leftChain.push(x);
                    rightChain.push(y);
                    if (!compare2Objects(x[p], y[p])) {
                        return false;
                    }
                    leftChain.pop();
                    rightChain.pop();
                    break;
                default:
                    if (x[p] !== y[p]) {
                        return false;
                    }
                    break;
            }
        }
        return true;
    }
    if (arguments.length <= 1) {
        throw new Error('Need two or more arguments to compare');
    }
    return compare2Objects(_1, _2);
}

/**
 * This function determines if a value is a form state.
 */
function isFormState(state) {
    return (!!state &&
        state.hasOwnProperty("id") &&
        state.hasOwnProperty("value") &&
        state.hasOwnProperty("errors"));
}
/**
 * This function determines if a value is an array state.
 */
function isArrayState(state) {
    return (isFormState(state) &&
        state.hasOwnProperty("controls") &&
        Array.isArray(state.controls));
}
/**
 * This function determines if a value is a group state.
 */
function isGroupState(state) {
    return (isFormState(state) &&
        state.hasOwnProperty("controls") &&
        !Array.isArray(state.controls) &&
        typeof state.controls !== "function");
}
function createChildState(id, childValue) {
    if (isBoxed(childValue)) {
        return createFormControlState(id, childValue);
    }
    if (childValue !== null && Array.isArray(childValue)) {
        return createFormArrayState(id, childValue);
    }
    if (childValue !== null && typeof childValue === "object") {
        return createFormGroupState(id, childValue);
    }
    return createFormControlState(id, childValue);
}
function verifyFormControlValueIsValid(value) {
    if (value === null ||
        ["string", "number", "boolean", "undefined"].indexOf(typeof value) >= 0) {
        return value;
    }
    if (!isBoxed(value)) {
        const errorMsg = "Form control states only support undefined, null, string, number, and boolean values as well as boxed values";
        throw new Error(`${errorMsg}; got ${JSON.stringify(value)} of type ${typeof value}`); // `;
    }
    if (value.value === null ||
        ["string", "number", "boolean", "undefined"].indexOf(typeof value.value) >=
            0) {
        return value;
    }
    const serialized = JSON.stringify(value);
    const deserialized = JSON.parse(serialized);
    if (deepEquals(value, deserialized, { treatUndefinedAndMissingKeyAsSame: true })) {
        return value;
    }
    throw new Error(`A form control value must be serializable (i.e. value === JSON.parse(JSON.stringify(value))), got: ${JSON.stringify(value)}`);
}
/**
 * This function creates a form control state with an ID and a value.
 */
function createFormControlState(id, value) {
    return {
        id,
        value: verifyFormControlValueIsValid(value),
        errors: {},
        pendingValidations: [],
        isValidationPending: false,
        isValid: true,
        isInvalid: false,
        isEnabled: true,
        isDisabled: false,
        isDirty: false,
        isPristine: true,
        isTouched: false,
        isUntouched: true,
        isSubmitted: false,
        isUnsubmitted: true,
        isFocused: false,
        isUnfocused: true,
        userDefinedProperties: {},
    };
}
function getFormGroupValue(controls, originalValue) {
    let hasChanged = Object.keys(originalValue).length !== Object.keys(controls).length;
    const newValue = Object.keys(controls).reduce((res, key) => {
        const control = controls[key];
        hasChanged = hasChanged || originalValue[key] !== control.value;
        res[key] = control.value;
        return res;
    }, {});
    return hasChanged ? newValue : originalValue;
}
function getFormGroupErrors(controls, originalErrors) {
    let hasChanged = false;
    const groupErrors = Object.keys(originalErrors)
        .filter((key) => !key.startsWith("_"))
        .reduce((res, key) => Object.assign(res, { [key]: originalErrors[key] }), {});
    const newErrors = Object.keys(controls).reduce((res, key) => {
        const control = controls[key];
        const controlErrors = control.errors;
        if (!isEmpty(controlErrors)) {
            hasChanged = hasChanged || originalErrors[`_${key}`] !== controlErrors;
            Object.assign(res, { [`_${key}`]: control.errors });
        }
        else {
            hasChanged = hasChanged || originalErrors.hasOwnProperty(`_${key}`);
        }
        return res;
    }, groupErrors);
    hasChanged =
        hasChanged ||
            Object.keys(originalErrors).length !== Object.keys(newErrors).length;
    return hasChanged ? newErrors : originalErrors;
}
function computeGroupState(id, controls, value, errors, pendingValidations, userDefinedProperties, flags) {
    value = getFormGroupValue(controls, value);
    errors = getFormGroupErrors(controls, errors);
    const isValid = isEmpty(errors);
    const typedControls = Object.keys(controls).map((key) => controls[key]);
    const isDirty = flags.wasOrShouldBeDirty ||
        typedControls.some((control) => control.isDirty);
    const isEnabled = flags.wasOrShouldBeEnabled ||
        typedControls.some((control) => control.isEnabled);
    const isTouched = flags.wasOrShouldBeTouched ||
        typedControls.some((control) => control.isTouched);
    const isSubmitted = flags.wasOrShouldBeSubmitted ||
        typedControls.some((control) => control.isSubmitted);
    const isValidationPending = pendingValidations.length > 0 ||
        typedControls.some((control) => control.isValidationPending);
    return {
        id,
        value,
        errors,
        pendingValidations,
        isValidationPending,
        isValid,
        isInvalid: !isValid,
        isEnabled,
        isDisabled: !isEnabled,
        isDirty,
        isPristine: !isDirty,
        isTouched,
        isUntouched: !isTouched,
        isSubmitted,
        isUnsubmitted: !isSubmitted,
        userDefinedProperties,
        controls,
    };
}
/**
 * This function creates a form group state with an ID and a value.
 * From the value the shape of the group state is inferred, i.e.
 * object properties are inferred as form groups, array properties
 * are inferred as form arrays, and primitive properties are inferred
 * as form controls.
 */
function createFormGroupState(id, initialValue) {
    const controls = Object.keys(initialValue)
        .map((key) => [
        key,
        createChildState(`${id}.${key}`, initialValue[key]),
    ])
        .reduce((res, [controlId, state]) => Object.assign(res, { [controlId]: state }), {});
    return computeGroupState(id, controls, initialValue, {}, [], {}, { wasOrShouldBeEnabled: true });
}
function getFormArrayValue(controls, originalValue) {
    let hasChanged = Object.keys(originalValue).length !== Object.keys(controls).length;
    const newValue = controls.map((state, i) => {
        hasChanged = hasChanged || originalValue[i] !== state.value;
        return state.value;
    });
    return hasChanged ? newValue : originalValue;
}
function getFormArrayErrors(controls, originalErrors) {
    let hasChanged = false;
    const groupErrors = Object.keys(originalErrors)
        .filter((key) => !key.startsWith("_"))
        .reduce((res, key) => Object.assign(res, { [key]: originalErrors[key] }), {});
    const newErrors = controls.reduce((res, state, i) => {
        const controlErrors = state.errors;
        if (!isEmpty(controlErrors)) {
            hasChanged = hasChanged || originalErrors[`_${i}`] !== controlErrors;
            Object.assign(res, { [`_${i}`]: controlErrors });
        }
        else {
            hasChanged = hasChanged || originalErrors.hasOwnProperty(`_${i}`);
        }
        return res;
    }, groupErrors);
    hasChanged =
        hasChanged ||
            Object.keys(originalErrors).length !== Object.keys(newErrors).length;
    return hasChanged ? newErrors : originalErrors;
}
function computeArrayState(id, inferredControls, value, errors, pendingValidations, userDefinedProperties, flags) {
    const controls = inferredControls;
    value = getFormArrayValue(controls, value);
    errors = getFormArrayErrors(controls, errors);
    const isValid = isEmpty(errors);
    const isDirty = flags.wasOrShouldBeDirty || controls.some((state) => state.isDirty);
    const isEnabled = flags.wasOrShouldBeEnabled || controls.some((state) => state.isEnabled);
    const isTouched = flags.wasOrShouldBeTouched || controls.some((state) => state.isTouched);
    const isSubmitted = flags.wasOrShouldBeSubmitted || controls.some((state) => state.isSubmitted);
    const isValidationPending = pendingValidations.length > 0 ||
        controls.some((state) => state.isValidationPending);
    return {
        id,
        value,
        errors,
        pendingValidations,
        isValidationPending,
        isValid,
        isInvalid: !isValid,
        isEnabled,
        isDisabled: !isEnabled,
        isDirty,
        isPristine: !isDirty,
        isTouched,
        isUntouched: !isTouched,
        isSubmitted,
        isUnsubmitted: !isSubmitted,
        userDefinedProperties,
        controls: inferredControls,
    };
}
/**
 * This function creates a form array state with an ID and a value.
 * From the value the shape of the array state is inferred, i.e.
 * object values are inferred as form groups, array values
 * are inferred as form arrays, and primitive values are inferred
 * as form controls.
 */
function createFormArrayState(id, initialValue) {
    const controls = initialValue.map((value, i) => createChildState(`${id}.${i}`, value));
    return computeArrayState(id, controls, initialValue, {}, [], {}, { wasOrShouldBeEnabled: true });
}

function clearAsyncErrorReducer$2(state, action) {
    if (action.type !== clearAsyncErrorAction.type) {
        return state;
    }
    const name = `$${action.name}`;
    let errors = state.errors;
    if (errors.hasOwnProperty(name)) {
        errors = { ...state.errors };
        delete errors[name];
    }
    const pendingValidations = state.pendingValidations.filter((v) => v !== action.name);
    const isValid = isEmpty(errors);
    if (errors === state.errors &&
        isValid === state.isValid &&
        pendingValidations.length === state.pendingValidations.length) {
        return state;
    }
    return {
        ...state,
        isValid,
        isInvalid: !isValid,
        errors,
        pendingValidations,
        isValidationPending: pendingValidations.length > 0,
    };
}

function disableReducer$2(state, action) {
    if (action.type !== disableAction.type) {
        return state;
    }
    if (state.isDisabled) {
        return state;
    }
    return {
        ...state,
        isEnabled: false,
        isDisabled: true,
        isValid: true,
        isInvalid: false,
        errors: {},
        pendingValidations: [],
        isValidationPending: false,
    };
}

function enableReducer$2(state, action) {
    if (action.type !== enableAction.type) {
        return state;
    }
    if (state.isEnabled) {
        return state;
    }
    return {
        ...state,
        isEnabled: true,
        isDisabled: false,
    };
}

function focusReducer(state, action) {
    if (action.type !== focusAction.type) {
        return state;
    }
    if (state.isFocused) {
        return state;
    }
    return {
        ...state,
        isFocused: true,
        isUnfocused: false,
    };
}

function markAsDirtyReducer$2(state, action) {
    if (action.type !== markAsDirtyAction.type) {
        return state;
    }
    if (state.isDirty) {
        return state;
    }
    return {
        ...state,
        isDirty: true,
        isPristine: false,
    };
}

function markAsPristineReducer$2(state, action) {
    if (action.type !== markAsPristineAction.type) {
        return state;
    }
    if (state.isPristine) {
        return state;
    }
    return {
        ...state,
        isDirty: false,
        isPristine: true,
    };
}

function markAsSubmittedReducer$2(state, action) {
    if (action.type !== markAsSubmittedAction.type) {
        return state;
    }
    if (state.isSubmitted) {
        return state;
    }
    return {
        ...state,
        isSubmitted: true,
        isUnsubmitted: false,
    };
}

function markAsTouchedReducer$2(state, action) {
    if (action.type !== markAsTouchedAction.type) {
        return state;
    }
    if (state.isTouched) {
        return state;
    }
    return {
        ...state,
        isTouched: true,
        isUntouched: false,
    };
}

function markAsUnsubmittedReducer$2(state, action) {
    if (action.type !== markAsUnsubmittedAction.type) {
        return state;
    }
    if (state.isUnsubmitted) {
        return state;
    }
    return {
        ...state,
        isSubmitted: false,
        isUnsubmitted: true,
    };
}

function markAsUntouchedReducer$2(state, action) {
    if (action.type !== markAsUntouchedAction.type) {
        return state;
    }
    if (state.isUntouched) {
        return state;
    }
    return {
        ...state,
        isTouched: false,
        isUntouched: true,
    };
}

function resetReducer$2(state, action) {
    if (action.type !== resetAction.type) {
        return state;
    }
    if (state.isPristine && state.isUntouched && state.isUnsubmitted) {
        return state;
    }
    return {
        ...state,
        isDirty: false,
        isPristine: true,
        isTouched: false,
        isUntouched: true,
        isSubmitted: false,
        isUnsubmitted: true,
    };
}

function setAsyncErrorReducer$2(state, action) {
    if (action.type !== setAsyncErrorAction.type) {
        return state;
    }
    if (state.isDisabled) {
        return state;
    }
    const name = `$${action.name}`;
    let value = action.value;
    if (deepEquals(state.errors[name], action.value)) {
        value = state.errors[name];
    }
    const errors = { ...state.errors, [name]: value };
    const pendingValidations = state.pendingValidations.filter((v) => v !== action.name);
    return {
        ...state,
        isValid: false,
        isInvalid: true,
        errors,
        pendingValidations,
        isValidationPending: pendingValidations.length > 0,
    };
}

function setErrorsReducer$2(state, action) {
    if (action.type !== setErrorsAction.type) {
        return state;
    }
    if (state.isDisabled) {
        return state;
    }
    if (state.errors === action.errors) {
        return state;
    }
    if (deepEquals(state.errors, action.errors)) {
        return state;
    }
    if (!action.errors ||
        typeof action.errors !== "object" ||
        Array.isArray(action.errors)) {
        throw new Error(`Control errors must be an object; got ${action.errors}`); // `;
    }
    if (Object.keys(action.errors).some((key) => key.startsWith("$"))) {
        throw new Error(`Control errors must not use $ as a prefix; got ${JSON.stringify(action.errors)}`); // `;
    }
    const asyncErrors = Object.keys(state.errors)
        .filter((key) => key.startsWith("$"))
        .reduce((res, key) => Object.assign(res, { [key]: state.errors[key] }), {});
    const newErrors = isEmpty(asyncErrors)
        ? action.errors
        : Object.assign(asyncErrors, action.errors);
    const isValid = isEmpty(newErrors);
    return {
        ...state,
        isValid,
        isInvalid: !isValid,
        errors: newErrors,
    };
}

function setUserDefinedPropertyReducer$2(state, action) {
    if (action.type !== setUserDefinedPropertyAction.type) {
        return state;
    }
    if (state.userDefinedProperties[action.name] === action.value) {
        return state;
    }
    return {
        ...state,
        userDefinedProperties: {
            ...state.userDefinedProperties,
            [action.name]: action.value,
        },
    };
}

function setValueReducer$2(state, action) {
    if (action.type !== setValueAction.type) {
        return state;
    }
    if (state.value === action.value) {
        return state;
    }
    return {
        ...state,
        // todo: better typing?
        value: verifyFormControlValueIsValid(action.value),
    };
}

function startAsyncValidationReducer$2(state, action) {
    if (action.type !== startAsyncValidationAction.type) {
        return state;
    }
    if (state.pendingValidations.indexOf(action.name) >= 0) {
        return state;
    }
    return {
        ...state,
        pendingValidations: [...state.pendingValidations, action.name],
        isValidationPending: true,
    };
}

function unfocusReducer(state, action) {
    if (action.type !== unfocusAction.type) {
        return state;
    }
    if (state.isUnfocused) {
        return state;
    }
    return {
        ...state,
        isFocused: false,
        isUnfocused: true,
    };
}

function formControlReducerInternal(state, action) {
    if (isGroupState(state) || isArrayState(state)) {
        throw new Error("The state must be a control state");
    }
    if (action.controlId !== state.id) {
        return state;
    }
    state = setValueReducer$2(state, action);
    state = setErrorsReducer$2(state, action);
    state = startAsyncValidationReducer$2(state, action);
    state = setAsyncErrorReducer$2(state, action);
    state = clearAsyncErrorReducer$2(state, action);
    state = enableReducer$2(state, action);
    state = disableReducer$2(state, action);
    state = focusReducer(state, action);
    state = unfocusReducer(state, action);
    state = markAsDirtyReducer$2(state, action);
    state = markAsPristineReducer$2(state, action);
    state = markAsTouchedReducer$2(state, action);
    state = markAsUntouchedReducer$2(state, action);
    state = markAsSubmittedReducer$2(state, action);
    state = markAsUnsubmittedReducer$2(state, action);
    state = setUserDefinedPropertyReducer$2(state, action);
    state = resetReducer$2(state, action);
    return state;
}
/**
 * This reducer function updates a form control state with actions.
 */
function formControlReducer(state, action) {
    if (!state) {
        throw new Error("The control state must be defined!");
    }
    return formControlReducerInternal(state, action);
}

function dispatchActionPerChild$1(controls, actionCreator) {
    let hasChanged = false;
    const newControls = controls.map((state) => {
        const newState = formStateReducer(state, actionCreator(state.id));
        hasChanged = hasChanged || state !== newState;
        return newState;
    });
    return hasChanged ? newControls : controls;
}
function callChildReducers$1(controls, action) {
    let hasChanged = false;
    const newControls = controls.map((state) => {
        const newState = formStateReducer(state, action);
        hasChanged = hasChanged || state !== newState;
        return newState;
    });
    return hasChanged ? newControls : controls;
}
function childReducer$1(state, action) {
    const controls = callChildReducers$1(state.controls, action);
    if (state.controls === controls) {
        return state;
    }
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}
function updateIdRecursiveForGroup(state, newId) {
    const controls = Object.keys(state.controls).reduce((agg, key) => Object.assign(agg, {
        [key]: updateIdRecursive(state.controls[key], `${newId}.${key}`),
    }), {});
    return {
        ...state,
        id: newId,
        controls,
    };
}
function updateIdRecursiveForArray(state, newId) {
    const controls = state.controls.map((c, i) => updateIdRecursive(c, `${newId}.${i}`));
    return {
        ...state,
        id: newId,
        controls,
    };
}
function updateIdRecursive(state, newId) {
    if (state.id === newId) {
        return state;
    }
    if (isGroupState(state)) {
        return updateIdRecursiveForGroup(state, newId);
    }
    if (isArrayState(state)) {
        return updateIdRecursiveForArray(state, newId);
    }
    return {
        ...state,
        id: newId,
    };
}

function addControlReducer$1(state, action) {
    if (action.type !== addArrayControlAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    const index = action.index === undefined ? state.controls.length : action.index;
    if (index > state.controls.length || index < 0) {
        throw new Error(`Index ${index} is out of bounds for array '${state.id}' with length ${state.controls.length}!`);
    }
    let controls = [...state.controls];
    controls.splice(index, 0, createChildState(`${state.id}.${index}`, action.value));
    controls = controls.map((c, i) => updateIdRecursive(c, `${state.id}.${i}`));
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: true,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function clearAsyncErrorReducer$1(state, action) {
    if (action.type !== clearAsyncErrorAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    const name = `$${action.name}`;
    let errors = state.errors;
    if (state.errors.hasOwnProperty(name)) {
        errors = { ...state.errors };
        delete errors[name];
    }
    const pendingValidations = state.pendingValidations.filter((v) => v !== action.name);
    if (errors === state.errors &&
        pendingValidations.length === state.pendingValidations.length) {
        return state;
    }
    return computeArrayState(state.id, state.controls, state.value, errors, pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function disableReducer$1(state, action) {
    if (action.type !== disableAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.isDisabled) {
        return state;
    }
    return computeArrayState(state.id, dispatchActionPerChild$1(state.controls, (controlId) => disableAction({ controlId })), state.value, {}, [], state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: false,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function enableReducer$1(state, action) {
    if (action.type !== enableAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    const controls = dispatchActionPerChild$1(state.controls, (controlId) => enableAction({ controlId }));
    if (controls === state.controls && state.isEnabled) {
        return state;
    }
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: true,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function markAsDirtyReducer$1(state, action) {
    if (action.type !== markAsDirtyAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    const controls = dispatchActionPerChild$1(state.controls, (controlId) => markAsDirtyAction({ controlId }));
    if (controls === state.controls && state.isDirty) {
        return state;
    }
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: true,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function markAsPristineReducer$1(state, action) {
    if (action.type !== markAsPristineAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.isPristine) {
        return state;
    }
    return computeArrayState(state.id, dispatchActionPerChild$1(state.controls, (controlId) => markAsPristineAction({ controlId })), state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: false,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function markAsSubmittedReducer$1(state, action) {
    if (action.type !== markAsSubmittedAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    const controls = dispatchActionPerChild$1(state.controls, (controlId) => markAsSubmittedAction({ controlId }));
    if (controls === state.controls) {
        return state;
    }
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: true,
    });
}

function markAsTouchedReducer$1(state, action) {
    if (action.type !== markAsTouchedAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    const controls = dispatchActionPerChild$1(state.controls, (controlId) => markAsTouchedAction({ controlId }));
    if (controls === state.controls) {
        return state;
    }
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: true,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function markAsUnsubmittedReducer$1(state, action) {
    if (action.type !== markAsUnsubmittedAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.isUnsubmitted) {
        return state;
    }
    return computeArrayState(state.id, dispatchActionPerChild$1(state.controls, (controlId) => markAsUnsubmittedAction({ controlId })), state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: false,
    });
}

function markAsUntouchedReducer$1(state, action) {
    if (action.type !== markAsUntouchedAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.isUntouched) {
        return state;
    }
    return computeArrayState(state.id, dispatchActionPerChild$1(state.controls, (controlId) => markAsUntouchedAction({ controlId })), state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: false,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function move(array, fromIndex, toIndex) {
    const item = array[fromIndex];
    const length = array.length;
    if (fromIndex > toIndex) {
        return [
            ...array.slice(0, toIndex),
            item,
            ...array.slice(toIndex, fromIndex),
            ...array.slice(fromIndex + 1, length),
        ];
    }
    else {
        const targetIndex = toIndex + 1;
        return [
            ...array.slice(0, fromIndex),
            ...array.slice(fromIndex + 1, targetIndex),
            item,
            ...array.slice(targetIndex, length),
        ];
    }
}
function moveControlReducer(state, action) {
    if (action.type !== moveArrayControlAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    const fromIndex = action.fromIndex;
    const toIndex = action.toIndex;
    if (fromIndex === toIndex) {
        return state;
    }
    if (fromIndex < 0 || toIndex < 0) {
        throw new Error(`fromIndex ${fromIndex} or toIndex ${fromIndex} was negative`);
    }
    if (fromIndex >= state.controls.length || toIndex >= state.controls.length) {
        throw new Error(`fromIndex ${fromIndex} or toIndex ${toIndex} is out of bounds with the length of the controls ${state.controls.length}`);
    }
    let controls = move(state.controls, fromIndex, toIndex);
    controls = controls.map((c, i) => updateIdRecursive(c, `${state.id}.${i}`));
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: true,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function removeControlReducer$1(state, action) {
    if (action.type !== removeArrayControlAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (action.index >= state.controls.length || action.index < 0) {
        throw new Error(`Index ${action.index} is out of bounds for array '${state.id}' with length ${state.controls.length}!`);
    }
    const index = action.index;
    const controls = state.controls
        .filter((_, i) => i !== index)
        .map((c, i) => updateIdRecursive(c, `${state.id}.${i}`));
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: true,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function resetReducer$1(state, action) {
    if (action.type !== resetAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.isPristine && state.isUntouched && state.isUnsubmitted) {
        return state;
    }
    return computeArrayState(state.id, dispatchActionPerChild$1(state.controls, (controlId) => resetAction({ controlId })), state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: false,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: false,
        wasOrShouldBeSubmitted: false,
    });
}

function setAsyncErrorReducer$1(state, action) {
    if (action.type !== setAsyncErrorAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.isDisabled) {
        return state;
    }
    const name = `$${action.name}`;
    let value = action.value;
    if (deepEquals(state.errors[name], action.value)) {
        value = state.errors[name];
    }
    const errors = { ...state.errors, [name]: value };
    const pendingValidations = state.pendingValidations.filter((v) => v !== action.name);
    return computeArrayState(state.id, state.controls, state.value, errors, pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function setErrorsReducer$1(state, action) {
    if (action.type !== setErrorsAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.isDisabled) {
        return state;
    }
    if (state.errors === action.errors) {
        return state;
    }
    if (deepEquals(state.errors, action.errors)) {
        return state;
    }
    if (!action.errors ||
        typeof action.errors !== "object" ||
        Array.isArray(action.errors)) {
        throw new Error(`Control errors must be an object; got ${action.errors}`);
    }
    if (Object.keys(action.errors).some((key) => key.startsWith("_"))) {
        throw new Error(`Control errors must not use underscore as a prefix; got ${JSON.stringify(action.errors)}`);
    }
    if (Object.keys(action.errors).some((key) => key.startsWith("$"))) {
        throw new Error(`Control errors must not use $ as a prefix; got ${JSON.stringify(action.errors)}`);
    }
    const childAndAsyncErrors = Object.keys(state.errors)
        .filter((key) => key.startsWith("_") || key.startsWith("$"))
        .reduce((res, key) => Object.assign(res, { [key]: state.errors[key] }), {});
    const newErrors = Object.assign(childAndAsyncErrors, action.errors);
    return computeArrayState(state.id, state.controls, state.value, newErrors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function setUserDefinedPropertyReducer$1(state, action) {
    if (action.type !== setUserDefinedPropertyAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.userDefinedProperties[action.name] === action.value) {
        return state;
    }
    return {
        ...state,
        userDefinedProperties: {
            ...state.userDefinedProperties,
            [action.name]: action.value,
        },
    };
}

function setValueReducer$1(state, action) {
    if (action.type !== setValueAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.value === action.value) {
        return state;
    }
    if (action.value instanceof Date) {
        throw new Error("Date values are not supported. Please used serialized strings instead.");
    }
    // todo: better typing?
    const value = action.value;
    const controls = value.map((v, i) => {
        if (!state.controls[i]) {
            return createChildState(`${state.id}.${i}`, v);
        }
        return formStateReducer(state.controls[i], setValueAction({ controlId: state.controls[i].id, value: v }));
    });
    return computeArrayState(state.id, controls, value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function startAsyncValidationReducer$1(state, action) {
    if (action.type !== startAsyncValidationAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    if (state.pendingValidations.indexOf(action.name) >= 0) {
        return state;
    }
    const pendingValidations = [...state.pendingValidations, action.name];
    return computeArrayState(state.id, state.controls, state.value, state.errors, pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function swapArrayValues(a, i, j) {
    const n = [...a];
    [n[i], n[j]] = [n[j], n[i]];
    return n;
}
function swapControlReducer(state, action) {
    if (action.type !== swapArrayControlAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer$1(state, action);
    }
    const fromIndex = action.fromIndex;
    const toIndex = action.toIndex;
    if (fromIndex === toIndex) {
        return state;
    }
    if (fromIndex < 0 || toIndex < 0) {
        throw new Error(`fromIndex ${fromIndex} or toIndex ${fromIndex} was negative`);
    }
    if (fromIndex >= state.controls.length || toIndex >= state.controls.length) {
        throw new Error(`fromIndex ${fromIndex} or toIndex ${toIndex} is out of bounds with the length of the controls ${state.controls.length}`);
    }
    let controls = swapArrayValues(state.controls, fromIndex, toIndex);
    controls = controls.map((c, i) => i >= fromIndex || i >= toIndex
        ? updateIdRecursive(c, `${state.id}.${i}`)
        : c);
    return computeArrayState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: true,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function formArrayReducerInternal(state, action) {
    if (!isArrayState(state)) {
        throw new Error("The state must be an array state");
    }
    if (!isNgrxFormsAction(action)) {
        return state;
    }
    if (!action.controlId.startsWith(state.id)) {
        return state;
    }
    switch (action.type) {
        case focusAction.type:
        case unfocusAction.type:
        case addGroupControlAction.type:
        case removeGroupControlAction.type:
            return childReducer$1(state, action);
        default:
            break;
    }
    state = setValueReducer$1(state, action);
    state = setErrorsReducer$1(state, action);
    state = startAsyncValidationReducer$1(state, action);
    state = setAsyncErrorReducer$1(state, action);
    state = clearAsyncErrorReducer$1(state, action);
    state = enableReducer$1(state, action);
    state = disableReducer$1(state, action);
    state = markAsDirtyReducer$1(state, action);
    state = markAsPristineReducer$1(state, action);
    state = markAsTouchedReducer$1(state, action);
    state = markAsUntouchedReducer$1(state, action);
    state = markAsSubmittedReducer$1(state, action);
    state = markAsUnsubmittedReducer$1(state, action);
    state = setUserDefinedPropertyReducer$1(state, action);
    state = resetReducer$1(state, action);
    state = addControlReducer$1(state, action);
    state = removeControlReducer$1(state, action);
    state = swapControlReducer(state, action);
    state = moveControlReducer(state, action);
    return state;
}
/**
 * This reducer function updates a form array state with actions.
 */
function formArrayReducer(state, action) {
    if (!state) {
        throw new Error("The array state must be defined!");
    }
    return formArrayReducerInternal(state, action);
}

function formStateReducer(state, action) {
    if (!state) {
        throw new Error("The form state must be defined!");
    }
    if (!isFormState(state)) {
        throw new Error(`state must be a form state, got ${state}`);
    }
    if (isGroupState(state)) {
        return formGroupReducer(state, action);
    }
    if (isArrayState(state)) {
        return formArrayReducer(state, action);
    }
    return formControlReducer(state, action);
}
/**
 * This function creates a reducer function that first applies an action to the state
 * and afterwards applies all given update functions one after another to the resulting
 * form state. However, the update functions are only applied if the form state changed
 * as result of applying the action. If you need the update functions to be applied
 * regardless of whether the state changed (e.g. because the update function closes
 * over variables that may change independently of the form state) you can simply apply
 * the update manually (e.g. `updateFunction(formStateReducer(state, action))`).
 *
 * The following (contrived) example uses this function to create a reducer that after
 * each action validates the child control `name` to be required and sets the child
 * control `email`'s value to be `''` if the name is invalid.
 *
```typescript
interface FormValue {
  name: string;
  email: string;
}

const updateFormState = updateGroup<FormValue>(
  {
    name: validate(required),
  },
  {
    email: (email, parentGroup) =>
      parentGroup.controls.name.isInvalid
        ? setValue('', email)
        : email,
  },
);

const reducer = createFormStateReducerWithUpdate<FormValue>(updateFormState);
```
 */
function createFormStateReducerWithUpdate(updateFnOrUpdateFnArr, ...updateFnArr) {
    updateFnArr = [
        ...(Array.isArray(updateFnOrUpdateFnArr)
            ? updateFnOrUpdateFnArr
            : [updateFnOrUpdateFnArr]),
        ...updateFnArr,
    ];
    return (state, action) => {
        const newState = formStateReducer(state, action);
        return newState === state
            ? state
            : updateFnArr.reduce((s, f) => f(s), newState);
    };
}
function reduceNestedFormState(state, key, action) {
    const value = state[key];
    if (!isFormState(value)) {
        return state;
    }
    return {
        ...state,
        [key]: formStateReducer(value, action),
    };
}
function reduceNestedFormStates(state, action) {
    return Object.keys(state).reduce((s, key) => reduceNestedFormState(s, key, action), state);
}
/**
 * This function returns an object that can be passed to ngrx's `createReducer`
 * function. By doing this all form state properties on the state will be updated
 * whenever necessary (i.e. whenever an ngrx-forms action is dispatched).
 *
 * To manually update a form state (e.g. to validate it) use
 * `wrapReducerWithFormStateUpdate`.
 */
function onNgrxForms() {
    return {
        reducer: (state, action) => isFormState(state)
            ? formStateReducer(state, action)
            : reduceNestedFormStates(state, action),
        types: ALL_NGRX_FORMS_ACTION_TYPES,
    };
}
/**
 * This function wraps a reducer and returns another reducer that first calls
 * the given reducer and then calls the given update function for the form state
 * that is specified by the form state locator function.
 *
 * The update function is passed the form state and the updated containing state
 * as parameters.
 */
function wrapReducerWithFormStateUpdate(reducer, formStateLocator, updateFn) {
    return (state, action) => {
        const updatedState = reducer(state, action);
        const formState = formStateLocator(updatedState);
        // if the state itself is the form state, update it directly
        if (formState === updatedState) {
            return updateFn(formState, updatedState);
        }
        const formStateKey = Object.keys(updatedState).find((key) => updatedState[key] === formState);
        const updatedFormState = updateFn(formState, updatedState);
        if (updatedFormState === formState) {
            return updatedState;
        }
        return {
            ...updatedState,
            [formStateKey]: updatedFormState,
        };
    };
}

function dispatchActionPerChild(controls, actionCreator) {
    let hasChanged = false;
    const newControls = Object.keys(controls).reduce((c, key) => {
        Object.assign(c, {
            [key]: formStateReducer(controls[key], actionCreator(controls[key].id)),
        });
        hasChanged = hasChanged || c[key] !== controls[key];
        return c;
    }, {});
    return hasChanged ? newControls : controls;
}
function callChildReducers(controls, action) {
    let hasChanged = false;
    const newControls = Object.keys(controls)
        .map((key) => [key, formStateReducer(controls[key], action)])
        .reduce((res, [key, state]) => {
        hasChanged = hasChanged || state !== controls[key];
        return Object.assign(res, { [key]: state });
    }, {});
    return hasChanged ? newControls : controls;
}
function childReducer(state, action) {
    const controls = callChildReducers(state.controls, action);
    if (state.controls === controls) {
        return state;
    }
    return computeGroupState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function addControlReducer(state, action) {
    if (action.type !== addGroupControlAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.controls.hasOwnProperty(action.name)) {
        throw new Error(`Group '${state.id}' already has child control '${action.name}'!`);
    }
    const controls = Object.assign({}, state.controls, {
        [action.name]: createChildState(`${state.id}.${action.name}`, action.value),
    });
    return computeGroupState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: true,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function clearAsyncErrorReducer(state, action) {
    if (action.type !== clearAsyncErrorAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    const name = `$${action.name}`;
    let errors = state.errors;
    if (errors.hasOwnProperty(name)) {
        errors = { ...state.errors };
        delete errors[name];
    }
    const pendingValidations = state.pendingValidations.filter((v) => v !== action.name);
    if (errors === state.errors &&
        pendingValidations.length === state.pendingValidations.length) {
        return state;
    }
    return computeGroupState(state.id, state.controls, state.value, errors, pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function disableReducer(state, action) {
    if (action.type !== disableAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.isDisabled) {
        return state;
    }
    return computeGroupState(state.id, dispatchActionPerChild(state.controls, (controlId) => disableAction({ controlId })), state.value, {}, [], state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: false,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function enableReducer(state, action) {
    if (action.type !== enableAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    const controls = dispatchActionPerChild(state.controls, (controlId) => enableAction({ controlId }));
    if (controls === state.controls) {
        return state;
    }
    return computeGroupState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: true,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function markAsDirtyReducer(state, action) {
    if (action.type !== markAsDirtyAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    const controls = dispatchActionPerChild(state.controls, (controlId) => markAsDirtyAction({ controlId }));
    if (controls === state.controls) {
        return state;
    }
    return computeGroupState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: true,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function markAsPristineReducer(state, action) {
    if (action.type !== markAsPristineAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.isPristine) {
        return state;
    }
    return computeGroupState(state.id, dispatchActionPerChild(state.controls, (controlId) => markAsPristineAction({ controlId })), state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: false,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function markAsSubmittedReducer(state, action) {
    if (action.type !== markAsSubmittedAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    const controls = dispatchActionPerChild(state.controls, (controlId) => markAsSubmittedAction({ controlId }));
    if (controls === state.controls) {
        return state;
    }
    return computeGroupState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: true,
    });
}

function markAsTouchedReducer(state, action) {
    if (action.type !== markAsTouchedAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    const controls = dispatchActionPerChild(state.controls, (controlId) => markAsTouchedAction({ controlId }));
    if (controls === state.controls) {
        return state;
    }
    return computeGroupState(state.id, controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: true,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function markAsUnsubmittedReducer(state, action) {
    if (action.type !== markAsUnsubmittedAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.isUnsubmitted) {
        return state;
    }
    return computeGroupState(state.id, dispatchActionPerChild(state.controls, (controlId) => markAsUnsubmittedAction({ controlId })), state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: false,
    });
}

function markAsUntouchedReducer(state, action) {
    if (action.type !== markAsUntouchedAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.isUntouched) {
        return state;
    }
    return computeGroupState(state.id, dispatchActionPerChild(state.controls, (controlId) => markAsUntouchedAction({ controlId })), state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: false,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function removeControlReducer(state, action) {
    if (action.type !== removeGroupControlAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (!state.controls.hasOwnProperty(action.name)) {
        throw new Error(`Group '${state.id}' does not have child control '${action.name}'!`);
    }
    const { [action.name]: _, ...controls } = state.controls;
    return computeGroupState(state.id, 
    // todo: better typing?
    controls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: true,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function resetReducer(state, action) {
    if (action.type !== resetAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.isPristine && state.isUntouched && state.isUnsubmitted) {
        return state;
    }
    return computeGroupState(state.id, dispatchActionPerChild(state.controls, (controlId) => resetAction({ controlId })), state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: false,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: false,
        wasOrShouldBeSubmitted: false,
    });
}

function setAsyncErrorReducer(state, action) {
    if (action.type !== setAsyncErrorAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.isDisabled) {
        return state;
    }
    const name = `$${action.name}`;
    let value = action.value;
    if (deepEquals(state.errors[name], action.value)) {
        value = state.errors[name];
    }
    const errors = { ...state.errors, [name]: value };
    const pendingValidations = state.pendingValidations.filter((v) => v !== action.name);
    return computeGroupState(state.id, state.controls, state.value, errors, pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function setErrorsReducer(state, action) {
    if (action.type !== setErrorsAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.isDisabled) {
        return state;
    }
    if (state.errors === action.errors) {
        return state;
    }
    if (deepEquals(state.errors, action.errors)) {
        return state;
    }
    if (!action.errors ||
        typeof action.errors !== "object" ||
        Array.isArray(action.errors)) {
        throw new Error(`Control errors must be an object; got ${action.errors}`); // `;
    }
    if (Object.keys(action.errors).some((key) => key.startsWith("_"))) {
        throw new Error(`Control errors must not use underscore as a prefix; got ${JSON.stringify(action.errors)}`); // `;
    }
    if (Object.keys(action.errors).some((key) => key.startsWith("$"))) {
        throw new Error(`Control errors must not use $ as a prefix; got ${JSON.stringify(action.errors)}`); // `;
    }
    const childAndAsyncErrors = Object.keys(state.errors)
        .filter((key) => key.startsWith("_") || key.startsWith("$"))
        .reduce((res, key) => Object.assign(res, { [key]: state.errors[key] }), {});
    const newErrors = Object.assign(childAndAsyncErrors, action.errors);
    return computeGroupState(state.id, state.controls, state.value, newErrors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function setUserDefinedPropertyReducer(state, action) {
    if (action.type !== setUserDefinedPropertyAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.userDefinedProperties[action.name] === action.value) {
        return state;
    }
    return {
        ...state,
        userDefinedProperties: {
            ...state.userDefinedProperties,
            [action.name]: action.value,
        },
    };
}

function setValueReducer(state, action) {
    if (action.type !== setValueAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.value === action.value) {
        return state;
    }
    if (action.value instanceof Date) {
        throw new Error("Date values are not supported. Please used serialized strings instead.");
    }
    // todo: better typing?
    const value = action.value;
    const controls = Object.keys(value).reduce((c, key) => {
        const control = state.controls[key];
        // tslint:disable-next-line:prefer-conditional-expression
        if (!control) {
            Object.assign(c, {
                [key]: createChildState(`${state.id}.${key}`, value[key]),
            });
        }
        else {
            Object.assign(c, {
                [key]: formStateReducer(control, setValueAction({
                    controlId: control.id,
                    value: value[key],
                })),
            });
        }
        return c;
    }, {});
    return computeGroupState(state.id, controls, value, state.errors, state.pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function startAsyncValidationReducer(state, action) {
    if (action.type !== startAsyncValidationAction.type) {
        return state;
    }
    if (action.controlId !== state.id) {
        return childReducer(state, action);
    }
    if (state.pendingValidations.indexOf(action.name) >= 0) {
        return state;
    }
    const pendingValidations = [...state.pendingValidations, action.name];
    return computeGroupState(state.id, state.controls, state.value, state.errors, pendingValidations, state.userDefinedProperties, {
        wasOrShouldBeDirty: state.isDirty,
        wasOrShouldBeEnabled: state.isEnabled,
        wasOrShouldBeTouched: state.isTouched,
        wasOrShouldBeSubmitted: state.isSubmitted,
    });
}

function formGroupReducerInternal(state, action) {
    if (!isGroupState(state)) {
        throw new Error("The state must be a group state");
    }
    if (!isNgrxFormsAction(action)) {
        return state;
    }
    if (!action.controlId.startsWith(state.id)) {
        return state;
    }
    switch (action.type) {
        case focusAction.type:
        case unfocusAction.type:
        case addArrayControlAction.type:
        case removeArrayControlAction.type:
        case moveArrayControlAction.type:
        case swapArrayControlAction.type:
            return childReducer(state, action);
        default:
            break;
    }
    state = setValueReducer(state, action);
    state = setErrorsReducer(state, action);
    state = startAsyncValidationReducer(state, action);
    state = setAsyncErrorReducer(state, action);
    state = clearAsyncErrorReducer(state, action);
    state = enableReducer(state, action);
    state = disableReducer(state, action);
    state = markAsDirtyReducer(state, action);
    state = markAsPristineReducer(state, action);
    state = markAsTouchedReducer(state, action);
    state = markAsUntouchedReducer(state, action);
    state = markAsSubmittedReducer(state, action);
    state = markAsUnsubmittedReducer(state, action);
    state = addControlReducer(state, action);
    state = removeControlReducer(state, action);
    state = setUserDefinedPropertyReducer(state, action);
    state = resetReducer(state, action);
    return state;
}
/**
 * This reducer function updates a form group state with actions.
 */
function formGroupReducer(state, action) {
    if (!state) {
        throw new Error("The group state must be defined!");
    }
    return formGroupReducerInternal(state, action);
}

function abstractControlReducer(state, action) {
    if (isArrayState(state)) {
        return formArrayReducer(state, action);
    }
    if (isGroupState(state)) {
        return formGroupReducer(state, action);
    }
    return formControlReducer(state, action);
}
function compose(...fns) {
    return (t) => fns.reduce((res, f) => f(res), t);
}
function ensureState(state) {
    if (!state) {
        throw new Error('state must not be undefined!');
    }
    return state;
}

function updateArrayControlsState(filterFn, updateFn) {
    return (state) => {
        let hasChanged = false;
        const newControls = state.controls.map((control, idx) => {
            if (!filterFn(control, idx)) {
                return control;
            }
            const newControl = updateFn(control, state);
            hasChanged = hasChanged || newControl !== control;
            return newControl;
        });
        return hasChanged ? newControls : state.controls;
    };
}
function updateArraySingle(filterFn, updateFn) {
    return (state) => {
        const newControls = updateArrayControlsState(filterFn, updateFn)(state);
        return newControls !== state.controls
            ? computeArrayState(state.id, newControls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
                wasOrShouldBeDirty: state.isDirty,
                wasOrShouldBeEnabled: state.isEnabled,
                wasOrShouldBeTouched: state.isTouched,
                wasOrShouldBeSubmitted: state.isSubmitted,
            })
            : state;
    };
}
function updateArrayWithFilter(stateOrFilterFunction, filterFunctionOrFunctionOrFunctionArray, updateFnOrUpdateFnArr, ...rest) {
    if (isArrayState(stateOrFilterFunction)) {
        const filterFn = filterFunctionOrFunctionOrFunctionArray;
        const updateFnArr = Array.isArray(updateFnOrUpdateFnArr) ? updateFnOrUpdateFnArr : [updateFnOrUpdateFnArr];
        return updateFnArr.concat(...rest).reduce((s, updateFn) => updateArraySingle(filterFn, updateFn)(s), stateOrFilterFunction);
    }
    let updateFnArr = Array.isArray(filterFunctionOrFunctionOrFunctionArray)
        ? filterFunctionOrFunctionOrFunctionArray
        : [filterFunctionOrFunctionOrFunctionArray];
    updateFnArr = updateFnOrUpdateFnArr === undefined ? updateFnArr : updateFnArr.concat(updateFnOrUpdateFnArr);
    return (s) => updateArrayWithFilter(ensureState(s), stateOrFilterFunction, updateFnArr.concat(rest));
}
function updateArray(stateOrFunctionOrFunctionArray, updateFnOrUpdateFnArr, ...rest) {
    if (isArrayState(stateOrFunctionOrFunctionArray)) {
        const updateFnArr = Array.isArray(updateFnOrUpdateFnArr) ? updateFnOrUpdateFnArr : [updateFnOrUpdateFnArr];
        return updateFnArr.concat(...rest).reduce((s, updateFn) => updateArraySingle(() => true, updateFn)(s), stateOrFunctionOrFunctionArray);
    }
    let updateFnArr = Array.isArray(stateOrFunctionOrFunctionArray) ? stateOrFunctionOrFunctionArray : [stateOrFunctionOrFunctionArray];
    updateFnArr = updateFnOrUpdateFnArr === undefined ? updateFnArr : updateFnArr.concat(updateFnOrUpdateFnArr);
    return (s) => updateArray(ensureState(s), updateFnArr.concat(rest));
}

function updateGroupControlsState(updateFns) {
    return (state) => {
        let hasChanged = false;
        const newControls = Object.keys(state.controls).reduce((res, key) => {
            const control = state.controls[key];
            Object.assign(res, { [key]: control });
            if (updateFns.hasOwnProperty(key)) {
                const newControl = updateFns[key](control, state);
                hasChanged = hasChanged || newControl !== control;
                Object.assign(res, { [key]: newControl });
            }
            return res;
        }, {});
        return hasChanged ? newControls : state.controls;
    };
}
function updateGroupSingle(updateFns) {
    return (state) => {
        const newControls = updateGroupControlsState(updateFns)(state);
        return newControls !== state.controls
            ? computeGroupState(state.id, newControls, state.value, state.errors, state.pendingValidations, state.userDefinedProperties, {
                wasOrShouldBeDirty: state.isDirty,
                wasOrShouldBeEnabled: state.isEnabled,
                wasOrShouldBeTouched: state.isTouched,
                wasOrShouldBeSubmitted: state.isSubmitted,
            })
            : state;
    };
}
function updateGroup(stateOrUpdateFnOrUpdateFnArray, updateFnOrUpdateFnArr, ...rest) {
    if (isGroupState(stateOrUpdateFnOrUpdateFnArray)) {
        const updateFnArr = Array.isArray(updateFnOrUpdateFnArr) ? updateFnOrUpdateFnArr : [updateFnOrUpdateFnArr];
        return updateFnArr.concat(...rest).reduce((s, updateFn) => updateGroupSingle(updateFn)(s), stateOrUpdateFnOrUpdateFnArray);
    }
    let updateFnArr = Array.isArray(stateOrUpdateFnOrUpdateFnArray) ? stateOrUpdateFnOrUpdateFnArray : [stateOrUpdateFnOrUpdateFnArray];
    updateFnArr = updateFnOrUpdateFnArr === undefined ? updateFnArr : updateFnArr.concat(updateFnOrUpdateFnArr);
    return (s) => updateGroup(ensureState(s), updateFnArr.concat(rest));
}

function updateRecursiveSingle(parent, updateFn) {
    return (state) => {
        if (isGroupState(state)) {
            const updateFunctions = Object.keys(state.controls).reduce((agg, key) => Object.assign(agg, {
                [key]: (s, p) => updateRecursiveSingle(p, updateFn)(s),
            }), {});
            state = updateGroup(updateFunctions)(state);
            return updateFn(state, parent);
        }
        if (isArrayState(state)) {
            state = updateArray((s, p) => updateRecursiveSingle(p, updateFn)(s))(state);
            return updateFn(state, parent);
        }
        return updateFn(state, parent);
    };
}
function updateRecursive(stateOrFunctionOrFunctionArray, updateFnOrUpdateFnArr, ...rest) {
    if (isFormState(stateOrFunctionOrFunctionArray)) {
        const updateFnArr = Array.isArray(updateFnOrUpdateFnArr) ? updateFnOrUpdateFnArr : [updateFnOrUpdateFnArr];
        return updateFnArr.concat(...rest)
            .reduce((s, updateFn) => updateRecursiveSingle(stateOrFunctionOrFunctionArray, updateFn)(s), stateOrFunctionOrFunctionArray);
    }
    let updateFnArr = Array.isArray(stateOrFunctionOrFunctionArray) ? stateOrFunctionOrFunctionArray : [stateOrFunctionOrFunctionArray];
    updateFnArr = updateFnOrUpdateFnArr === undefined ? updateFnArr : updateFnArr.concat(updateFnOrUpdateFnArr);
    return (s) => updateRecursive(ensureState(s), updateFnArr.concat(rest));
}

function setValue(valueOrState, value) {
    if (isFormState(valueOrState)) {
        return abstractControlReducer(valueOrState, setValueAction({ controlId: valueOrState.id, value }));
    }
    return (s) => setValue(ensureState(s), valueOrState);
}

function setErrors(errorsOrErrorsArrayOrState, errorsOrErrorsArray, ...rest) {
    if (isFormState(errorsOrErrorsArrayOrState)) {
        const state = errorsOrErrorsArrayOrState;
        const errorsArray = Array.isArray(errorsOrErrorsArray)
            ? errorsOrErrorsArray
            : [errorsOrErrorsArray];
        const errors = errorsArray
            .concat(...rest)
            .reduce((agg, err) => Object.assign(agg, err), {});
        return formStateReducer(state, setErrorsAction({ controlId: state.id, errors }));
    }
    let errorsArray = Array.isArray(errorsOrErrorsArrayOrState)
        ? errorsOrErrorsArrayOrState
        : [errorsOrErrorsArrayOrState];
    errorsArray =
        errorsOrErrorsArray === undefined
            ? errorsArray
            : errorsArray.concat(errorsOrErrorsArray);
    return (s) => setErrors(ensureState(s), errorsArray.concat(rest));
}

function validate(stateOrFunctionOrFunctionArray, functionOrFunctionArr, ...rest) {
    if (isFormState(stateOrFunctionOrFunctionArray)) {
        const state = stateOrFunctionOrFunctionArray;
        const functionArr = Array.isArray(functionOrFunctionArr)
            ? functionOrFunctionArr
            : [functionOrFunctionArr];
        const errors = functionArr
            .concat(...rest)
            .reduce((agg, validationFn) => Object.assign(agg, validationFn(state.value)), {});
        return formStateReducer(stateOrFunctionOrFunctionArray, setErrorsAction({ controlId: state.id, errors }));
    }
    const functionOrFunctionArray = stateOrFunctionOrFunctionArray;
    let updateFnArr = Array.isArray(functionOrFunctionArray)
        ? functionOrFunctionArray
        : [functionOrFunctionArray];
    updateFnArr =
        functionOrFunctionArr === undefined
            ? updateFnArr
            : updateFnArr.concat(functionOrFunctionArr);
    return (s) => validate(ensureState(s), updateFnArr.concat(rest));
}

function enable(state) {
    return abstractControlReducer(state, enableAction({ controlId: state.id }));
}

function disable(state) {
    return abstractControlReducer(state, disableAction({ controlId: state.id }));
}

function markAsDirty(state) {
    return abstractControlReducer(state, markAsDirtyAction({ controlId: state.id }));
}

function markAsPristine(state) {
    return abstractControlReducer(state, markAsPristineAction({ controlId: state.id }));
}

function markAsTouched(state) {
    return abstractControlReducer(state, markAsTouchedAction({ controlId: state.id }));
}

function markAsUntouched(state) {
    return abstractControlReducer(state, markAsUntouchedAction({ controlId: state.id }));
}

function markAsSubmitted(state) {
    return abstractControlReducer(state, markAsSubmittedAction({ controlId: state.id }));
}

function markAsUnsubmitted(state) {
    return abstractControlReducer(state, markAsUnsubmittedAction({ controlId: state.id }));
}

/**
 * This update function takes a form control state and marks it as focused (which
 * will also `.focus()` the form element).
 */
function focus(state) {
    return formControlReducer(state, focusAction({ controlId: state.id }));
}

/**
 * This update function takes a form control state and marks it as not focused (which
 * will also `.blur()` the form element).
 */
function unfocus(state) {
    return formControlReducer(state, unfocusAction({ controlId: state.id }));
}

function addArrayControl(valueOrState, indexOrValue, index) {
    if (isArrayState(valueOrState)) {
        return formArrayReducer(valueOrState, addArrayControlAction({
            controlId: valueOrState.id,
            value: indexOrValue,
            index,
        }));
    }
    return (s) => addArrayControl(ensureState(s), valueOrState, indexOrValue);
}

function addGroupControl(nameOrState, valueOrName, value) {
    if (isGroupState(nameOrState)) {
        return formGroupReducer(nameOrState, addGroupControlAction({
            controlId: nameOrState.id,
            // todo: better typing?
            name: valueOrName,
            value: value,
        }));
    }
    return (s) => addGroupControl(ensureState(s), nameOrState, valueOrName);
}

function moveArrayControl(indexOrState, fromIndex, toIndex) {
    if (isArrayState(indexOrState)) {
        return formArrayReducer(indexOrState, moveArrayControlAction({
            controlId: indexOrState.id,
            fromIndex,
            toIndex: toIndex,
        }));
    }
    return (s) => moveArrayControl(ensureState(s), indexOrState, fromIndex);
}

function swapArrayControl(indexOrState, fromIndex, toIndex) {
    if (isArrayState(indexOrState)) {
        return formArrayReducer(indexOrState, swapArrayControlAction({
            controlId: indexOrState.id,
            fromIndex,
            toIndex: toIndex,
        }));
    }
    return (s) => swapArrayControl(ensureState(s), indexOrState, fromIndex);
}

function removeArrayControl(indexOrState, index) {
    if (isArrayState(indexOrState)) {
        return formArrayReducer(indexOrState, removeArrayControlAction({ controlId: indexOrState.id, index: index }));
    }
    return (s) => removeArrayControl(ensureState(s), indexOrState);
}

function removeGroupControl(nameOrState, name) {
    if (isGroupState(nameOrState)) {
        return formGroupReducer(nameOrState, 
        // todo: better typing?
        removeGroupControlAction({
            controlId: nameOrState.id,
            name: name,
        }));
    }
    return (s) => removeGroupControl(ensureState(s), nameOrState);
}

function setUserDefinedProperty(nameOrState, valueOrName, value) {
    if (isFormState(nameOrState)) {
        const state = nameOrState;
        return formStateReducer(nameOrState, setUserDefinedPropertyAction({
            controlId: state.id,
            name: valueOrName,
            value,
        }));
    }
    return (s) => setUserDefinedProperty(ensureState(s), nameOrState, valueOrName);
}

function reset(state) {
    return abstractControlReducer(state, resetAction({ controlId: state.id }));
}

function startAsyncValidation(nameOrState, name) {
    if (isFormState(nameOrState)) {
        return abstractControlReducer(nameOrState, startAsyncValidationAction({ controlId: nameOrState.id, name: name }));
    }
    return (s) => startAsyncValidation(ensureState(s), nameOrState);
}

function setAsyncError(nameOrState, nameOrValue, value) {
    if (isFormState(nameOrState)) {
        return abstractControlReducer(nameOrState, setAsyncErrorAction({
            controlId: nameOrState.id,
            name: nameOrValue,
            value,
        }));
    }
    return (s) => setAsyncError(ensureState(s), nameOrState, nameOrValue);
}

function clearAsyncError(nameOrState, name) {
    if (isFormState(nameOrState)) {
        return abstractControlReducer(nameOrState, clearAsyncErrorAction({ controlId: nameOrState.id, name: name }));
    }
    return (s) => clearAsyncError(ensureState(s), nameOrState);
}

/**
 * Used to provide a {@link FormViewAdapter} for form elements.
 */
const NGRX_FORM_VIEW_ADAPTER = new InjectionToken('NgrxFormViewAdapter');

// tslint:disable:directive-class-suffix
class NgrxCheckboxViewAdapter {
    renderer;
    elementRef;
    state;
    nativeIdWasSet = false;
    onChange = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'checked', value);
    }
    setOnChangeCallback(fn) {
        this.onChange = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    handleInput({ target }) {
        this.onChange(target.checked);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxCheckboxViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxCheckboxViewAdapter, selector: "input[type=checkbox][ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "change": "handleInput($event)" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxCheckboxViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxCheckboxViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'input[type=checkbox][ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxCheckboxViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], handleInput: [{
                type: HostListener,
                args: ['change', ['$event']]
            }] } });

/**
 * We must check whether the agent is Android because composition events
 * behave differently between iOS and Android.
 */
function isAndroid(navigator) {
    return /android (\d+)/.test(navigator.userAgent.toLowerCase());
}
// tslint:disable:directive-class-suffix
// tslint:disable:directive-selector
// TODO: since this directive has a side-effect (setting the element's id attribute)
// it should not blacklist other types of inputs but instead it should somehow figure
// out whether it is the "active" view adapter and only perform its side effects if it
// is active
class NgrxDefaultViewAdapter {
    renderer;
    elementRef;
    platformId;
    state;
    nativeIdWasSet = false;
    onChange = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    /** Whether the user is creating a composition string (IME events). */
    isComposing = false;
    isCompositionSupported;
    constructor(renderer, elementRef, platformId = null, 
    // we use a special injection string that should never exist at runtime to allow mocking this dependency for testing
    navigator = null) {
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.platformId = platformId;
        this.isCompositionSupported = isPlatformBrowser(this.platformId || '') && !isAndroid(navigator || window.navigator);
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        const normalizedValue = value == null ? '' : value;
        this.renderer.setProperty(this.elementRef.nativeElement, 'value', normalizedValue);
    }
    setOnChangeCallback(fn) {
        this.onChange = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    handleInput({ target }) {
        if (this.isCompositionSupported && this.isComposing) {
            return;
        }
        this.onChange(target.value);
    }
    compositionStart() {
        this.isComposing = true;
    }
    compositionEnd({ target }) {
        this.isComposing = false;
        if (this.isCompositionSupported) {
            this.onChange(target.value);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxDefaultViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: PLATFORM_ID, optional: true }, { token: 'ngrx-forms/never', optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxDefaultViewAdapter, selector: "input:not([type=checkbox]):not([type=number]):not([type=radio]):not([type=range])[ngrxFormControlState],textarea[ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "input": "handleInput($event)", "compositionstart": "compositionStart()", "compositionend": "compositionEnd($event)" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxDefaultViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxDefaultViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input:not([type=checkbox]):not([type=number]):not([type=radio]):not([type=range])[ngrxFormControlState],textarea[ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxDefaultViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: ['ngrx-forms/never']
                }] }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], handleInput: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], compositionStart: [{
                type: HostListener,
                args: ['compositionstart']
            }], compositionEnd: [{
                type: HostListener,
                args: ['compositionend', ['$event']]
            }] } });

// tslint:disable:directive-class-suffix
class NgrxNumberViewAdapter {
    renderer;
    elementRef;
    state;
    nativeIdWasSet = false;
    onChange = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        // The value needs to be normalized for IE9, otherwise it is set to 'null' when null
        const normalizedValue = value === null ? '' : value;
        this.renderer.setProperty(this.elementRef.nativeElement, 'value', normalizedValue);
    }
    setOnChangeCallback(fn) {
        this.onChange = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    handleInput({ target }) {
        const value = target.value;
        this.onChange(value === '' ? null : parseFloat(value));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxNumberViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxNumberViewAdapter, selector: "input[type=number][ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "change": "handleInput($event)", "input": "handleInput($event)" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxNumberViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxNumberViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'input[type=number][ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxNumberViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], handleInput: [{
                type: HostListener,
                args: ['change', ['$event']]
            }, {
                type: HostListener,
                args: ['input', ['$event']]
            }] } });

// tslint:disable:directive-class-suffix
class NgrxSelectViewAdapter {
    renderer;
    elementRef;
    state;
    optionMap = {};
    idCounter = 0;
    selectedId = null;
    value = undefined;
    nativeIdWasSet = false;
    onChangeFn = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        this.value = value;
        this.selectedId = this.getOptionId(value);
        if (this.selectedId === null) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'selectedIndex', -1);
        }
        this.renderer.setProperty(this.elementRef.nativeElement, 'value', this.selectedId);
    }
    onChange({ target }) {
        this.selectedId = target.value;
        const value = this.optionMap[this.selectedId];
        this.value = value;
        this.onChangeFn(value);
    }
    setOnChangeCallback(fn) {
        this.onChangeFn = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    createOptionId() {
        const id = this.idCounter.toString();
        this.idCounter += 1;
        return id;
    }
    updateOptionValue(id, value) {
        this.optionMap[id] = value;
        if (this.selectedId === id) {
            this.onChangeFn(value);
        }
        else if (value === this.value) {
            this.setViewValue(value);
        }
    }
    deregisterOption(id) {
        delete this.optionMap[id];
    }
    getOptionId(value) {
        for (const id of Array.from(Object.keys(this.optionMap))) {
            if (this.optionMap[id] === value) {
                return id;
            }
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxSelectViewAdapter, selector: "select:not([multiple])[ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "change": "onChange($event)" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxSelectViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'select:not([multiple])[ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxSelectViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], onChange: [{
                type: HostListener,
                args: ['change', ['$event']]
            }] } });
const NULL_VIEW_ADAPTER$1 = {
    createOptionId: () => '',
    deregisterOption: () => void 0,
    updateOptionValue: () => void 0,
};
const NULL_RENDERER$2 = {
    setProperty: () => void 0,
};
class NgrxSelectOption {
    element;
    renderer;
    viewAdapter;
    isInitialized = false;
    id;
    constructor(element, renderer, viewAdapter) {
        this.element = element;
        this.renderer = renderer;
        this.viewAdapter = viewAdapter;
        this.renderer = viewAdapter ? renderer : NULL_RENDERER$2;
        this.viewAdapter = viewAdapter || NULL_VIEW_ADAPTER$1;
        this.id = this.viewAdapter.createOptionId();
    }
    set value(value) {
        // this cannot be done inside ngOnInit since the value property
        // must be already set when the option value is updated in the view
        // adapter and the initial binding of 'value' happens before
        // ngOnInit runs
        if (!this.isInitialized) {
            this.isInitialized = true;
            this.renderer.setProperty(this.element.nativeElement, 'value', this.id);
        }
        this.viewAdapter.updateOptionValue(this.id, value);
    }
    ngOnDestroy() {
        this.viewAdapter.deregisterOption(this.id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectOption, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: NgrxSelectViewAdapter, host: true, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxSelectOption, selector: "option", inputs: { value: "value" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectOption, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'option',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: NgrxSelectViewAdapter, decorators: [{
                    type: Host
                }, {
                    type: Optional
                }] }], propDecorators: { value: [{
                type: Input,
                args: ['value']
            }] } });

// tslint:disable:directive-class-suffix
class NgrxSelectMultipleViewAdapter {
    renderer;
    elementRef;
    state;
    options = {};
    optionValues = {};
    idCounter = 0;
    selectedIds = [];
    nativeIdWasSet = false;
    onChangeFn = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        if (value === null) {
            value = [];
        }
        if (!Array.isArray(value)) {
            throw new Error(`the value provided to a NgrxSelectMultipleViewAdapter must be null or an array; got ${value} of type ${typeof value}`); // `
        }
        this.selectedIds = value.map(v => this.getOptionId(v)).filter(id => id !== null).map(id => id);
        Object.keys(this.options).forEach(id => this.options[id].isSelected = this.selectedIds.indexOf(id) >= 0);
    }
    onChange() {
        this.selectedIds = Object.keys(this.options).filter(id => this.options[id].isSelected);
        const value = this.selectedIds.map(id => this.optionValues[id]);
        this.onChangeFn(value);
    }
    setOnChangeCallback(fn) {
        this.onChangeFn = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    registerOption(option) {
        const id = this.idCounter.toString();
        this.options[id] = option;
        this.idCounter += 1;
        return id;
    }
    updateOptionValue(id, value) {
        this.optionValues[id] = value;
        if (this.selectedIds.indexOf(id) >= 0) {
            this.onChange();
        }
    }
    deregisterOption(id) {
        delete this.options[id];
        delete this.optionValues[id];
    }
    getOptionId(value) {
        for (const id of Array.from(Object.keys(this.optionValues))) {
            if (this.optionValues[id] === value) {
                return id;
            }
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectMultipleViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxSelectMultipleViewAdapter, selector: "select[multiple][ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "change": "onChange()" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxSelectMultipleViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectMultipleViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'select[multiple][ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxSelectMultipleViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], onChange: [{
                type: HostListener,
                args: ['change']
            }] } });
const NULL_VIEW_ADAPTER = {
    registerOption: () => '',
    deregisterOption: () => void 0,
    updateOptionValue: () => void 0,
};
const NULL_RENDERER$1 = {
    setProperty: () => void 0,
};
class NgrxSelectMultipleOption {
    element;
    renderer;
    viewAdapter;
    id;
    constructor(element, renderer, viewAdapter) {
        this.element = element;
        this.renderer = renderer;
        this.viewAdapter = viewAdapter;
        this.renderer = viewAdapter ? renderer : NULL_RENDERER$1;
        this.viewAdapter = viewAdapter || NULL_VIEW_ADAPTER;
        this.id = this.viewAdapter.registerOption(this);
    }
    set value(value) {
        this.viewAdapter.updateOptionValue(this.id, value);
    }
    set isSelected(selected) {
        this.renderer.setProperty(this.element.nativeElement, 'selected', selected);
    }
    get isSelected() {
        return this.element.nativeElement.selected;
    }
    ngOnInit() {
        this.renderer.setProperty(this.element.nativeElement, 'value', this.id);
    }
    ngOnDestroy() {
        this.viewAdapter.deregisterOption(this.id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectMultipleOption, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: NgrxSelectMultipleViewAdapter, host: true, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxSelectMultipleOption, selector: "option", inputs: { value: "value" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectMultipleOption, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'option',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: NgrxSelectMultipleViewAdapter, decorators: [{
                    type: Host
                }, {
                    type: Optional
                }] }], propDecorators: { value: [{
                type: Input,
                args: ['value']
            }] } });

// tslint:disable:directive-class-suffix
const NULL_RENDERER = {
    setProperty: () => void 0,
};
/**
 * This directive is necessary to restore the default behaviour of Angular
 * when an `option` is used without an **ngrx-forms** form state. Since it
 * is not possible to select an element with a selector that considers its
 * parent the `option` directives for `select` and `select[multiple]` will
 * always be applied and therefore overriding the `[value]` binding which
 * disabled Angular's normal behaviour. This directive restores this
 * behaviour if no `select` or `select[multiple]` view adapter is found.
 * This is not a perfect solution since it may interfere with other
 * directives that try to set the `[value]` but that is very unlikely.
 */
class NgrxFallbackSelectOption {
    element;
    renderer;
    constructor(element, renderer, viewAdapter, multipleViewAdapter) {
        this.element = element;
        this.renderer = renderer;
        this.renderer = viewAdapter || multipleViewAdapter ? NULL_RENDERER : renderer;
    }
    set value(value) {
        this.renderer.setProperty(this.element.nativeElement, 'value', value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFallbackSelectOption, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: NgrxSelectViewAdapter, host: true, optional: true }, { token: NgrxSelectMultipleViewAdapter, host: true, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxFallbackSelectOption, selector: "option", inputs: { value: "value" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFallbackSelectOption, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'option',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: NgrxSelectViewAdapter, decorators: [{
                    type: Host
                }, {
                    type: Optional
                }] }, { type: NgrxSelectMultipleViewAdapter, decorators: [{
                    type: Host
                }, {
                    type: Optional
                }] }], propDecorators: { value: [{
                type: Input,
                args: ['value']
            }] } });

// tslint:disable:directive-class-suffix
class NgrxRadioViewAdapter {
    renderer;
    elementRef;
    state;
    nativeNameWasSet = false;
    set value(val) {
        if (val !== this.latestValue) {
            this.latestValue = val;
            if (this.isChecked) {
                this.onChange();
            }
        }
    }
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeName = this.elementRef.nativeElement.name;
        const shouldSetNativeName = value.id !== nativeName && this.nativeNameWasSet;
        if (shouldSetNativeName) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'name', value.id);
        }
    }
    latestValue;
    isChecked;
    onChange = () => void 0;
    onTouched = () => void 0;
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    ngOnInit() {
        this.isChecked = this.elementRef.nativeElement.checked;
    }
    ngAfterViewInit() {
        const nativeName = this.elementRef.nativeElement.name;
        const shouldSetNativeName = this.state.id !== nativeName && !nativeName;
        if (shouldSetNativeName) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'name', this.state.id);
            this.nativeNameWasSet = true;
        }
    }
    setViewValue(value) {
        this.isChecked = value === this.latestValue;
        this.renderer.setProperty(this.elementRef.nativeElement, 'checked', this.isChecked);
    }
    setOnChangeCallback(fn) {
        this.onChange = () => fn(this.latestValue);
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxRadioViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxRadioViewAdapter, selector: "input[type=radio][ngrxFormControlState]", inputs: { value: "value", ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "change": "onChange()", "blur": "onTouched()" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxRadioViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxRadioViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'input[type=radio][ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxRadioViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { value: [{
                type: Input
            }], ngrxFormControlState: [{
                type: Input
            }], onChange: [{
                type: HostListener,
                args: ['change']
            }], onTouched: [{
                type: HostListener,
                args: ['blur']
            }] } });

// tslint:disable:directive-class-suffix
class NgrxRangeViewAdapter {
    renderer;
    elementRef;
    state;
    nativeIdWasSet = false;
    onChange = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'value', parseFloat(value));
    }
    setOnChangeCallback(fn) {
        this.onChange = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    handleInput({ target }) {
        const value = target.value;
        this.onChange(value === '' ? null : parseFloat(value));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxRangeViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxRangeViewAdapter, selector: "input[type=range][ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "change": "handleInput($event)", "input": "handleInput($event)" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxRangeViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxRangeViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'input[type=range][ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxRangeViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], handleInput: [{
                type: HostListener,
                args: ['change', ['$event']]
            }, {
                type: HostListener,
                args: ['input', ['$event']]
            }] } });

const BUILTIN_ADAPTERS = [
    NgrxCheckboxViewAdapter,
    NgrxRangeViewAdapter,
    NgrxNumberViewAdapter,
    NgrxSelectViewAdapter,
    NgrxSelectMultipleViewAdapter,
    NgrxRadioViewAdapter,
];
function isBuiltInViewAdapter(viewAdapter) {
    return BUILTIN_ADAPTERS.some(a => viewAdapter.constructor === a);
}
function selectViewAdapter(viewAdapters) {
    if (!viewAdapters) {
        throw new Error('No view adapter matches!');
    }
    let defaultAdapter;
    let builtinAdapter;
    let customAdapter;
    viewAdapters.forEach((v) => {
        if (v.constructor === NgrxDefaultViewAdapter) {
            defaultAdapter = v;
        }
        else if (isBuiltInViewAdapter(v)) {
            if (builtinAdapter) {
                throw new Error('More than one built-in view adapter matches!');
            }
            builtinAdapter = v;
        }
        else {
            if (customAdapter) {
                throw new Error('More than one custom view adapter matches!');
            }
            customAdapter = v;
        }
    });
    if (customAdapter) {
        return customAdapter;
    }
    if (builtinAdapter) {
        return builtinAdapter;
    }
    if (defaultAdapter) {
        return defaultAdapter;
    }
    throw new Error('No valid view adapter!');
}

// tslint:disable-next-line:variable-name
const NgrxValueConverters = {
    default() {
        return {
            convertViewToStateValue: value => typeof value === 'object' && value !== null ? box(value) : value,
            convertStateToViewValue: unbox,
        };
    },
    dateToISOString: {
        convertViewToStateValue: date => date === null ? null : date.toISOString(),
        convertStateToViewValue: s => s === null ? null : new Date(Date.parse(s)),
    },
    objectToJSON: {
        convertViewToStateValue: value => value === null ? null : JSON.stringify(value),
        convertStateToViewValue: s => s === null ? null : JSON.parse(s),
    },
};

var NGRX_UPDATE_ON_TYPE;
(function (NGRX_UPDATE_ON_TYPE) {
    NGRX_UPDATE_ON_TYPE["CHANGE"] = "change";
    NGRX_UPDATE_ON_TYPE["BLUR"] = "blur";
    NGRX_UPDATE_ON_TYPE["NEVER"] = "never";
})(NGRX_UPDATE_ON_TYPE || (NGRX_UPDATE_ON_TYPE = {}));
class ControlValueAccessorAdapter {
    valueAccessor;
    constructor(valueAccessor) {
        this.valueAccessor = valueAccessor;
    }
    setViewValue(value) {
        this.valueAccessor.writeValue(value);
    }
    setOnChangeCallback(fn) {
        this.valueAccessor.registerOnChange(fn);
    }
    setOnTouchedCallback(fn) {
        this.valueAccessor.registerOnTouched(fn);
    }
    setIsDisabled(isDisabled) {
        if (this.valueAccessor.setDisabledState) {
            this.valueAccessor.setDisabledState(isDisabled);
        }
    }
}
class NgrxFormControlDirective {
    el;
    dom;
    actionsSubject;
    isInitialized = false;
    focusTrackingIsEnabled = false;
    set ngrxFormControlState(newState) {
        if (!newState) {
            throw new Error("The control state must not be undefined!");
        }
        const oldState = this.state;
        this.state = newState;
        if (this.isInitialized) {
            this.updateViewIfControlIdChanged(newState, oldState);
            this.updateViewIfValueChanged(newState, oldState);
            this.updateViewIfIsDisabledChanged(newState, oldState);
            this.updateViewIfIsFocusedChanged(newState, oldState);
        }
    }
    ngrxUpdateOn = NGRX_UPDATE_ON_TYPE.CHANGE;
    set ngrxEnableFocusTracking(value) {
        if (value && !this.dom) {
            throw new Error("focus tracking is only supported on the browser platform");
        }
        this.focusTrackingIsEnabled = value;
    }
    ngrxValueConverter = NgrxValueConverters.default();
    // TODO: move this into a separate directive
    // automatically apply the attribute that's used by the CDK to set initial focus
    get focusRegionStartAttr() {
        return this.state && this.state.isFocused ? "" : null;
    }
    state;
    viewAdapter;
    // we have to store the latest known state value since most input elements don't play nicely with
    // setting the same value again (e.g. input elements move the cursor to the end of the input when
    // a new value is set which means whenever the user types something the cursor is forced to the
    // end of the input) which would for example happen every time a new value is pushed to the state
    // since when the action to update the state is dispatched a new state will be received inside
    // the directive, which in turn would trigger a view update; to prevent this behavior we compare
    // the latest known state value with the value to be set and filter out those values that are equal
    // to the latest known value
    viewValue;
    stateValue;
    constructor(el, 
    // for the dom parameter the `null` type must be last to ensure that in the compiled output
    // there is no reference to the Document type to support non-browser platforms
    dom, actionsSubject, viewAdapters, valueAccessors) {
        this.el = el;
        this.dom = dom;
        this.actionsSubject = actionsSubject;
        viewAdapters = viewAdapters || [];
        valueAccessors = valueAccessors || [];
        if (valueAccessors.length > 1) {
            throw new Error("More than one custom control value accessor matches!");
        }
        this.viewAdapter =
            valueAccessors.length > 0
                ? new ControlValueAccessorAdapter(valueAccessors[0])
                : selectViewAdapter(viewAdapters);
    }
    updateViewIfControlIdChanged(newState, oldState) {
        if (oldState && newState.id === oldState.id) {
            return;
        }
        this.stateValue = newState.value;
        this.viewValue = this.ngrxValueConverter.convertStateToViewValue(this.stateValue);
        this.viewAdapter.setViewValue(this.viewValue);
        if (this.viewAdapter.setIsDisabled) {
            this.viewAdapter.setIsDisabled(newState.isDisabled);
        }
    }
    updateViewIfValueChanged(newState, _) {
        if (newState.value === this.stateValue) {
            return;
        }
        this.stateValue = newState.value;
        this.viewValue = this.ngrxValueConverter.convertStateToViewValue(newState.value);
        this.viewAdapter.setViewValue(this.viewValue);
    }
    updateViewIfIsDisabledChanged(newState, oldState) {
        if (!this.viewAdapter.setIsDisabled) {
            return;
        }
        if (oldState && newState.isDisabled === oldState.isDisabled) {
            return;
        }
        this.viewAdapter.setIsDisabled(newState.isDisabled);
    }
    updateViewIfIsFocusedChanged(newState, oldState) {
        if (!this.focusTrackingIsEnabled) {
            return;
        }
        if (oldState && newState.isFocused === oldState.isFocused) {
            return;
        }
        if (newState.isFocused) {
            this.el.nativeElement.focus();
        }
        else {
            this.el.nativeElement.blur();
        }
    }
    dispatchAction(action) {
        if (this.actionsSubject !== null) {
            this.actionsSubject.next(action);
        }
        else {
            throw new Error("ActionsSubject must be present in order to dispatch actions!");
        }
    }
    ngOnInit() {
        if (!this.state) {
            throw new Error("The form state must not be undefined!");
        }
        this.isInitialized = true;
        this.updateViewIfControlIdChanged(this.state, undefined);
        this.updateViewIfValueChanged(this.state, undefined);
        this.updateViewIfIsDisabledChanged(this.state, undefined);
        this.updateViewIfIsFocusedChanged(this.state, undefined);
        const dispatchMarkAsDirtyAction = () => {
            if (this.state.isPristine) {
                this.dispatchAction(markAsDirtyAction({ controlId: this.state.id }));
            }
        };
        const dispatchSetValueAction = () => {
            this.stateValue = this.ngrxValueConverter.convertViewToStateValue(this.viewValue);
            if (this.stateValue !== this.state.value) {
                this.dispatchAction(setValueAction({ controlId: this.state.id, value: this.stateValue }));
                dispatchMarkAsDirtyAction();
            }
        };
        this.viewAdapter.setOnChangeCallback((viewValue) => {
            this.viewValue = viewValue;
            if (this.ngrxUpdateOn === NGRX_UPDATE_ON_TYPE.CHANGE) {
                dispatchSetValueAction();
            }
        });
        this.viewAdapter.setOnTouchedCallback(() => {
            if (!this.state.isTouched &&
                this.ngrxUpdateOn !== NGRX_UPDATE_ON_TYPE.NEVER) {
                this.dispatchAction(markAsTouchedAction({ controlId: this.state.id }));
            }
            if (this.ngrxUpdateOn === NGRX_UPDATE_ON_TYPE.BLUR) {
                dispatchSetValueAction();
            }
        });
    }
    ngAfterViewInit() {
        // we need to update the view again after it was initialized since some
        // controls depend on child elements for setting the value (e.g. selects)
        this.viewAdapter.setViewValue(this.viewValue);
        if (this.viewAdapter.setIsDisabled) {
            this.viewAdapter.setIsDisabled(this.state.isDisabled);
        }
    }
    onFocusChange() {
        if (!this.focusTrackingIsEnabled) {
            return;
        }
        const isControlFocused = this.el.nativeElement === this.dom.activeElement;
        if (isControlFocused !== this.state.isFocused) {
            this.dispatchAction(isControlFocused
                ? focusAction({ controlId: this.state.id })
                : unfocusAction({ controlId: this.state.id }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormControlDirective, deps: [{ token: i0.ElementRef }, { token: DOCUMENT, optional: true }, { token: ActionsSubject, optional: true }, { token: NGRX_FORM_VIEW_ADAPTER, optional: true, self: true }, { token: NG_VALUE_ACCESSOR, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxFormControlDirective, selector: ":not([ngrxFormsAction])[ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState", ngrxUpdateOn: "ngrxUpdateOn", ngrxEnableFocusTracking: "ngrxEnableFocusTracking", ngrxValueConverter: "ngrxValueConverter" }, host: { listeners: { "focusin": "onFocusChange()", "focusout": "onFocusChange()" }, properties: { "attr.cdk-focus-region-start": "this.focusRegionStartAttr" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormControlDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: ":not([ngrxFormsAction])[ngrxFormControlState]",
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.ActionsSubject, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ActionsSubject]
                }] }, { type: undefined, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [NGRX_FORM_VIEW_ADAPTER]
                }] }, { type: undefined, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [NG_VALUE_ACCESSOR]
                }] }], propDecorators: { ngrxFormControlState: [{
                type: Input
            }], ngrxUpdateOn: [{
                type: Input
            }], ngrxEnableFocusTracking: [{
                type: Input
            }], ngrxValueConverter: [{
                type: Input
            }], focusRegionStartAttr: [{
                type: HostBinding,
                args: ["attr.cdk-focus-region-start"]
            }], onFocusChange: [{
                type: HostListener,
                args: ["focusin"]
            }, {
                type: HostListener,
                args: ["focusout"]
            }] } });

class NgrxLocalFormControlDirective extends NgrxFormControlDirective {
    ngrxFormsAction = new EventEmitter();
    constructor(el, dom, viewAdapters, valueAccessors) {
        super(el, dom, null, viewAdapters, valueAccessors);
    }
    dispatchAction(action) {
        this.ngrxFormsAction.emit(action);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxLocalFormControlDirective, deps: [{ token: i0.ElementRef }, { token: DOCUMENT, optional: true }, { token: NGRX_FORM_VIEW_ADAPTER, optional: true, self: true }, { token: NG_VALUE_ACCESSOR, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxLocalFormControlDirective, selector: "[ngrxFormControlState][ngrxFormsAction]", outputs: { ngrxFormsAction: "ngrxFormsAction" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxLocalFormControlDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: "[ngrxFormControlState][ngrxFormsAction]",
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: undefined, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [NGRX_FORM_VIEW_ADAPTER]
                }] }, { type: undefined, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [NG_VALUE_ACCESSOR]
                }] }], propDecorators: { ngrxFormsAction: [{
                type: Output
            }] } });

class NgrxFormDirective {
    actionsSubject;
    // tslint:disable-next-line:no-input-rename
    state;
    constructor(actionsSubject) {
        this.actionsSubject = actionsSubject;
        this.actionsSubject = actionsSubject;
    }
    dispatchAction(action) {
        if (this.actionsSubject !== null) {
            this.actionsSubject.next(action);
        }
        else {
            throw new Error("ActionsSubject must be present in order to dispatch actions!");
        }
    }
    ngOnInit() {
        if (!this.state) {
            throw new Error("The form state must not be undefined!");
        }
    }
    onSubmit(event) {
        event.preventDefault();
        if (this.state.isUnsubmitted) {
            this.dispatchAction(markAsSubmittedAction({ controlId: this.state.id }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormDirective, deps: [{ token: ActionsSubject, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxFormDirective, selector: "form:not([ngrxFormsAction])[ngrxFormState]", inputs: { state: ["ngrxFormState", "state"] }, host: { listeners: { "submit": "onSubmit($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: "form:not([ngrxFormsAction])[ngrxFormState]",
                }]
        }], ctorParameters: () => [{ type: i1.ActionsSubject, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ActionsSubject]
                }] }], propDecorators: { state: [{
                type: Input,
                args: ["ngrxFormState"]
            }], onSubmit: [{
                type: HostListener,
                args: ["submit", ["$event"]]
            }] } });

class NgrxLocalFormDirective extends NgrxFormDirective {
    ngrxFormsAction = new EventEmitter();
    constructor() {
        super(null);
    }
    dispatchAction(action) {
        this.ngrxFormsAction.emit(action);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxLocalFormDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxLocalFormDirective, selector: "form[ngrxFormState][ngrxFormsAction]", outputs: { ngrxFormsAction: "ngrxFormsAction" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxLocalFormDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: "form[ngrxFormState][ngrxFormsAction]",
                }]
        }], ctorParameters: () => [], propDecorators: { ngrxFormsAction: [{
                type: Output
            }] } });

/**
 * Lists the available status class names based on the property
 * they are depending on.
 */
const NGRX_STATUS_CLASS_NAMES = {
    isValid: 'ngrx-forms-valid',
    isInvalid: 'ngrx-forms-invalid',
    isDirty: 'ngrx-forms-dirty',
    isPristine: 'ngrx-forms-pristine',
    isTouched: 'ngrx-forms-touched',
    isUntouched: 'ngrx-forms-untouched',
    isSubmitted: 'ngrx-forms-submitted',
    isUnsubmitted: 'ngrx-forms-unsubmitted',
    isValidationPending: 'ngrx-forms-validation-pending',
};
class NgrxStatusCssClassesDirective {
    state;
    set ngrxFormControlState(state) {
        this.state = state;
    }
    set ngrxFormState(state) {
        this.state = state;
    }
    get isValid() {
        return this.state.isValid;
    }
    get isInvalid() {
        return this.state.isInvalid;
    }
    get isDirty() {
        return this.state.isDirty;
    }
    get isPristine() {
        return this.state.isPristine;
    }
    get isTouched() {
        return this.state.isTouched;
    }
    get isUntouched() {
        return this.state.isUntouched;
    }
    get isSubmitted() {
        return this.state.isSubmitted;
    }
    get isUnsubmitted() {
        return this.state.isUnsubmitted;
    }
    get isValidationPending() {
        return this.state.isValidationPending;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxStatusCssClassesDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxStatusCssClassesDirective, selector: "form[ngrxFormState],[ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState", ngrxFormState: "ngrxFormState" }, host: { properties: { "class.ngrx-forms-valid": "this.isValid", "class.ngrx-forms-invalid": "this.isInvalid", "class.ngrx-forms-dirty": "this.isDirty", "class.ngrx-forms-pristine": "this.isPristine", "class.ngrx-forms-touched": "this.isTouched", "class.ngrx-forms-untouched": "this.isUntouched", "class.ngrx-forms-submitted": "this.isSubmitted", "class.ngrx-forms-unsubmitted": "this.isUnsubmitted", "class.ngrx-forms-validation-pending": "this.isValidationPending" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxStatusCssClassesDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'form[ngrxFormState],[ngrxFormControlState]',
                }]
        }], propDecorators: { ngrxFormControlState: [{
                type: Input
            }], ngrxFormState: [{
                type: Input
            }], isValid: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isValid}`]
            }], isInvalid: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isInvalid}`]
            }], isDirty: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isDirty}`]
            }], isPristine: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isPristine}`]
            }], isTouched: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isTouched}`]
            }], isUntouched: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isUntouched}`]
            }], isSubmitted: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isSubmitted}`]
            }], isUnsubmitted: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isUnsubmitted}`]
            }], isValidationPending: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isValidationPending}`]
            }] } });

const exportsAndDeclarations = [
    NgrxFormControlDirective,
    NgrxLocalFormControlDirective,
    NgrxFormDirective,
    NgrxLocalFormDirective,
    NgrxCheckboxViewAdapter,
    NgrxDefaultViewAdapter,
    NgrxNumberViewAdapter,
    NgrxRadioViewAdapter,
    NgrxRangeViewAdapter,
    NgrxSelectMultipleOption,
    NgrxSelectMultipleViewAdapter,
    NgrxSelectOption,
    NgrxSelectViewAdapter,
    NgrxFallbackSelectOption,
    NgrxStatusCssClassesDirective,
];
class NgrxFormsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormsModule, declarations: [NgrxFormControlDirective,
            NgrxLocalFormControlDirective,
            NgrxFormDirective,
            NgrxLocalFormDirective,
            NgrxCheckboxViewAdapter,
            NgrxDefaultViewAdapter,
            NgrxNumberViewAdapter,
            NgrxRadioViewAdapter,
            NgrxRangeViewAdapter,
            NgrxSelectMultipleOption,
            NgrxSelectMultipleViewAdapter,
            NgrxSelectOption,
            NgrxSelectViewAdapter,
            NgrxFallbackSelectOption,
            NgrxStatusCssClassesDirective], exports: [NgrxFormControlDirective,
            NgrxLocalFormControlDirective,
            NgrxFormDirective,
            NgrxLocalFormDirective,
            NgrxCheckboxViewAdapter,
            NgrxDefaultViewAdapter,
            NgrxNumberViewAdapter,
            NgrxRadioViewAdapter,
            NgrxRangeViewAdapter,
            NgrxSelectMultipleOption,
            NgrxSelectMultipleViewAdapter,
            NgrxSelectOption,
            NgrxSelectViewAdapter,
            NgrxFallbackSelectOption,
            NgrxStatusCssClassesDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormsModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: exportsAndDeclarations,
                    exports: exportsAndDeclarations,
                }]
        }] });

// this regex is taken from the @angular/forms source code
// tslint:disable-next-line:max-line-length
const NGRX_FORMS_EMAIL_VALIDATION_REGEXP = /^(?=.{1,254}$)(?=.{1,64}@)[-!#$%&'*+/0-9=?A-Z^_`a-z{|}~]+(\.[-!#$%&'*+/0-9=?A-Z^_`a-z{|}~]+)*@[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/;
/**
 * A validation function that requires a value to be a valid e-mail address.
 * Considers `null`, `undefined`, and `''` as valid. Combine this function with the
 * `required` validation function if these values should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  email: {
    pattern: string;
    actual: string;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  userMailAddress: validate(email),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function email(value) {
    value = unbox(value);
    if (value === null || value === undefined || value.length === 0) {
        return {};
    }
    if (NGRX_FORMS_EMAIL_VALIDATION_REGEXP.test(value)) {
        return {};
    }
    return {
        email: {
            pattern: NGRX_FORMS_EMAIL_VALIDATION_REGEXP.toString(),
            actual: value,
        },
    };
}

/**
 * A validation function that requires the value to be strictly equal (i.e. `===`)
 * to another value.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  equalTo: {
    comparand: T;
    actual: T;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  name: validate(equalTo('John Doe')),
})
```
 */
function equalTo(comparand) {
    return (value) => {
        value = unbox(value);
        if (value === comparand) {
            return {};
        }
        return {
            equalTo: {
                comparand,
                actual: value,
            },
        };
    };
}

/**
 * A validation function that requires the value to be greater than a number.
 * Considers `null`, `undefined` and non-numeric values as valid. Combine this function with the `required`
 * validation function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  greaterThan: {
    comparand: number;
    actual: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  amount: validate(greaterThan(10)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function greaterThan(comparand) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (comparand === null || comparand === undefined) {
        throw new Error(`The greaterThan Validation function requires the comparand parameter to be a non-null number, got ${comparand}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined || typeof value !== "number") {
            return {};
        }
        if (value > comparand) {
            return {};
        }
        return {
            greaterThan: {
                comparand,
                actual: value,
            },
        };
    };
}

/**
 * A validation function that requires the value to be greater than or equal to a number.
 * Considers `null`, `undefined` and non-numeric values as valid. Combine this function with the `required`
 * validation function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  greaterThanOrEqualTo: {
    comparand: number;
    actual: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  amount: validate(greaterThanOrEqualTo(10)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function greaterThanOrEqualTo(comparand) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (comparand === null || comparand === undefined) {
        throw new Error(`The greaterThanOrEqualTo Validation function requires the comparand parameter to be a non-null number, got ${comparand}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined || typeof value !== "number") {
            return {};
        }
        if (value >= comparand) {
            return {};
        }
        return {
            greaterThanOrEqualTo: {
                comparand,
                actual: value,
            },
        };
    };
}

/**
 * A validation function that requires the value to be less than a number.
 * Considers `null`, `undefined` and non-numeric values as valid. Combine this function with the `required`
 * validation function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  lessThan: {
    comparand: number;
    actual: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  amount: validate(lessThan(10)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function lessThan(comparand) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (comparand === null || comparand === undefined) {
        throw new Error(`The lessThan Validation function requires the comparand parameter to be a non-null number, got ${comparand}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined || typeof value !== "number") {
            return {};
        }
        if (value < comparand) {
            return {};
        }
        return {
            lessThan: {
                comparand,
                actual: value,
            },
        };
    };
}

/**
 * A validation function that requires the value to be less than or equal to a number.
 * Considers `null`, `undefined` and non-numeric values as valid. Combine this function with the `required`
 * validation function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  lessThanOrEqualTo: {
    comparand: number;
    actual: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  amount: validate(lessThanOrEqualTo(10)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function lessThanOrEqualTo(comparand) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (comparand === null || comparand === undefined) {
        throw new Error(`The lessThanOrEqualTo Validation function requires the comparand parameter to be a non-null number, got ${comparand}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined || typeof value !== "number") {
            return {};
        }
        if (value <= comparand) {
            return {};
        }
        return {
            lessThanOrEqualTo: {
                comparand,
                actual: value,
            },
        };
    };
}

/**
 * A validation function that requires a `string` or `array` value to have a maximum length.
 * Considers `null` and `undefined` as valid. Combine this function with the `required`
 * validation function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  maxLength: {
    maxLength: number;
    value: string;
    actualLength: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  name: validate(maxLength(10)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function maxLength(maxLengthParam) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (maxLengthParam === null || maxLengthParam === undefined) {
        throw new Error(`The maxLength Validation function requires the maxLength parameter to be a non-null number, got ${maxLengthParam}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined) {
            return {};
        }
        const length = value.length;
        if (length <= maxLengthParam) {
            return {};
        }
        return {
            maxLength: {
                maxLength: maxLengthParam,
                value: value,
                actualLength: length,
            },
        };
    };
}

/**
 * A validation function that requires a `string` or `array` value to have a minimum length.
 * Considers `null`, `undefined`, empty strings and empty arrays as valid. Combine this
 * function with the `required` validation function if these values should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  minLength: {
    minLength: number;
    value: string;
    actualLength: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  password: validate(minLength(8)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function minLength(minLengthParam) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (minLengthParam === null || minLengthParam === undefined) {
        throw new Error(`The minLength Validation function requires the minLength parameter to be a non-null number, got ${minLengthParam}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined) {
            return {};
        }
        const length = value.length;
        if (length === 0) {
            return {}; // don't validate empty values to allow optional controls
        }
        if (length >= minLengthParam) {
            return {};
        }
        return {
            minLength: {
                minLength: minLengthParam,
                value: value,
                actualLength: length,
            },
        };
    };
}

/**
 * A validation function that requires the value to be strictly not equal (i.e. `!==`)
 * to another value.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  notEqualTo: {
    comparand: T;
    actual: T;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  name: validate(notEqualTo('John Doe')),
})
```
 */
function notEqualTo(comparand) {
    return (value) => {
        value = unbox(value);
        if (value !== comparand) {
            return {};
        }
        return {
            notEqualTo: {
                comparand,
                actual: value,
            },
        };
    };
}

/**
 * A validation function that requires a value to match a regex.
 * Considers `null`, `undefined`, and `''` as valid. Combine this function with the
 * `required` validation function if these values should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  pattern: {
    pattern: string;
    actual: string;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  numberWithPeriodsOrCommas: validate(pattern(/^[0-9.,]+$/)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function pattern(patternParam) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (patternParam === null || patternParam === undefined) {
        throw new Error(`The pattern Validation function requires the pattern parameter to be a non-null string or regular expression, got ${patternParam}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null ||
            value === undefined ||
            value.length === 0) {
            return {};
        }
        if (patternParam.test(value)) {
            return {};
        }
        return {
            pattern: {
                pattern: patternParam.toString(),
                actual: value,
            },
        };
    };
}

/**
 * A validation function that requires the value to be non-`undefined`, non-'null',
 * and non-empty.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  required: {
    actual: T | null | undefined;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  name: validate(required),
})
```
 */
function required(value) {
    value = unbox(value);
    if (value !== undefined && value !== null && value.length !== 0) {
        return {};
    }
    return {
        required: {
            actual: value,
        },
    };
}

/**
 * A validation function that requires a value to be a valid number.
 * Considers `null` and `undefined` as valid. Combine this function with the
 * `required` validation function if these values should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  number: {
    actual: any;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  amount: validate(number),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function number(value) {
    value = unbox(value);
    if (value === null || value === undefined || typeof value === "number") {
        return {};
    }
    return {
        number: {
            actual: value,
        },
    };
}

/**
 * A validation function that requires the value to be `false`. Considers `null` and
 * `undefined` as valid. Combine this function with the `required` validation
 * function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  required: {
    actual: boolean;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  disagreeWithTermsOfService: validate(requiredFalse),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function requiredFalse(value) {
    value = unbox(value);
    // tslint:disable-next-line:strict-type-predicates
    if (value === null || value === undefined) {
        return {};
    }
    if (!value) {
        return {};
    }
    return {
        required: {
            actual: value,
        },
    };
}

/**
 * A validation function that requires the value to be `true`. Considers `null` and
 * `undefined` as valid. Combine this function with the `required` validation
 * function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  required: {
    actual: boolean;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  agreeWithTermsOfService: validate(requiredTrue),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
function requiredTrue(value) {
    value = unbox(value);
    // tslint:disable-next-line:strict-type-predicates
    if (value === null || value === undefined) {
        return {};
    }
    if (value) {
        return {};
    }
    return {
        required: {
            actual: value,
        },
    };
}

/**
 * ngrx-forms
 * Proper integration of forms in Angular applications using Ngrx
 * Written by Jonathan Ziller.
 * MIT license.
 * https://github.com/MrWolfZ/ngrx-forms
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ALL_NGRX_FORMS_ACTION_TYPES, NGRX_FORM_VIEW_ADAPTER, NGRX_STATUS_CLASS_NAMES, NGRX_UPDATE_ON_TYPE, NgrxCheckboxViewAdapter, NgrxDefaultViewAdapter, NgrxFallbackSelectOption, NgrxFormControlDirective, NgrxFormDirective, NgrxFormsModule, NgrxLocalFormControlDirective, NgrxLocalFormDirective, NgrxNumberViewAdapter, NgrxRadioViewAdapter, NgrxRangeViewAdapter, NgrxSelectMultipleOption, NgrxSelectMultipleViewAdapter, NgrxSelectOption, NgrxSelectViewAdapter, NgrxStatusCssClassesDirective, NgrxValueConverters, addArrayControl, addArrayControlAction, addGroupControl, addGroupControlAction, box, clearAsyncError, clearAsyncErrorAction, compose, createFormArrayState, createFormControlState, createFormGroupState, createFormStateReducerWithUpdate, disable, disableAction, email, enable, enableAction, equalTo, focus, focusAction, formArrayReducer, formControlReducer, formGroupReducer, formStateReducer, greaterThan, greaterThanOrEqualTo, isArrayState, isBoxed, isGroupState, isNgrxFormsAction, lessThan, lessThanOrEqualTo, markAsDirty, markAsDirtyAction, markAsPristine, markAsPristineAction, markAsSubmitted, markAsSubmittedAction, markAsTouched, markAsTouchedAction, markAsUnsubmitted, markAsUnsubmittedAction, markAsUntouched, markAsUntouchedAction, maxLength, minLength, moveArrayControl, moveArrayControlAction, notEqualTo, number, onNgrxForms, pattern, removeArrayControl, removeArrayControlAction, removeGroupControl, removeGroupControlAction, required, requiredFalse, requiredTrue, reset, resetAction, setAsyncError, setAsyncErrorAction, setErrors, setErrorsAction, setUserDefinedProperty, setUserDefinedPropertyAction, setValue, setValueAction, startAsyncValidation, startAsyncValidationAction, swapArrayControl, swapArrayControlAction, unbox, unfocus, unfocusAction, updateArray, updateArrayWithFilter, updateGroup, updateRecursive, validate, wrapReducerWithFormStateUpdate };
//# sourceMappingURL=ngrx-forms.mjs.map
