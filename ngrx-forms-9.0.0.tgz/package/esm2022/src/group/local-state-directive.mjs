import { Directive, EventEmitter, Output } from "@angular/core";
import { NgrxFormDirective } from "./directive";
import * as i0 from "@angular/core";
export class NgrxLocalFormDirective extends NgrxFormDirective {
    ngrxFormsAction = new EventEmitter();
    constructor() {
        super(null);
    }
    dispatchAction(action) {
        this.ngrxFormsAction.emit(action);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxLocalFormDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxLocalFormDirective, selector: "form[ngrxFormState][ngrxFormsAction]", outputs: { ngrxFormsAction: "ngrxFormsAction" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxLocalFormDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: "form[ngrxFormState][ngrxFormsAction]",
                }]
        }], ctorParameters: () => [], propDecorators: { ngrxFormsAction: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYWwtc3RhdGUtZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2dyb3VwL2xvY2FsLXN0YXRlLWRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFJaEUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sYUFBYSxDQUFDOztBQU9oRCxNQUFNLE9BQU8sc0JBRVgsU0FBUSxpQkFBOEI7SUFDNUIsZUFBZSxHQUFHLElBQUksWUFBWSxFQUF1QixDQUFDO0lBRXBFO1FBQ0UsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2QsQ0FBQztJQUVTLGNBQWMsQ0FBQyxNQUEyQjtRQUNsRCxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNwQyxDQUFDO3VHQVhVLHNCQUFzQjsyRkFBdEIsc0JBQXNCOzsyRkFBdEIsc0JBQXNCO2tCQUpsQyxTQUFTO21CQUFDO29CQUNULDhDQUE4QztvQkFDOUMsUUFBUSxFQUFFLHNDQUFzQztpQkFDakQ7d0RBSVcsZUFBZTtzQkFBeEIsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSwgRXZlbnRFbWl0dGVyLCBPdXRwdXQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuXG5pbXBvcnQgeyBBY3Rpb25zIH0gZnJvbSBcIi4uL2FjdGlvbnNcIjtcbmltcG9ydCB7IEtleVZhbHVlIH0gZnJvbSBcIi4uL3N0YXRlXCI7XG5pbXBvcnQgeyBOZ3J4Rm9ybURpcmVjdGl2ZSB9IGZyb20gXCIuL2RpcmVjdGl2ZVwiO1xuaW1wb3J0IHsgQWN0aW9uVHlwZSB9IGZyb20gXCJAbmdyeC9zdG9yZVwiO1xuXG5ARGlyZWN0aXZlKHtcbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOmRpcmVjdGl2ZS1zZWxlY3RvclxuICBzZWxlY3RvcjogXCJmb3JtW25ncnhGb3JtU3RhdGVdW25ncnhGb3Jtc0FjdGlvbl1cIixcbn0pXG5leHBvcnQgY2xhc3MgTmdyeExvY2FsRm9ybURpcmVjdGl2ZTxcbiAgVFN0YXRlVmFsdWUgZXh0ZW5kcyBLZXlWYWx1ZVxuPiBleHRlbmRzIE5ncnhGb3JtRGlyZWN0aXZlPFRTdGF0ZVZhbHVlPiB7XG4gIEBPdXRwdXQoKSBuZ3J4Rm9ybXNBY3Rpb24gPSBuZXcgRXZlbnRFbWl0dGVyPEFjdGlvblR5cGU8QWN0aW9ucz4+KCk7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIobnVsbCk7XG4gIH1cblxuICBwcm90ZWN0ZWQgZGlzcGF0Y2hBY3Rpb24oYWN0aW9uOiBBY3Rpb25UeXBlPEFjdGlvbnM+KSB7XG4gICAgdGhpcy5uZ3J4Rm9ybXNBY3Rpb24uZW1pdChhY3Rpb24pO1xuICB9XG59XG4iXX0=