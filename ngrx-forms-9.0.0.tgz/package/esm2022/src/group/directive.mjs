import { Directive, HostListener, Inject, Input, Optional, } from "@angular/core";
import { ActionsSubject } from "@ngrx/store";
import { markAsSubmittedAction } from "../actions";
import * as i0 from "@angular/core";
import * as i1 from "@ngrx/store";
export class NgrxFormDirective {
    actionsSubject;
    // tslint:disable-next-line:no-input-rename
    state;
    constructor(actionsSubject) {
        this.actionsSubject = actionsSubject;
        this.actionsSubject = actionsSubject;
    }
    dispatchAction(action) {
        if (this.actionsSubject !== null) {
            this.actionsSubject.next(action);
        }
        else {
            throw new Error("ActionsSubject must be present in order to dispatch actions!");
        }
    }
    ngOnInit() {
        if (!this.state) {
            throw new Error("The form state must not be undefined!");
        }
    }
    onSubmit(event) {
        event.preventDefault();
        if (this.state.isUnsubmitted) {
            this.dispatchAction(markAsSubmittedAction({ controlId: this.state.id }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormDirective, deps: [{ token: ActionsSubject, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxFormDirective, selector: "form:not([ngrxFormsAction])[ngrxFormState]", inputs: { state: ["ngrxFormState", "state"] }, host: { listeners: { "submit": "onSubmit($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: "form:not([ngrxFormsAction])[ngrxFormState]",
                }]
        }], ctorParameters: () => [{ type: i1.ActionsSubject, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ActionsSubject]
                }] }], propDecorators: { state: [{
                type: Input,
                args: ["ngrxFormState"]
            }], onSubmit: [{
                type: HostListener,
                args: ["submit", ["$event"]]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2dyb3VwL2RpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0wsU0FBUyxFQUNULFlBQVksRUFDWixNQUFNLEVBQ04sS0FBSyxFQUVMLFFBQVEsR0FDVCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQWMsY0FBYyxFQUFFLE1BQU0sYUFBYSxDQUFDO0FBRXpELE9BQU8sRUFBVyxxQkFBcUIsRUFBRSxNQUFNLFlBQVksQ0FBQzs7O0FBWTVELE1BQU0sT0FBTyxpQkFBaUI7SUFPbEI7SUFOViwyQ0FBMkM7SUFDbkIsS0FBSyxDQUE4QjtJQUUzRCxZQUdVLGNBQXFDO1FBQXJDLG1CQUFjLEdBQWQsY0FBYyxDQUF1QjtRQUU3QyxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztJQUN2QyxDQUFDO0lBRVMsY0FBYyxDQUFDLE1BQTJCO1FBQ2xELElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxJQUFJLEVBQUUsQ0FBQztZQUNqQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNuQyxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sSUFBSSxLQUFLLENBQ2IsOERBQThELENBQy9ELENBQUM7UUFDSixDQUFDO0lBQ0gsQ0FBQztJQUVELFFBQVE7UUFDTixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUNBQXVDLENBQUMsQ0FBQztRQUMzRCxDQUFDO0lBQ0gsQ0FBQztJQUdELFFBQVEsQ0FBQyxLQUFrQjtRQUN6QixLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxjQUFjLENBQUMscUJBQXFCLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDM0UsQ0FBQztJQUNILENBQUM7dUdBbENVLGlCQUFpQixrQkFNbEIsY0FBYzsyRkFOYixpQkFBaUI7OzJGQUFqQixpQkFBaUI7a0JBSjdCLFNBQVM7bUJBQUM7b0JBQ1QsOENBQThDO29CQUM5QyxRQUFRLEVBQUUsNENBQTRDO2lCQUN2RDs7MEJBTUksUUFBUTs7MEJBQ1IsTUFBTTsyQkFBQyxjQUFjO3lDQUpBLEtBQUs7c0JBQTVCLEtBQUs7dUJBQUMsZUFBZTtnQkEyQnRCLFFBQVE7c0JBRFAsWUFBWTt1QkFBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBEaXJlY3RpdmUsXG4gIEhvc3RMaXN0ZW5lcixcbiAgSW5qZWN0LFxuICBJbnB1dCxcbiAgT25Jbml0LFxuICBPcHRpb25hbCxcbn0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IEFjdGlvblR5cGUsIEFjdGlvbnNTdWJqZWN0IH0gZnJvbSBcIkBuZ3J4L3N0b3JlXCI7XG5cbmltcG9ydCB7IEFjdGlvbnMsIG1hcmtBc1N1Ym1pdHRlZEFjdGlvbiB9IGZyb20gXCIuLi9hY3Rpb25zXCI7XG5pbXBvcnQgeyBGb3JtR3JvdXBTdGF0ZSwgS2V5VmFsdWUgfSBmcm9tIFwiLi4vc3RhdGVcIjtcblxuLy8gdGhpcyBpbnRlcmZhY2UganVzdCBleGlzdHMgdG8gcHJldmVudCBhIGRpcmVjdCByZWZlcmVuY2UgdG9cbi8vIGBFdmVudGAgaW4gb3VyIGNvZGUsIHdoaWNoIG90aGVyd2lzZSBjYXVzZXMgaXNzdWVzIGluIE5hdGl2ZVNjcmlwdFxuLy8gYXBwbGljYXRpb25zXG5pbnRlcmZhY2UgQ3VzdG9tRXZlbnQgZXh0ZW5kcyBFdmVudCB7fVxuXG5ARGlyZWN0aXZlKHtcbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOmRpcmVjdGl2ZS1zZWxlY3RvclxuICBzZWxlY3RvcjogXCJmb3JtOm5vdChbbmdyeEZvcm1zQWN0aW9uXSlbbmdyeEZvcm1TdGF0ZV1cIixcbn0pXG5leHBvcnQgY2xhc3MgTmdyeEZvcm1EaXJlY3RpdmU8VFN0YXRlVmFsdWUgZXh0ZW5kcyBLZXlWYWx1ZT4gaW1wbGVtZW50cyBPbkluaXQge1xuICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bm8taW5wdXQtcmVuYW1lXG4gIEBJbnB1dChcIm5ncnhGb3JtU3RhdGVcIikgc3RhdGU6IEZvcm1Hcm91cFN0YXRlPFRTdGF0ZVZhbHVlPjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBAT3B0aW9uYWwoKVxuICAgIEBJbmplY3QoQWN0aW9uc1N1YmplY3QpXG4gICAgcHJpdmF0ZSBhY3Rpb25zU3ViamVjdDogQWN0aW9uc1N1YmplY3QgfCBudWxsXG4gICkge1xuICAgIHRoaXMuYWN0aW9uc1N1YmplY3QgPSBhY3Rpb25zU3ViamVjdDtcbiAgfVxuXG4gIHByb3RlY3RlZCBkaXNwYXRjaEFjdGlvbihhY3Rpb246IEFjdGlvblR5cGU8QWN0aW9ucz4pIHtcbiAgICBpZiAodGhpcy5hY3Rpb25zU3ViamVjdCAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5hY3Rpb25zU3ViamVjdC5uZXh0KGFjdGlvbik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgXCJBY3Rpb25zU3ViamVjdCBtdXN0IGJlIHByZXNlbnQgaW4gb3JkZXIgdG8gZGlzcGF0Y2ggYWN0aW9ucyFcIlxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICBpZiAoIXRoaXMuc3RhdGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoZSBmb3JtIHN0YXRlIG11c3Qgbm90IGJlIHVuZGVmaW5lZCFcIik7XG4gICAgfVxuICB9XG5cbiAgQEhvc3RMaXN0ZW5lcihcInN1Ym1pdFwiLCBbXCIkZXZlbnRcIl0pXG4gIG9uU3VibWl0KGV2ZW50OiBDdXN0b21FdmVudCkge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKHRoaXMuc3RhdGUuaXNVbnN1Ym1pdHRlZCkge1xuICAgICAgdGhpcy5kaXNwYXRjaEFjdGlvbihtYXJrQXNTdWJtaXR0ZWRBY3Rpb24oeyBjb250cm9sSWQ6IHRoaXMuc3RhdGUuaWQgfSkpO1xuICAgIH1cbiAgfVxufVxuIl19