import { NgModule } from '@angular/core';
import { NgrxFormControlDirective } from './control/directive';
import { NgrxLocalFormControlDirective } from './control/local-state-directive';
import { NgrxFormDirective } from './group/directive';
import { NgrxLocalFormDirective } from './group/local-state-directive';
import { NgrxStatusCssClassesDirective } from './status-css-classes.directive';
import { NgrxCheckboxViewAdapter } from './view-adapter/checkbox';
import { NgrxDefaultViewAdapter } from './view-adapter/default';
import { NgrxNumberViewAdapter } from './view-adapter/number';
import { NgrxFallbackSelectOption } from './view-adapter/option';
import { NgrxRadioViewAdapter } from './view-adapter/radio';
import { NgrxRangeViewAdapter } from './view-adapter/range';
import { NgrxSelectOption, NgrxSelectViewAdapter } from './view-adapter/select';
import { NgrxSelectMultipleOption, NgrxSelectMultipleViewAdapter } from './view-adapter/select-multiple';
import * as i0 from "@angular/core";
const exportsAndDeclarations = [
    NgrxFormControlDirective,
    NgrxLocalFormControlDirective,
    NgrxFormDirective,
    NgrxLocalFormDirective,
    NgrxCheckboxViewAdapter,
    NgrxDefaultViewAdapter,
    NgrxNumberViewAdapter,
    NgrxRadioViewAdapter,
    NgrxRangeViewAdapter,
    NgrxSelectMultipleOption,
    NgrxSelectMultipleViewAdapter,
    NgrxSelectOption,
    NgrxSelectViewAdapter,
    NgrxFallbackSelectOption,
    NgrxStatusCssClassesDirective,
];
export class NgrxFormsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormsModule, declarations: [NgrxFormControlDirective,
            NgrxLocalFormControlDirective,
            NgrxFormDirective,
            NgrxLocalFormDirective,
            NgrxCheckboxViewAdapter,
            NgrxDefaultViewAdapter,
            NgrxNumberViewAdapter,
            NgrxRadioViewAdapter,
            NgrxRangeViewAdapter,
            NgrxSelectMultipleOption,
            NgrxSelectMultipleViewAdapter,
            NgrxSelectOption,
            NgrxSelectViewAdapter,
            NgrxFallbackSelectOption,
            NgrxStatusCssClassesDirective], exports: [NgrxFormControlDirective,
            NgrxLocalFormControlDirective,
            NgrxFormDirective,
            NgrxLocalFormDirective,
            NgrxCheckboxViewAdapter,
            NgrxDefaultViewAdapter,
            NgrxNumberViewAdapter,
            NgrxRadioViewAdapter,
            NgrxRangeViewAdapter,
            NgrxSelectMultipleOption,
            NgrxSelectMultipleViewAdapter,
            NgrxSelectOption,
            NgrxSelectViewAdapter,
            NgrxFallbackSelectOption,
            NgrxStatusCssClassesDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormsModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: exportsAndDeclarations,
                    exports: exportsAndDeclarations,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL21vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRXpDLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQy9ELE9BQU8sRUFBRSw2QkFBNkIsRUFBRSxNQUFNLGlDQUFpQyxDQUFDO0FBQ2hGLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3RELE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxNQUFNLCtCQUErQixDQUFDO0FBQ3ZFLE9BQU8sRUFBRSw2QkFBNkIsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQy9FLE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzlELE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ2pFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQzVELE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQzVELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxxQkFBcUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ2hGLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSw2QkFBNkIsRUFBRSxNQUFNLGdDQUFnQyxDQUFDOztBQUV6RyxNQUFNLHNCQUFzQixHQUFHO0lBQzdCLHdCQUF3QjtJQUN4Qiw2QkFBNkI7SUFDN0IsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0Qix1QkFBdUI7SUFDdkIsc0JBQXNCO0lBQ3RCLHFCQUFxQjtJQUNyQixvQkFBb0I7SUFDcEIsb0JBQW9CO0lBQ3BCLHdCQUF3QjtJQUN4Qiw2QkFBNkI7SUFDN0IsZ0JBQWdCO0lBQ2hCLHFCQUFxQjtJQUNyQix3QkFBd0I7SUFDeEIsNkJBQTZCO0NBQzlCLENBQUM7QUFNRixNQUFNLE9BQU8sZUFBZTt1R0FBZixlQUFlO3dHQUFmLGVBQWUsaUJBckIxQix3QkFBd0I7WUFDeEIsNkJBQTZCO1lBQzdCLGlCQUFpQjtZQUNqQixzQkFBc0I7WUFDdEIsdUJBQXVCO1lBQ3ZCLHNCQUFzQjtZQUN0QixxQkFBcUI7WUFDckIsb0JBQW9CO1lBQ3BCLG9CQUFvQjtZQUNwQix3QkFBd0I7WUFDeEIsNkJBQTZCO1lBQzdCLGdCQUFnQjtZQUNoQixxQkFBcUI7WUFDckIsd0JBQXdCO1lBQ3hCLDZCQUE2QixhQWQ3Qix3QkFBd0I7WUFDeEIsNkJBQTZCO1lBQzdCLGlCQUFpQjtZQUNqQixzQkFBc0I7WUFDdEIsdUJBQXVCO1lBQ3ZCLHNCQUFzQjtZQUN0QixxQkFBcUI7WUFDckIsb0JBQW9CO1lBQ3BCLG9CQUFvQjtZQUNwQix3QkFBd0I7WUFDeEIsNkJBQTZCO1lBQzdCLGdCQUFnQjtZQUNoQixxQkFBcUI7WUFDckIsd0JBQXdCO1lBQ3hCLDZCQUE2Qjt3R0FPbEIsZUFBZTs7MkZBQWYsZUFBZTtrQkFKM0IsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUUsc0JBQXNCO29CQUNwQyxPQUFPLEVBQUUsc0JBQXNCO2lCQUNoQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IE5ncnhGb3JtQ29udHJvbERpcmVjdGl2ZSB9IGZyb20gJy4vY29udHJvbC9kaXJlY3RpdmUnO1xuaW1wb3J0IHsgTmdyeExvY2FsRm9ybUNvbnRyb2xEaXJlY3RpdmUgfSBmcm9tICcuL2NvbnRyb2wvbG9jYWwtc3RhdGUtZGlyZWN0aXZlJztcbmltcG9ydCB7IE5ncnhGb3JtRGlyZWN0aXZlIH0gZnJvbSAnLi9ncm91cC9kaXJlY3RpdmUnO1xuaW1wb3J0IHsgTmdyeExvY2FsRm9ybURpcmVjdGl2ZSB9IGZyb20gJy4vZ3JvdXAvbG9jYWwtc3RhdGUtZGlyZWN0aXZlJztcbmltcG9ydCB7IE5ncnhTdGF0dXNDc3NDbGFzc2VzRGlyZWN0aXZlIH0gZnJvbSAnLi9zdGF0dXMtY3NzLWNsYXNzZXMuZGlyZWN0aXZlJztcbmltcG9ydCB7IE5ncnhDaGVja2JveFZpZXdBZGFwdGVyIH0gZnJvbSAnLi92aWV3LWFkYXB0ZXIvY2hlY2tib3gnO1xuaW1wb3J0IHsgTmdyeERlZmF1bHRWaWV3QWRhcHRlciB9IGZyb20gJy4vdmlldy1hZGFwdGVyL2RlZmF1bHQnO1xuaW1wb3J0IHsgTmdyeE51bWJlclZpZXdBZGFwdGVyIH0gZnJvbSAnLi92aWV3LWFkYXB0ZXIvbnVtYmVyJztcbmltcG9ydCB7IE5ncnhGYWxsYmFja1NlbGVjdE9wdGlvbiB9IGZyb20gJy4vdmlldy1hZGFwdGVyL29wdGlvbic7XG5pbXBvcnQgeyBOZ3J4UmFkaW9WaWV3QWRhcHRlciB9IGZyb20gJy4vdmlldy1hZGFwdGVyL3JhZGlvJztcbmltcG9ydCB7IE5ncnhSYW5nZVZpZXdBZGFwdGVyIH0gZnJvbSAnLi92aWV3LWFkYXB0ZXIvcmFuZ2UnO1xuaW1wb3J0IHsgTmdyeFNlbGVjdE9wdGlvbiwgTmdyeFNlbGVjdFZpZXdBZGFwdGVyIH0gZnJvbSAnLi92aWV3LWFkYXB0ZXIvc2VsZWN0JztcbmltcG9ydCB7IE5ncnhTZWxlY3RNdWx0aXBsZU9wdGlvbiwgTmdyeFNlbGVjdE11bHRpcGxlVmlld0FkYXB0ZXIgfSBmcm9tICcuL3ZpZXctYWRhcHRlci9zZWxlY3QtbXVsdGlwbGUnO1xuXG5jb25zdCBleHBvcnRzQW5kRGVjbGFyYXRpb25zID0gW1xuICBOZ3J4Rm9ybUNvbnRyb2xEaXJlY3RpdmUsXG4gIE5ncnhMb2NhbEZvcm1Db250cm9sRGlyZWN0aXZlLFxuICBOZ3J4Rm9ybURpcmVjdGl2ZSxcbiAgTmdyeExvY2FsRm9ybURpcmVjdGl2ZSxcbiAgTmdyeENoZWNrYm94Vmlld0FkYXB0ZXIsXG4gIE5ncnhEZWZhdWx0Vmlld0FkYXB0ZXIsXG4gIE5ncnhOdW1iZXJWaWV3QWRhcHRlcixcbiAgTmdyeFJhZGlvVmlld0FkYXB0ZXIsXG4gIE5ncnhSYW5nZVZpZXdBZGFwdGVyLFxuICBOZ3J4U2VsZWN0TXVsdGlwbGVPcHRpb24sXG4gIE5ncnhTZWxlY3RNdWx0aXBsZVZpZXdBZGFwdGVyLFxuICBOZ3J4U2VsZWN0T3B0aW9uLFxuICBOZ3J4U2VsZWN0Vmlld0FkYXB0ZXIsXG4gIE5ncnhGYWxsYmFja1NlbGVjdE9wdGlvbixcbiAgTmdyeFN0YXR1c0Nzc0NsYXNzZXNEaXJlY3RpdmUsXG5dO1xuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IGV4cG9ydHNBbmREZWNsYXJhdGlvbnMsXG4gIGV4cG9ydHM6IGV4cG9ydHNBbmREZWNsYXJhdGlvbnMsXG59KVxuZXhwb3J0IGNsYXNzIE5ncnhGb3Jtc01vZHVsZSB7IH1cbiJdfQ==