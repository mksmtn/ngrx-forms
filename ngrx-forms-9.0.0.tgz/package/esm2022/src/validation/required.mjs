import { unbox } from "../boxing";
/**
 * A validation function that requires the value to be non-`undefined`, non-'null',
 * and non-empty.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  required: {
    actual: T | null | undefined;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  name: validate(required),
})
```
 */
export function required(value) {
    value = unbox(value);
    if (value !== undefined && value !== null && value.length !== 0) {
        return {};
    }
    return {
        required: {
            actual: value,
        },
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVxdWlyZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdmFsaWRhdGlvbi9yZXF1aXJlZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQVMsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBT3pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBc0JHO0FBQ0gsTUFBTSxVQUFVLFFBQVEsQ0FDdEIsS0FBc0M7SUFFdEMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQXlCLENBQUM7SUFFN0MsSUFBSSxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUssS0FBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUN6RSxPQUFPLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFRCxPQUFPO1FBQ0wsUUFBUSxFQUFFO1lBQ1IsTUFBTSxFQUFFLEtBQUs7U0FDZDtLQUNGLENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94ZWQsIHVuYm94IH0gZnJvbSBcIi4uL2JveGluZ1wiO1xuaW1wb3J0IHsgVmFsaWRhdGlvbkVycm9ycyB9IGZyb20gXCIuLi9zdGF0ZVwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIFJlcXVpcmVkVmFsaWRhdGlvbkVycm9yPFQ+IHtcbiAgYWN0dWFsOiBUIHwgbnVsbCB8IHVuZGVmaW5lZDtcbn1cblxuLyoqXG4gKiBBIHZhbGlkYXRpb24gZnVuY3Rpb24gdGhhdCByZXF1aXJlcyB0aGUgdmFsdWUgdG8gYmUgbm9uLWB1bmRlZmluZWRgLCBub24tJ251bGwnLFxuICogYW5kIG5vbi1lbXB0eS5cbiAqXG4gKiBUaGUgdmFsaWRhdGlvbiBlcnJvciByZXR1cm5lZCBieSB0aGlzIHZhbGlkYXRpb24gZnVuY3Rpb24gaGFzIHRoZSBmb2xsb3dpbmcgc2hhcGU6XG4gKlxuYGBgdHlwZXNjcmlwdFxue1xuICByZXF1aXJlZDoge1xuICAgIGFjdHVhbDogVCB8IG51bGwgfCB1bmRlZmluZWQ7XG4gIH07XG59XG5gYGBcbiAqXG4gKiBVc3VhbGx5IHlvdSB3b3VsZCB1c2UgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIGB2YWxpZGF0ZWBcbiAqIHVwZGF0ZSBmdW5jdGlvbiB0byBwZXJmb3JtIHN5bmNocm9ub3VzIHZhbGlkYXRpb24gaW4geW91ciByZWR1Y2VyOlxuICpcbmBgYHR5cGVzY3JpcHRcbnVwZGF0ZUdyb3VwPE15Rm9ybVZhbHVlPih7XG4gIG5hbWU6IHZhbGlkYXRlKHJlcXVpcmVkKSxcbn0pXG5gYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlcXVpcmVkPFQ+KFxuICB2YWx1ZTogVCB8IEJveGVkPFQ+IHwgbnVsbCB8IHVuZGVmaW5lZFxuKTogVmFsaWRhdGlvbkVycm9ycyB7XG4gIHZhbHVlID0gdW5ib3godmFsdWUpIGFzIFQgfCBudWxsIHwgdW5kZWZpbmVkO1xuXG4gIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSBudWxsICYmICh2YWx1ZSBhcyBhbnkpLmxlbmd0aCAhPT0gMCkge1xuICAgIHJldHVybiB7fTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgcmVxdWlyZWQ6IHtcbiAgICAgIGFjdHVhbDogdmFsdWUsXG4gICAgfSxcbiAgfTtcbn1cbiJdfQ==