import { unbox } from "../boxing";
/**
 * A validation function that requires a `string` or `array` value to have a maximum length.
 * Considers `null` and `undefined` as valid. Combine this function with the `required`
 * validation function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  maxLength: {
    maxLength: number;
    value: string;
    actualLength: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  name: validate(maxLength(10)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
export function maxLength(maxLengthParam) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (maxLengthParam === null || maxLengthParam === undefined) {
        throw new Error(`The maxLength Validation function requires the maxLength parameter to be a non-null number, got ${maxLengthParam}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined) {
            return {};
        }
        const length = value.length;
        if (length <= maxLengthParam) {
            return {};
        }
        return {
            maxLength: {
                maxLength: maxLengthParam,
                value: value,
                actualLength: length,
            },
        };
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF4LWxlbmd0aC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy92YWxpZGF0aW9uL21heC1sZW5ndGgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFTLEtBQUssRUFBRSxNQUFNLFdBQVcsQ0FBQztBQVN6Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTRCRztBQUNILE1BQU0sVUFBVSxTQUFTLENBQUMsY0FBc0I7SUFDOUMsaUdBQWlHO0lBQ2pHLElBQUksY0FBYyxLQUFLLElBQUksSUFBSSxjQUFjLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDNUQsTUFBTSxJQUFJLEtBQUssQ0FDYixtR0FBbUcsY0FBYyxHQUFHLENBQ3JILENBQUM7SUFDSixDQUFDO0lBRUQsT0FBTyxDQUdMLEtBQVEsRUFDVSxFQUFFO1FBQ3BCLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFckIsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUMxQyxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFFRCxNQUFNLE1BQU0sR0FBSSxLQUF3QixDQUFDLE1BQU0sQ0FBQztRQUVoRCxJQUFJLE1BQU0sSUFBSSxjQUFjLEVBQUUsQ0FBQztZQUM3QixPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFFRCxPQUFPO1lBQ0wsU0FBUyxFQUFFO2dCQUNULFNBQVMsRUFBRSxjQUFjO2dCQUN6QixLQUFLLEVBQUUsS0FBZTtnQkFDdEIsWUFBWSxFQUFFLE1BQU07YUFDckI7U0FDRixDQUFDO0lBQ0osQ0FBQyxDQUFDO0FBQ0osQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJveGVkLCB1bmJveCB9IGZyb20gXCIuLi9ib3hpbmdcIjtcbmltcG9ydCB7IFZhbGlkYXRpb25FcnJvcnMgfSBmcm9tIFwiLi4vc3RhdGVcIjtcblxuZXhwb3J0IGludGVyZmFjZSBNYXhMZW5ndGhWYWxpZGF0aW9uRXJyb3Ige1xuICBtYXhMZW5ndGg6IG51bWJlcjtcbiAgdmFsdWU6IHN0cmluZyB8IGFueVtdO1xuICBhY3R1YWxMZW5ndGg6IG51bWJlcjtcbn1cblxuLyoqXG4gKiBBIHZhbGlkYXRpb24gZnVuY3Rpb24gdGhhdCByZXF1aXJlcyBhIGBzdHJpbmdgIG9yIGBhcnJheWAgdmFsdWUgdG8gaGF2ZSBhIG1heGltdW0gbGVuZ3RoLlxuICogQ29uc2lkZXJzIGBudWxsYCBhbmQgYHVuZGVmaW5lZGAgYXMgdmFsaWQuIENvbWJpbmUgdGhpcyBmdW5jdGlvbiB3aXRoIHRoZSBgcmVxdWlyZWRgXG4gKiB2YWxpZGF0aW9uIGZ1bmN0aW9uIGlmIGBudWxsYCBvciBgdW5kZWZpbmVkYCBzaG91bGQgYmUgY29uc2lkZXJlZCBpbnZhbGlkLlxuICpcbiAqIFRoZSB2YWxpZGF0aW9uIGVycm9yIHJldHVybmVkIGJ5IHRoaXMgdmFsaWRhdGlvbiBmdW5jdGlvbiBoYXMgdGhlIGZvbGxvd2luZyBzaGFwZTpcbiAqXG5gYGB0eXBlc2NyaXB0XG57XG4gIG1heExlbmd0aDoge1xuICAgIG1heExlbmd0aDogbnVtYmVyO1xuICAgIHZhbHVlOiBzdHJpbmc7XG4gICAgYWN0dWFsTGVuZ3RoOiBudW1iZXI7XG4gIH07XG59XG5gYGBcbiAqXG4gKiBVc3VhbGx5IHlvdSB3b3VsZCB1c2UgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIGB2YWxpZGF0ZWBcbiAqIHVwZGF0ZSBmdW5jdGlvbiB0byBwZXJmb3JtIHN5bmNocm9ub3VzIHZhbGlkYXRpb24gaW4geW91ciByZWR1Y2VyOlxuICpcbmBgYHR5cGVzY3JpcHRcbnVwZGF0ZUdyb3VwPE15Rm9ybVZhbHVlPih7XG4gIG5hbWU6IHZhbGlkYXRlKG1heExlbmd0aCgxMCkpLFxufSlcbmBgYFxuICpcbiAqIE5vdGUgdGhhdCB0aGlzIGZ1bmN0aW9uIGlzIGdlbmVyaWMgdG8gYWxsb3cgdGhlIGNvbXBpbGVyIHRvIHByb3Blcmx5IGluZmVyIHRoZSB0eXBlXG4gKiBvZiB0aGUgYHZhbGlkYXRlYCBmdW5jdGlvbiBmb3IgYm90aCBvcHRpb25hbCBhbmQgbm9uLW9wdGlvbmFsIGNvbnRyb2xzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWF4TGVuZ3RoKG1heExlbmd0aFBhcmFtOiBudW1iZXIpIHtcbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOnN0cmljdC10eXBlLXByZWRpY2F0ZXMgKGd1YXJkIGZvciB1c2VycyB3aXRob3V0IHN0cmljdCB0eXBlIGNoZWNraW5nKVxuICBpZiAobWF4TGVuZ3RoUGFyYW0gPT09IG51bGwgfHwgbWF4TGVuZ3RoUGFyYW0gPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGBUaGUgbWF4TGVuZ3RoIFZhbGlkYXRpb24gZnVuY3Rpb24gcmVxdWlyZXMgdGhlIG1heExlbmd0aCBwYXJhbWV0ZXIgdG8gYmUgYSBub24tbnVsbCBudW1iZXIsIGdvdCAke21heExlbmd0aFBhcmFtfSFgXG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiA8XG4gICAgVCBleHRlbmRzIHN0cmluZyB8IEJveGVkPHN0cmluZz4gfCBhbnlbXSB8IEJveGVkPGFueVtdPiB8IG51bGwgfCB1bmRlZmluZWRcbiAgPihcbiAgICB2YWx1ZTogVFxuICApOiBWYWxpZGF0aW9uRXJyb3JzID0+IHtcbiAgICB2YWx1ZSA9IHVuYm94KHZhbHVlKTtcblxuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgY29uc3QgbGVuZ3RoID0gKHZhbHVlIGFzIHN0cmluZyB8IGFueVtdKS5sZW5ndGg7XG5cbiAgICBpZiAobGVuZ3RoIDw9IG1heExlbmd0aFBhcmFtKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG1heExlbmd0aDoge1xuICAgICAgICBtYXhMZW5ndGg6IG1heExlbmd0aFBhcmFtLFxuICAgICAgICB2YWx1ZTogdmFsdWUgYXMgc3RyaW5nLFxuICAgICAgICBhY3R1YWxMZW5ndGg6IGxlbmd0aCxcbiAgICAgIH0sXG4gICAgfTtcbiAgfTtcbn1cbiJdfQ==