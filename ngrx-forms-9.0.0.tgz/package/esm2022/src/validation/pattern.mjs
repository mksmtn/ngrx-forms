import { unbox } from "../boxing";
/**
 * A validation function that requires a value to match a regex.
 * Considers `null`, `undefined`, and `''` as valid. Combine this function with the
 * `required` validation function if these values should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  pattern: {
    pattern: string;
    actual: string;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  numberWithPeriodsOrCommas: validate(pattern(/^[0-9.,]+$/)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
export function pattern(patternParam) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (patternParam === null || patternParam === undefined) {
        throw new Error(`The pattern Validation function requires the pattern parameter to be a non-null string or regular expression, got ${patternParam}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null ||
            value === undefined ||
            value.length === 0) {
            return {};
        }
        if (patternParam.test(value)) {
            return {};
        }
        return {
            pattern: {
                pattern: patternParam.toString(),
                actual: value,
            },
        };
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGF0dGVybi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy92YWxpZGF0aW9uL3BhdHRlcm4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFTLEtBQUssRUFBRSxNQUFNLFdBQVcsQ0FBQztBQVF6Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBMkJHO0FBQ0gsTUFBTSxVQUFVLE9BQU8sQ0FBQyxZQUFvQjtJQUMxQyxpR0FBaUc7SUFDakcsSUFBSSxZQUFZLEtBQUssSUFBSSxJQUFJLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUN4RCxNQUFNLElBQUksS0FBSyxDQUNiLHFIQUFxSCxZQUFZLEdBQUcsQ0FDckksQ0FBQztJQUNKLENBQUM7SUFFRCxPQUFPLENBQ0wsS0FBUSxFQUNVLEVBQUU7UUFDcEIsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQW1DLENBQUM7UUFFdkQsSUFDRSxLQUFLLEtBQUssSUFBSTtZQUNkLEtBQUssS0FBSyxTQUFTO1lBQ2xCLEtBQWdCLENBQUMsTUFBTSxLQUFLLENBQUMsRUFDOUIsQ0FBQztZQUNELE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQztRQUVELElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFlLENBQUMsRUFBRSxDQUFDO1lBQ3ZDLE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQztRQUVELE9BQU87WUFDTCxPQUFPLEVBQUU7Z0JBQ1AsT0FBTyxFQUFFLFlBQVksQ0FBQyxRQUFRLEVBQUU7Z0JBQ2hDLE1BQU0sRUFBRSxLQUFlO2FBQ3hCO1NBQ0YsQ0FBQztJQUNKLENBQUMsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3hlZCwgdW5ib3ggfSBmcm9tIFwiLi4vYm94aW5nXCI7XG5pbXBvcnQgeyBWYWxpZGF0aW9uRXJyb3JzIH0gZnJvbSBcIi4uL3N0YXRlXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGF0dGVyblZhbGlkYXRpb25FcnJvciB7XG4gIHBhdHRlcm46IHN0cmluZztcbiAgYWN0dWFsOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQSB2YWxpZGF0aW9uIGZ1bmN0aW9uIHRoYXQgcmVxdWlyZXMgYSB2YWx1ZSB0byBtYXRjaCBhIHJlZ2V4LlxuICogQ29uc2lkZXJzIGBudWxsYCwgYHVuZGVmaW5lZGAsIGFuZCBgJydgIGFzIHZhbGlkLiBDb21iaW5lIHRoaXMgZnVuY3Rpb24gd2l0aCB0aGVcbiAqIGByZXF1aXJlZGAgdmFsaWRhdGlvbiBmdW5jdGlvbiBpZiB0aGVzZSB2YWx1ZXMgc2hvdWxkIGJlIGNvbnNpZGVyZWQgaW52YWxpZC5cbiAqXG4gKiBUaGUgdmFsaWRhdGlvbiBlcnJvciByZXR1cm5lZCBieSB0aGlzIHZhbGlkYXRpb24gZnVuY3Rpb24gaGFzIHRoZSBmb2xsb3dpbmcgc2hhcGU6XG4gKlxuYGBgdHlwZXNjcmlwdFxue1xuICBwYXR0ZXJuOiB7XG4gICAgcGF0dGVybjogc3RyaW5nO1xuICAgIGFjdHVhbDogc3RyaW5nO1xuICB9O1xufVxuYGBgXG4gKlxuICogVXN1YWxseSB5b3Ugd291bGQgdXNlIHRoaXMgdmFsaWRhdGlvbiBmdW5jdGlvbiBpbiBjb25qdW5jdGlvbiB3aXRoIHRoZSBgdmFsaWRhdGVgXG4gKiB1cGRhdGUgZnVuY3Rpb24gdG8gcGVyZm9ybSBzeW5jaHJvbm91cyB2YWxpZGF0aW9uIGluIHlvdXIgcmVkdWNlcjpcbiAqXG5gYGB0eXBlc2NyaXB0XG51cGRhdGVHcm91cDxNeUZvcm1WYWx1ZT4oe1xuICBudW1iZXJXaXRoUGVyaW9kc09yQ29tbWFzOiB2YWxpZGF0ZShwYXR0ZXJuKC9eWzAtOS4sXSskLykpLFxufSlcbmBgYFxuICpcbiAqIE5vdGUgdGhhdCB0aGlzIGZ1bmN0aW9uIGlzIGdlbmVyaWMgdG8gYWxsb3cgdGhlIGNvbXBpbGVyIHRvIHByb3Blcmx5IGluZmVyIHRoZSB0eXBlXG4gKiBvZiB0aGUgYHZhbGlkYXRlYCBmdW5jdGlvbiBmb3IgYm90aCBvcHRpb25hbCBhbmQgbm9uLW9wdGlvbmFsIGNvbnRyb2xzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGF0dGVybihwYXR0ZXJuUGFyYW06IFJlZ0V4cCkge1xuICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6c3RyaWN0LXR5cGUtcHJlZGljYXRlcyAoZ3VhcmQgZm9yIHVzZXJzIHdpdGhvdXQgc3RyaWN0IHR5cGUgY2hlY2tpbmcpXG4gIGlmIChwYXR0ZXJuUGFyYW0gPT09IG51bGwgfHwgcGF0dGVyblBhcmFtID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBgVGhlIHBhdHRlcm4gVmFsaWRhdGlvbiBmdW5jdGlvbiByZXF1aXJlcyB0aGUgcGF0dGVybiBwYXJhbWV0ZXIgdG8gYmUgYSBub24tbnVsbCBzdHJpbmcgb3IgcmVndWxhciBleHByZXNzaW9uLCBnb3QgJHtwYXR0ZXJuUGFyYW19IWBcbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIDxUIGV4dGVuZHMgc3RyaW5nIHwgQm94ZWQ8c3RyaW5nPiB8IG51bGwgfCB1bmRlZmluZWQ+KFxuICAgIHZhbHVlOiBUXG4gICk6IFZhbGlkYXRpb25FcnJvcnMgPT4ge1xuICAgIHZhbHVlID0gdW5ib3godmFsdWUpIGFzIHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQgYXMgVDtcblxuICAgIGlmIChcbiAgICAgIHZhbHVlID09PSBudWxsIHx8XG4gICAgICB2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8XG4gICAgICAodmFsdWUgYXMgc3RyaW5nKS5sZW5ndGggPT09IDBcbiAgICApIHtcbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG5cbiAgICBpZiAocGF0dGVyblBhcmFtLnRlc3QodmFsdWUgYXMgc3RyaW5nKSkge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBwYXR0ZXJuOiB7XG4gICAgICAgIHBhdHRlcm46IHBhdHRlcm5QYXJhbS50b1N0cmluZygpLFxuICAgICAgICBhY3R1YWw6IHZhbHVlIGFzIHN0cmluZyxcbiAgICAgIH0sXG4gICAgfTtcbiAgfTtcbn1cbiJdfQ==