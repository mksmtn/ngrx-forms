import { unbox } from "../boxing";
/**
 * A validation function that requires the value to be strictly equal (i.e. `===`)
 * to another value.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  equalTo: {
    comparand: T;
    actual: T;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  name: validate(equalTo('John Doe')),
})
```
 */
export function equalTo(comparand) {
    return (value) => {
        value = unbox(value);
        if (value === comparand) {
            return {};
        }
        return {
            equalTo: {
                comparand,
                actual: value,
            },
        };
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXF1YWwtdG8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdmFsaWRhdGlvbi9lcXVhbC10by50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQVMsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBUXpDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXVCRztBQUNILE1BQU0sVUFBVSxPQUFPLENBQUksU0FBWTtJQUNyQyxPQUFPLENBQThCLEtBQVMsRUFBb0IsRUFBRTtRQUNsRSxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBWSxDQUFDO1FBRWhDLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3hCLE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQztRQUVELE9BQU87WUFDTCxPQUFPLEVBQUU7Z0JBQ1AsU0FBUztnQkFDVCxNQUFNLEVBQUUsS0FBSzthQUNkO1NBQ0YsQ0FBQztJQUNKLENBQUMsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3hlZCwgdW5ib3ggfSBmcm9tIFwiLi4vYm94aW5nXCI7XG5pbXBvcnQgeyBWYWxpZGF0aW9uRXJyb3JzIH0gZnJvbSBcIi4uL3N0YXRlXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRXF1YWxUb1ZhbGlkYXRpb25FcnJvcjxUPiB7XG4gIGNvbXBhcmFuZDogVDtcbiAgYWN0dWFsOiBUO1xufVxuXG4vKipcbiAqIEEgdmFsaWRhdGlvbiBmdW5jdGlvbiB0aGF0IHJlcXVpcmVzIHRoZSB2YWx1ZSB0byBiZSBzdHJpY3RseSBlcXVhbCAoaS5lLiBgPT09YClcbiAqIHRvIGFub3RoZXIgdmFsdWUuXG4gKlxuICogVGhlIHZhbGlkYXRpb24gZXJyb3IgcmV0dXJuZWQgYnkgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGhhcyB0aGUgZm9sbG93aW5nIHNoYXBlOlxuICpcbmBgYHR5cGVzY3JpcHRcbntcbiAgZXF1YWxUbzoge1xuICAgIGNvbXBhcmFuZDogVDtcbiAgICBhY3R1YWw6IFQ7XG4gIH07XG59XG5gYGBcbiAqXG4gKiBVc3VhbGx5IHlvdSB3b3VsZCB1c2UgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIGB2YWxpZGF0ZWBcbiAqIHVwZGF0ZSBmdW5jdGlvbiB0byBwZXJmb3JtIHN5bmNocm9ub3VzIHZhbGlkYXRpb24gaW4geW91ciByZWR1Y2VyOlxuICpcbmBgYHR5cGVzY3JpcHRcbnVwZGF0ZUdyb3VwPE15Rm9ybVZhbHVlPih7XG4gIG5hbWU6IHZhbGlkYXRlKGVxdWFsVG8oJ0pvaG4gRG9lJykpLFxufSlcbmBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZXF1YWxUbzxUPihjb21wYXJhbmQ6IFQpIHtcbiAgcmV0dXJuIDxUViBleHRlbmRzIFQgfCBCb3hlZDxUPiA9IFQ+KHZhbHVlOiBUVik6IFZhbGlkYXRpb25FcnJvcnMgPT4ge1xuICAgIHZhbHVlID0gdW5ib3godmFsdWUpIGFzIFQgYXMgVFY7XG5cbiAgICBpZiAodmFsdWUgPT09IGNvbXBhcmFuZCkge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBlcXVhbFRvOiB7XG4gICAgICAgIGNvbXBhcmFuZCxcbiAgICAgICAgYWN0dWFsOiB2YWx1ZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgfTtcbn1cbiJdfQ==