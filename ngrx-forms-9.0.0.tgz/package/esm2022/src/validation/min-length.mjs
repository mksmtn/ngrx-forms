import { unbox } from "../boxing";
/**
 * A validation function that requires a `string` or `array` value to have a minimum length.
 * Considers `null`, `undefined`, empty strings and empty arrays as valid. Combine this
 * function with the `required` validation function if these values should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  minLength: {
    minLength: number;
    value: string;
    actualLength: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  password: validate(minLength(8)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
export function minLength(minLengthParam) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (minLengthParam === null || minLengthParam === undefined) {
        throw new Error(`The minLength Validation function requires the minLength parameter to be a non-null number, got ${minLengthParam}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined) {
            return {};
        }
        const length = value.length;
        if (length === 0) {
            return {}; // don't validate empty values to allow optional controls
        }
        if (length >= minLengthParam) {
            return {};
        }
        return {
            minLength: {
                minLength: minLengthParam,
                value: value,
                actualLength: length,
            },
        };
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWluLWxlbmd0aC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy92YWxpZGF0aW9uL21pbi1sZW5ndGgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFTLEtBQUssRUFBRSxNQUFNLFdBQVcsQ0FBQztBQVN6Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTRCRztBQUNILE1BQU0sVUFBVSxTQUFTLENBQUMsY0FBc0I7SUFDOUMsaUdBQWlHO0lBQ2pHLElBQUksY0FBYyxLQUFLLElBQUksSUFBSSxjQUFjLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDNUQsTUFBTSxJQUFJLEtBQUssQ0FDYixtR0FBbUcsY0FBYyxHQUFHLENBQ3JILENBQUM7SUFDSixDQUFDO0lBRUQsT0FBTyxDQUdMLEtBQVEsRUFDVSxFQUFFO1FBQ3BCLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFckIsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUMxQyxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFFRCxNQUFNLE1BQU0sR0FBSSxLQUF3QixDQUFDLE1BQU0sQ0FBQztRQUVoRCxJQUFJLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNqQixPQUFPLEVBQUUsQ0FBQyxDQUFDLHlEQUF5RDtRQUN0RSxDQUFDO1FBRUQsSUFBSSxNQUFNLElBQUksY0FBYyxFQUFFLENBQUM7WUFDN0IsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDO1FBRUQsT0FBTztZQUNMLFNBQVMsRUFBRTtnQkFDVCxTQUFTLEVBQUUsY0FBYztnQkFDekIsS0FBSyxFQUFFLEtBQWU7Z0JBQ3RCLFlBQVksRUFBRSxNQUFNO2FBQ3JCO1NBQ0YsQ0FBQztJQUNKLENBQUMsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3hlZCwgdW5ib3ggfSBmcm9tIFwiLi4vYm94aW5nXCI7XG5pbXBvcnQgeyBWYWxpZGF0aW9uRXJyb3JzIH0gZnJvbSBcIi4uL3N0YXRlXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWluTGVuZ3RoVmFsaWRhdGlvbkVycm9yIHtcbiAgbWluTGVuZ3RoOiBudW1iZXI7XG4gIHZhbHVlOiBzdHJpbmcgfCBhbnlbXTtcbiAgYWN0dWFsTGVuZ3RoOiBudW1iZXI7XG59XG5cbi8qKlxuICogQSB2YWxpZGF0aW9uIGZ1bmN0aW9uIHRoYXQgcmVxdWlyZXMgYSBgc3RyaW5nYCBvciBgYXJyYXlgIHZhbHVlIHRvIGhhdmUgYSBtaW5pbXVtIGxlbmd0aC5cbiAqIENvbnNpZGVycyBgbnVsbGAsIGB1bmRlZmluZWRgLCBlbXB0eSBzdHJpbmdzIGFuZCBlbXB0eSBhcnJheXMgYXMgdmFsaWQuIENvbWJpbmUgdGhpc1xuICogZnVuY3Rpb24gd2l0aCB0aGUgYHJlcXVpcmVkYCB2YWxpZGF0aW9uIGZ1bmN0aW9uIGlmIHRoZXNlIHZhbHVlcyBzaG91bGQgYmUgY29uc2lkZXJlZCBpbnZhbGlkLlxuICpcbiAqIFRoZSB2YWxpZGF0aW9uIGVycm9yIHJldHVybmVkIGJ5IHRoaXMgdmFsaWRhdGlvbiBmdW5jdGlvbiBoYXMgdGhlIGZvbGxvd2luZyBzaGFwZTpcbiAqXG5gYGB0eXBlc2NyaXB0XG57XG4gIG1pbkxlbmd0aDoge1xuICAgIG1pbkxlbmd0aDogbnVtYmVyO1xuICAgIHZhbHVlOiBzdHJpbmc7XG4gICAgYWN0dWFsTGVuZ3RoOiBudW1iZXI7XG4gIH07XG59XG5gYGBcbiAqXG4gKiBVc3VhbGx5IHlvdSB3b3VsZCB1c2UgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIGB2YWxpZGF0ZWBcbiAqIHVwZGF0ZSBmdW5jdGlvbiB0byBwZXJmb3JtIHN5bmNocm9ub3VzIHZhbGlkYXRpb24gaW4geW91ciByZWR1Y2VyOlxuICpcbmBgYHR5cGVzY3JpcHRcbnVwZGF0ZUdyb3VwPE15Rm9ybVZhbHVlPih7XG4gIHBhc3N3b3JkOiB2YWxpZGF0ZShtaW5MZW5ndGgoOCkpLFxufSlcbmBgYFxuICpcbiAqIE5vdGUgdGhhdCB0aGlzIGZ1bmN0aW9uIGlzIGdlbmVyaWMgdG8gYWxsb3cgdGhlIGNvbXBpbGVyIHRvIHByb3Blcmx5IGluZmVyIHRoZSB0eXBlXG4gKiBvZiB0aGUgYHZhbGlkYXRlYCBmdW5jdGlvbiBmb3IgYm90aCBvcHRpb25hbCBhbmQgbm9uLW9wdGlvbmFsIGNvbnRyb2xzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWluTGVuZ3RoKG1pbkxlbmd0aFBhcmFtOiBudW1iZXIpIHtcbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOnN0cmljdC10eXBlLXByZWRpY2F0ZXMgKGd1YXJkIGZvciB1c2VycyB3aXRob3V0IHN0cmljdCB0eXBlIGNoZWNraW5nKVxuICBpZiAobWluTGVuZ3RoUGFyYW0gPT09IG51bGwgfHwgbWluTGVuZ3RoUGFyYW0gPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGBUaGUgbWluTGVuZ3RoIFZhbGlkYXRpb24gZnVuY3Rpb24gcmVxdWlyZXMgdGhlIG1pbkxlbmd0aCBwYXJhbWV0ZXIgdG8gYmUgYSBub24tbnVsbCBudW1iZXIsIGdvdCAke21pbkxlbmd0aFBhcmFtfSFgXG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiA8XG4gICAgVCBleHRlbmRzIHN0cmluZyB8IEJveGVkPHN0cmluZz4gfCBhbnlbXSB8IEJveGVkPGFueVtdPiB8IG51bGwgfCB1bmRlZmluZWRcbiAgPihcbiAgICB2YWx1ZTogVFxuICApOiBWYWxpZGF0aW9uRXJyb3JzID0+IHtcbiAgICB2YWx1ZSA9IHVuYm94KHZhbHVlKTtcblxuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgY29uc3QgbGVuZ3RoID0gKHZhbHVlIGFzIHN0cmluZyB8IGFueVtdKS5sZW5ndGg7XG5cbiAgICBpZiAobGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4ge307IC8vIGRvbid0IHZhbGlkYXRlIGVtcHR5IHZhbHVlcyB0byBhbGxvdyBvcHRpb25hbCBjb250cm9sc1xuICAgIH1cblxuICAgIGlmIChsZW5ndGggPj0gbWluTGVuZ3RoUGFyYW0pIHtcbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgbWluTGVuZ3RoOiB7XG4gICAgICAgIG1pbkxlbmd0aDogbWluTGVuZ3RoUGFyYW0sXG4gICAgICAgIHZhbHVlOiB2YWx1ZSBhcyBzdHJpbmcsXG4gICAgICAgIGFjdHVhbExlbmd0aDogbGVuZ3RoLFxuICAgICAgfSxcbiAgICB9O1xuICB9O1xufVxuIl19