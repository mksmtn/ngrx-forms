import { unbox } from "../boxing";
/**
 * A validation function that requires a value to be a valid number.
 * Considers `null` and `undefined` as valid. Combine this function with the
 * `required` validation function if these values should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  number: {
    actual: any;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  amount: validate(number),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
export function number(value) {
    value = unbox(value);
    if (value === null || value === undefined || typeof value === "number") {
        return {};
    }
    return {
        number: {
            actual: value,
        },
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnVtYmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3ZhbGlkYXRpb24vbnVtYmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBUyxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFPekM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBMEJHO0FBQ0gsTUFBTSxVQUFVLE1BQU0sQ0FDcEIsS0FBUTtJQUVSLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFtQyxDQUFDO0lBRXZELElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssU0FBUyxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDO1FBQ3ZFLE9BQU8sRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVELE9BQU87UUFDTCxNQUFNLEVBQUU7WUFDTixNQUFNLEVBQUUsS0FBSztTQUNkO0tBQ0YsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3hlZCwgdW5ib3ggfSBmcm9tIFwiLi4vYm94aW5nXCI7XG5pbXBvcnQgeyBWYWxpZGF0aW9uRXJyb3JzIH0gZnJvbSBcIi4uL3N0YXRlXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTnVtYmVyVmFsaWRhdGlvbkVycm9yPFQ+IHtcbiAgYWN0dWFsOiBUO1xufVxuXG4vKipcbiAqIEEgdmFsaWRhdGlvbiBmdW5jdGlvbiB0aGF0IHJlcXVpcmVzIGEgdmFsdWUgdG8gYmUgYSB2YWxpZCBudW1iZXIuXG4gKiBDb25zaWRlcnMgYG51bGxgIGFuZCBgdW5kZWZpbmVkYCBhcyB2YWxpZC4gQ29tYmluZSB0aGlzIGZ1bmN0aW9uIHdpdGggdGhlXG4gKiBgcmVxdWlyZWRgIHZhbGlkYXRpb24gZnVuY3Rpb24gaWYgdGhlc2UgdmFsdWVzIHNob3VsZCBiZSBjb25zaWRlcmVkIGludmFsaWQuXG4gKlxuICogVGhlIHZhbGlkYXRpb24gZXJyb3IgcmV0dXJuZWQgYnkgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGhhcyB0aGUgZm9sbG93aW5nIHNoYXBlOlxuICpcbmBgYHR5cGVzY3JpcHRcbntcbiAgbnVtYmVyOiB7XG4gICAgYWN0dWFsOiBhbnk7XG4gIH07XG59XG5gYGBcbiAqXG4gKiBVc3VhbGx5IHlvdSB3b3VsZCB1c2UgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIGB2YWxpZGF0ZWBcbiAqIHVwZGF0ZSBmdW5jdGlvbiB0byBwZXJmb3JtIHN5bmNocm9ub3VzIHZhbGlkYXRpb24gaW4geW91ciByZWR1Y2VyOlxuICpcbmBgYHR5cGVzY3JpcHRcbnVwZGF0ZUdyb3VwPE15Rm9ybVZhbHVlPih7XG4gIGFtb3VudDogdmFsaWRhdGUobnVtYmVyKSxcbn0pXG5gYGBcbiAqXG4gKiBOb3RlIHRoYXQgdGhpcyBmdW5jdGlvbiBpcyBnZW5lcmljIHRvIGFsbG93IHRoZSBjb21waWxlciB0byBwcm9wZXJseSBpbmZlciB0aGUgdHlwZVxuICogb2YgdGhlIGB2YWxpZGF0ZWAgZnVuY3Rpb24gZm9yIGJvdGggb3B0aW9uYWwgYW5kIG5vbi1vcHRpb25hbCBjb250cm9scy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG51bWJlcjxUIGV4dGVuZHMgbnVtYmVyIHwgQm94ZWQ8bnVtYmVyPiB8IG51bGwgfCB1bmRlZmluZWQ+KFxuICB2YWx1ZTogVFxuKTogVmFsaWRhdGlvbkVycm9ycyB7XG4gIHZhbHVlID0gdW5ib3godmFsdWUpIGFzIG51bWJlciB8IG51bGwgfCB1bmRlZmluZWQgYXMgVDtcblxuICBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCB8fCB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIpIHtcbiAgICByZXR1cm4ge307XG4gIH1cblxuICByZXR1cm4ge1xuICAgIG51bWJlcjoge1xuICAgICAgYWN0dWFsOiB2YWx1ZSxcbiAgICB9LFxuICB9O1xufVxuIl19