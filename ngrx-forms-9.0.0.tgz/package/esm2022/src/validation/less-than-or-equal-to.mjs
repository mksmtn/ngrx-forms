import { unbox } from "../boxing";
/**
 * A validation function that requires the value to be less than or equal to a number.
 * Considers `null`, `undefined` and non-numeric values as valid. Combine this function with the `required`
 * validation function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  lessThanOrEqualTo: {
    comparand: number;
    actual: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  amount: validate(lessThanOrEqualTo(10)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
export function lessThanOrEqualTo(comparand) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (comparand === null || comparand === undefined) {
        throw new Error(`The lessThanOrEqualTo Validation function requires the comparand parameter to be a non-null number, got ${comparand}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined || typeof value !== "number") {
            return {};
        }
        if (value <= comparand) {
            return {};
        }
        return {
            lessThanOrEqualTo: {
                comparand,
                actual: value,
            },
        };
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGVzcy10aGFuLW9yLWVxdWFsLXRvLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3ZhbGlkYXRpb24vbGVzcy10aGFuLW9yLWVxdWFsLXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBUyxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFRekM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTJCRztBQUNILE1BQU0sVUFBVSxpQkFBaUIsQ0FBQyxTQUFpQjtJQUNqRCxpR0FBaUc7SUFDakcsSUFBSSxTQUFTLEtBQUssSUFBSSxJQUFJLFNBQVMsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUNsRCxNQUFNLElBQUksS0FBSyxDQUNiLDJHQUEyRyxTQUFTLEdBQUcsQ0FDeEgsQ0FBQztJQUNKLENBQUM7SUFFRCxPQUFPLENBQ0wsS0FBUSxFQUNVLEVBQUU7UUFDcEIsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQW1DLENBQUM7UUFFdkQsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxTQUFTLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDdkUsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDO1FBRUQsSUFBSSxLQUFLLElBQUksU0FBUyxFQUFFLENBQUM7WUFDdkIsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDO1FBRUQsT0FBTztZQUNMLGlCQUFpQixFQUFFO2dCQUNqQixTQUFTO2dCQUNULE1BQU0sRUFBRSxLQUFlO2FBQ3hCO1NBQ0YsQ0FBQztJQUNKLENBQUMsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3hlZCwgdW5ib3ggfSBmcm9tIFwiLi4vYm94aW5nXCI7XG5pbXBvcnQgeyBWYWxpZGF0aW9uRXJyb3JzIH0gZnJvbSBcIi4uL3N0YXRlXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTGVzc1RoYW5PckVxdWFsVG9WYWxpZGF0aW9uRXJyb3Ige1xuICBjb21wYXJhbmQ6IG51bWJlcjtcbiAgYWN0dWFsOiBudW1iZXI7XG59XG5cbi8qKlxuICogQSB2YWxpZGF0aW9uIGZ1bmN0aW9uIHRoYXQgcmVxdWlyZXMgdGhlIHZhbHVlIHRvIGJlIGxlc3MgdGhhbiBvciBlcXVhbCB0byBhIG51bWJlci5cbiAqIENvbnNpZGVycyBgbnVsbGAsIGB1bmRlZmluZWRgIGFuZCBub24tbnVtZXJpYyB2YWx1ZXMgYXMgdmFsaWQuIENvbWJpbmUgdGhpcyBmdW5jdGlvbiB3aXRoIHRoZSBgcmVxdWlyZWRgXG4gKiB2YWxpZGF0aW9uIGZ1bmN0aW9uIGlmIGBudWxsYCBvciBgdW5kZWZpbmVkYCBzaG91bGQgYmUgY29uc2lkZXJlZCBpbnZhbGlkLlxuICpcbiAqIFRoZSB2YWxpZGF0aW9uIGVycm9yIHJldHVybmVkIGJ5IHRoaXMgdmFsaWRhdGlvbiBmdW5jdGlvbiBoYXMgdGhlIGZvbGxvd2luZyBzaGFwZTpcbiAqXG5gYGB0eXBlc2NyaXB0XG57XG4gIGxlc3NUaGFuT3JFcXVhbFRvOiB7XG4gICAgY29tcGFyYW5kOiBudW1iZXI7XG4gICAgYWN0dWFsOiBudW1iZXI7XG4gIH07XG59XG5gYGBcbiAqXG4gKiBVc3VhbGx5IHlvdSB3b3VsZCB1c2UgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIGB2YWxpZGF0ZWBcbiAqIHVwZGF0ZSBmdW5jdGlvbiB0byBwZXJmb3JtIHN5bmNocm9ub3VzIHZhbGlkYXRpb24gaW4geW91ciByZWR1Y2VyOlxuICpcbmBgYHR5cGVzY3JpcHRcbnVwZGF0ZUdyb3VwPE15Rm9ybVZhbHVlPih7XG4gIGFtb3VudDogdmFsaWRhdGUobGVzc1RoYW5PckVxdWFsVG8oMTApKSxcbn0pXG5gYGBcbiAqXG4gKiBOb3RlIHRoYXQgdGhpcyBmdW5jdGlvbiBpcyBnZW5lcmljIHRvIGFsbG93IHRoZSBjb21waWxlciB0byBwcm9wZXJseSBpbmZlciB0aGUgdHlwZVxuICogb2YgdGhlIGB2YWxpZGF0ZWAgZnVuY3Rpb24gZm9yIGJvdGggb3B0aW9uYWwgYW5kIG5vbi1vcHRpb25hbCBjb250cm9scy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxlc3NUaGFuT3JFcXVhbFRvKGNvbXBhcmFuZDogbnVtYmVyKSB7XG4gIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpzdHJpY3QtdHlwZS1wcmVkaWNhdGVzIChndWFyZCBmb3IgdXNlcnMgd2l0aG91dCBzdHJpY3QgdHlwZSBjaGVja2luZylcbiAgaWYgKGNvbXBhcmFuZCA9PT0gbnVsbCB8fCBjb21wYXJhbmQgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGBUaGUgbGVzc1RoYW5PckVxdWFsVG8gVmFsaWRhdGlvbiBmdW5jdGlvbiByZXF1aXJlcyB0aGUgY29tcGFyYW5kIHBhcmFtZXRlciB0byBiZSBhIG5vbi1udWxsIG51bWJlciwgZ290ICR7Y29tcGFyYW5kfSFgXG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiA8VCBleHRlbmRzIG51bWJlciB8IEJveGVkPG51bWJlcj4gfCBudWxsIHwgdW5kZWZpbmVkPihcbiAgICB2YWx1ZTogVFxuICApOiBWYWxpZGF0aW9uRXJyb3JzID0+IHtcbiAgICB2YWx1ZSA9IHVuYm94KHZhbHVlKSBhcyBudW1iZXIgfCBudWxsIHwgdW5kZWZpbmVkIGFzIFQ7XG5cbiAgICBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCB8fCB0eXBlb2YgdmFsdWUgIT09IFwibnVtYmVyXCIpIHtcbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG5cbiAgICBpZiAodmFsdWUgPD0gY29tcGFyYW5kKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIGxlc3NUaGFuT3JFcXVhbFRvOiB7XG4gICAgICAgIGNvbXBhcmFuZCxcbiAgICAgICAgYWN0dWFsOiB2YWx1ZSBhcyBudW1iZXIsXG4gICAgICB9LFxuICAgIH07XG4gIH07XG59XG4iXX0=