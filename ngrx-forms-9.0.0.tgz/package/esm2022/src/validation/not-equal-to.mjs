import { unbox } from "../boxing";
/**
 * A validation function that requires the value to be strictly not equal (i.e. `!==`)
 * to another value.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  notEqualTo: {
    comparand: T;
    actual: T;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  name: validate(notEqualTo('John Doe')),
})
```
 */
export function notEqualTo(comparand) {
    return (value) => {
        value = unbox(value);
        if (value !== comparand) {
            return {};
        }
        return {
            notEqualTo: {
                comparand,
                actual: value,
            },
        };
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibm90LWVxdWFsLXRvLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3ZhbGlkYXRpb24vbm90LWVxdWFsLXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBUyxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFRekM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBdUJHO0FBQ0gsTUFBTSxVQUFVLFVBQVUsQ0FBSSxTQUFZO0lBQ3hDLE9BQU8sQ0FBOEIsS0FBUyxFQUFvQixFQUFFO1FBQ2xFLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFZLENBQUM7UUFFaEMsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDeEIsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDO1FBRUQsT0FBTztZQUNMLFVBQVUsRUFBRTtnQkFDVixTQUFTO2dCQUNULE1BQU0sRUFBRSxLQUFLO2FBQ2Q7U0FDRixDQUFDO0lBQ0osQ0FBQyxDQUFDO0FBQ0osQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJveGVkLCB1bmJveCB9IGZyb20gXCIuLi9ib3hpbmdcIjtcbmltcG9ydCB7IFZhbGlkYXRpb25FcnJvcnMgfSBmcm9tIFwiLi4vc3RhdGVcIjtcblxuZXhwb3J0IGludGVyZmFjZSBOb3RFcXVhbFRvVmFsaWRhdGlvbkVycm9yPFQ+IHtcbiAgY29tcGFyYW5kOiBUO1xuICBhY3R1YWw6IFQ7XG59XG5cbi8qKlxuICogQSB2YWxpZGF0aW9uIGZ1bmN0aW9uIHRoYXQgcmVxdWlyZXMgdGhlIHZhbHVlIHRvIGJlIHN0cmljdGx5IG5vdCBlcXVhbCAoaS5lLiBgIT09YClcbiAqIHRvIGFub3RoZXIgdmFsdWUuXG4gKlxuICogVGhlIHZhbGlkYXRpb24gZXJyb3IgcmV0dXJuZWQgYnkgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGhhcyB0aGUgZm9sbG93aW5nIHNoYXBlOlxuICpcbmBgYHR5cGVzY3JpcHRcbntcbiAgbm90RXF1YWxUbzoge1xuICAgIGNvbXBhcmFuZDogVDtcbiAgICBhY3R1YWw6IFQ7XG4gIH07XG59XG5gYGBcbiAqXG4gKiBVc3VhbGx5IHlvdSB3b3VsZCB1c2UgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIGB2YWxpZGF0ZWBcbiAqIHVwZGF0ZSBmdW5jdGlvbiB0byBwZXJmb3JtIHN5bmNocm9ub3VzIHZhbGlkYXRpb24gaW4geW91ciByZWR1Y2VyOlxuICpcbmBgYHR5cGVzY3JpcHRcbnVwZGF0ZUdyb3VwPE15Rm9ybVZhbHVlPih7XG4gIG5hbWU6IHZhbGlkYXRlKG5vdEVxdWFsVG8oJ0pvaG4gRG9lJykpLFxufSlcbmBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gbm90RXF1YWxUbzxUPihjb21wYXJhbmQ6IFQpIHtcbiAgcmV0dXJuIDxUViBleHRlbmRzIFQgfCBCb3hlZDxUPiA9IFQ+KHZhbHVlOiBUVik6IFZhbGlkYXRpb25FcnJvcnMgPT4ge1xuICAgIHZhbHVlID0gdW5ib3godmFsdWUpIGFzIFQgYXMgVFY7XG5cbiAgICBpZiAodmFsdWUgIT09IGNvbXBhcmFuZCkge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBub3RFcXVhbFRvOiB7XG4gICAgICAgIGNvbXBhcmFuZCxcbiAgICAgICAgYWN0dWFsOiB2YWx1ZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgfTtcbn1cbiJdfQ==