import { unbox } from "../boxing";
/**
 * A validation function that requires the value to be greater than a number.
 * Considers `null`, `undefined` and non-numeric values as valid. Combine this function with the `required`
 * validation function if `null` or `undefined` should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  greaterThan: {
    comparand: number;
    actual: number;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  amount: validate(greaterThan(10)),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
export function greaterThan(comparand) {
    // tslint:disable-next-line:strict-type-predicates (guard for users without strict type checking)
    if (comparand === null || comparand === undefined) {
        throw new Error(`The greaterThan Validation function requires the comparand parameter to be a non-null number, got ${comparand}!`);
    }
    return (value) => {
        value = unbox(value);
        if (value === null || value === undefined || typeof value !== "number") {
            return {};
        }
        if (value > comparand) {
            return {};
        }
        return {
            greaterThan: {
                comparand,
                actual: value,
            },
        };
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JlYXRlci10aGFuLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3ZhbGlkYXRpb24vZ3JlYXRlci10aGFuLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBUyxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFRekM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTJCRztBQUNILE1BQU0sVUFBVSxXQUFXLENBQUMsU0FBaUI7SUFDM0MsaUdBQWlHO0lBQ2pHLElBQUksU0FBUyxLQUFLLElBQUksSUFBSSxTQUFTLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDbEQsTUFBTSxJQUFJLEtBQUssQ0FDYixxR0FBcUcsU0FBUyxHQUFHLENBQ2xILENBQUM7SUFDSixDQUFDO0lBRUQsT0FBTyxDQUNMLEtBQVEsRUFDVSxFQUFFO1FBQ3BCLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFtQyxDQUFDO1FBRXZELElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssU0FBUyxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDO1lBQ3ZFLE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQztRQUVELElBQUksS0FBSyxHQUFHLFNBQVMsRUFBRSxDQUFDO1lBQ3RCLE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQztRQUVELE9BQU87WUFDTCxXQUFXLEVBQUU7Z0JBQ1gsU0FBUztnQkFDVCxNQUFNLEVBQUUsS0FBZTthQUN4QjtTQUNGLENBQUM7SUFDSixDQUFDLENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94ZWQsIHVuYm94IH0gZnJvbSBcIi4uL2JveGluZ1wiO1xuaW1wb3J0IHsgVmFsaWRhdGlvbkVycm9ycyB9IGZyb20gXCIuLi9zdGF0ZVwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIEdyZWF0ZXJUaGFuVmFsaWRhdGlvbkVycm9yIHtcbiAgY29tcGFyYW5kOiBudW1iZXI7XG4gIGFjdHVhbDogbnVtYmVyO1xufVxuXG4vKipcbiAqIEEgdmFsaWRhdGlvbiBmdW5jdGlvbiB0aGF0IHJlcXVpcmVzIHRoZSB2YWx1ZSB0byBiZSBncmVhdGVyIHRoYW4gYSBudW1iZXIuXG4gKiBDb25zaWRlcnMgYG51bGxgLCBgdW5kZWZpbmVkYCBhbmQgbm9uLW51bWVyaWMgdmFsdWVzIGFzIHZhbGlkLiBDb21iaW5lIHRoaXMgZnVuY3Rpb24gd2l0aCB0aGUgYHJlcXVpcmVkYFxuICogdmFsaWRhdGlvbiBmdW5jdGlvbiBpZiBgbnVsbGAgb3IgYHVuZGVmaW5lZGAgc2hvdWxkIGJlIGNvbnNpZGVyZWQgaW52YWxpZC5cbiAqXG4gKiBUaGUgdmFsaWRhdGlvbiBlcnJvciByZXR1cm5lZCBieSB0aGlzIHZhbGlkYXRpb24gZnVuY3Rpb24gaGFzIHRoZSBmb2xsb3dpbmcgc2hhcGU6XG4gKlxuYGBgdHlwZXNjcmlwdFxue1xuICBncmVhdGVyVGhhbjoge1xuICAgIGNvbXBhcmFuZDogbnVtYmVyO1xuICAgIGFjdHVhbDogbnVtYmVyO1xuICB9O1xufVxuYGBgXG4gKlxuICogVXN1YWxseSB5b3Ugd291bGQgdXNlIHRoaXMgdmFsaWRhdGlvbiBmdW5jdGlvbiBpbiBjb25qdW5jdGlvbiB3aXRoIHRoZSBgdmFsaWRhdGVgXG4gKiB1cGRhdGUgZnVuY3Rpb24gdG8gcGVyZm9ybSBzeW5jaHJvbm91cyB2YWxpZGF0aW9uIGluIHlvdXIgcmVkdWNlcjpcbiAqXG5gYGB0eXBlc2NyaXB0XG51cGRhdGVHcm91cDxNeUZvcm1WYWx1ZT4oe1xuICBhbW91bnQ6IHZhbGlkYXRlKGdyZWF0ZXJUaGFuKDEwKSksXG59KVxuYGBgXG4gKlxuICogTm90ZSB0aGF0IHRoaXMgZnVuY3Rpb24gaXMgZ2VuZXJpYyB0byBhbGxvdyB0aGUgY29tcGlsZXIgdG8gcHJvcGVybHkgaW5mZXIgdGhlIHR5cGVcbiAqIG9mIHRoZSBgdmFsaWRhdGVgIGZ1bmN0aW9uIGZvciBib3RoIG9wdGlvbmFsIGFuZCBub24tb3B0aW9uYWwgY29udHJvbHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBncmVhdGVyVGhhbihjb21wYXJhbmQ6IG51bWJlcikge1xuICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6c3RyaWN0LXR5cGUtcHJlZGljYXRlcyAoZ3VhcmQgZm9yIHVzZXJzIHdpdGhvdXQgc3RyaWN0IHR5cGUgY2hlY2tpbmcpXG4gIGlmIChjb21wYXJhbmQgPT09IG51bGwgfHwgY29tcGFyYW5kID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBgVGhlIGdyZWF0ZXJUaGFuIFZhbGlkYXRpb24gZnVuY3Rpb24gcmVxdWlyZXMgdGhlIGNvbXBhcmFuZCBwYXJhbWV0ZXIgdG8gYmUgYSBub24tbnVsbCBudW1iZXIsIGdvdCAke2NvbXBhcmFuZH0hYFxuICAgICk7XG4gIH1cblxuICByZXR1cm4gPFQgZXh0ZW5kcyBudW1iZXIgfCBCb3hlZDxudW1iZXI+IHwgbnVsbCB8IHVuZGVmaW5lZD4oXG4gICAgdmFsdWU6IFRcbiAgKTogVmFsaWRhdGlvbkVycm9ycyA9PiB7XG4gICAgdmFsdWUgPSB1bmJveCh2YWx1ZSkgYXMgbnVtYmVyIHwgbnVsbCB8IHVuZGVmaW5lZCBhcyBUO1xuXG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgfHwgdHlwZW9mIHZhbHVlICE9PSBcIm51bWJlclwiKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgaWYgKHZhbHVlID4gY29tcGFyYW5kKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIGdyZWF0ZXJUaGFuOiB7XG4gICAgICAgIGNvbXBhcmFuZCxcbiAgICAgICAgYWN0dWFsOiB2YWx1ZSBhcyBudW1iZXIsXG4gICAgICB9LFxuICAgIH07XG4gIH07XG59XG4iXX0=