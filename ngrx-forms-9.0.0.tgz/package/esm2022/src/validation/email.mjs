import { unbox } from "../boxing";
// this regex is taken from the @angular/forms source code
// tslint:disable-next-line:max-line-length
export const NGRX_FORMS_EMAIL_VALIDATION_REGEXP = /^(?=.{1,254}$)(?=.{1,64}@)[-!#$%&'*+/0-9=?A-Z^_`a-z{|}~]+(\.[-!#$%&'*+/0-9=?A-Z^_`a-z{|}~]+)*@[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/;
/**
 * A validation function that requires a value to be a valid e-mail address.
 * Considers `null`, `undefined`, and `''` as valid. Combine this function with the
 * `required` validation function if these values should be considered invalid.
 *
 * The validation error returned by this validation function has the following shape:
 *
```typescript
{
  email: {
    pattern: string;
    actual: string;
  };
}
```
 *
 * Usually you would use this validation function in conjunction with the `validate`
 * update function to perform synchronous validation in your reducer:
 *
```typescript
updateGroup<MyFormValue>({
  userMailAddress: validate(email),
})
```
 *
 * Note that this function is generic to allow the compiler to properly infer the type
 * of the `validate` function for both optional and non-optional controls.
 */
export function email(value) {
    value = unbox(value);
    if (value === null || value === undefined || value.length === 0) {
        return {};
    }
    if (NGRX_FORMS_EMAIL_VALIDATION_REGEXP.test(value)) {
        return {};
    }
    return {
        email: {
            pattern: NGRX_FORMS_EMAIL_VALIDATION_REGEXP.toString(),
            actual: value,
        },
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW1haWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdmFsaWRhdGlvbi9lbWFpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQVMsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBR3pDLDBEQUEwRDtBQUMxRCwyQ0FBMkM7QUFDM0MsTUFBTSxDQUFDLE1BQU0sa0NBQWtDLEdBQzdDLDRMQUE0TCxDQUFDO0FBTy9MOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0EyQkc7QUFDSCxNQUFNLFVBQVUsS0FBSyxDQUNuQixLQUFRO0lBRVIsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQW1DLENBQUM7SUFFdkQsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxTQUFTLElBQUssS0FBZ0IsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDNUUsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0lBRUQsSUFBSSxrQ0FBa0MsQ0FBQyxJQUFJLENBQUMsS0FBZSxDQUFDLEVBQUUsQ0FBQztRQUM3RCxPQUFPLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFRCxPQUFPO1FBQ0wsS0FBSyxFQUFFO1lBQ0wsT0FBTyxFQUFFLGtDQUFrQyxDQUFDLFFBQVEsRUFBRTtZQUN0RCxNQUFNLEVBQUUsS0FBZTtTQUN4QjtLQUNGLENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94ZWQsIHVuYm94IH0gZnJvbSBcIi4uL2JveGluZ1wiO1xuaW1wb3J0IHsgVmFsaWRhdGlvbkVycm9ycyB9IGZyb20gXCIuLi9zdGF0ZVwiO1xuXG4vLyB0aGlzIHJlZ2V4IGlzIHRha2VuIGZyb20gdGhlIEBhbmd1bGFyL2Zvcm1zIHNvdXJjZSBjb2RlXG4vLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bWF4LWxpbmUtbGVuZ3RoXG5leHBvcnQgY29uc3QgTkdSWF9GT1JNU19FTUFJTF9WQUxJREFUSU9OX1JFR0VYUCA9XG4gIC9eKD89LnsxLDI1NH0kKSg/PS57MSw2NH1AKVstISMkJSYnKisvMC05PT9BLVpeX2BhLXp7fH1+XSsoXFwuWy0hIyQlJicqKy8wLTk9P0EtWl5fYGEtent8fX5dKykqQFtBLVphLXowLTldKFtBLVphLXowLTktXXswLDYxfVtBLVphLXowLTldKT8oXFwuW0EtWmEtejAtOV0oW0EtWmEtejAtOS1dezAsNjF9W0EtWmEtejAtOV0pPykqJC87XG5cbmV4cG9ydCBpbnRlcmZhY2UgRW1haWxWYWxpZGF0aW9uRXJyb3Ige1xuICBwYXR0ZXJuOiBzdHJpbmc7XG4gIGFjdHVhbDogc3RyaW5nO1xufVxuXG4vKipcbiAqIEEgdmFsaWRhdGlvbiBmdW5jdGlvbiB0aGF0IHJlcXVpcmVzIGEgdmFsdWUgdG8gYmUgYSB2YWxpZCBlLW1haWwgYWRkcmVzcy5cbiAqIENvbnNpZGVycyBgbnVsbGAsIGB1bmRlZmluZWRgLCBhbmQgYCcnYCBhcyB2YWxpZC4gQ29tYmluZSB0aGlzIGZ1bmN0aW9uIHdpdGggdGhlXG4gKiBgcmVxdWlyZWRgIHZhbGlkYXRpb24gZnVuY3Rpb24gaWYgdGhlc2UgdmFsdWVzIHNob3VsZCBiZSBjb25zaWRlcmVkIGludmFsaWQuXG4gKlxuICogVGhlIHZhbGlkYXRpb24gZXJyb3IgcmV0dXJuZWQgYnkgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGhhcyB0aGUgZm9sbG93aW5nIHNoYXBlOlxuICpcbmBgYHR5cGVzY3JpcHRcbntcbiAgZW1haWw6IHtcbiAgICBwYXR0ZXJuOiBzdHJpbmc7XG4gICAgYWN0dWFsOiBzdHJpbmc7XG4gIH07XG59XG5gYGBcbiAqXG4gKiBVc3VhbGx5IHlvdSB3b3VsZCB1c2UgdGhpcyB2YWxpZGF0aW9uIGZ1bmN0aW9uIGluIGNvbmp1bmN0aW9uIHdpdGggdGhlIGB2YWxpZGF0ZWBcbiAqIHVwZGF0ZSBmdW5jdGlvbiB0byBwZXJmb3JtIHN5bmNocm9ub3VzIHZhbGlkYXRpb24gaW4geW91ciByZWR1Y2VyOlxuICpcbmBgYHR5cGVzY3JpcHRcbnVwZGF0ZUdyb3VwPE15Rm9ybVZhbHVlPih7XG4gIHVzZXJNYWlsQWRkcmVzczogdmFsaWRhdGUoZW1haWwpLFxufSlcbmBgYFxuICpcbiAqIE5vdGUgdGhhdCB0aGlzIGZ1bmN0aW9uIGlzIGdlbmVyaWMgdG8gYWxsb3cgdGhlIGNvbXBpbGVyIHRvIHByb3Blcmx5IGluZmVyIHRoZSB0eXBlXG4gKiBvZiB0aGUgYHZhbGlkYXRlYCBmdW5jdGlvbiBmb3IgYm90aCBvcHRpb25hbCBhbmQgbm9uLW9wdGlvbmFsIGNvbnRyb2xzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZW1haWw8VCBleHRlbmRzIHN0cmluZyB8IEJveGVkPHN0cmluZz4gfCBudWxsIHwgdW5kZWZpbmVkPihcbiAgdmFsdWU6IFRcbik6IFZhbGlkYXRpb25FcnJvcnMge1xuICB2YWx1ZSA9IHVuYm94KHZhbHVlKSBhcyBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkIGFzIFQ7XG5cbiAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgfHwgKHZhbHVlIGFzIHN0cmluZykubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgaWYgKE5HUlhfRk9STVNfRU1BSUxfVkFMSURBVElPTl9SRUdFWFAudGVzdCh2YWx1ZSBhcyBzdHJpbmcpKSB7XG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBlbWFpbDoge1xuICAgICAgcGF0dGVybjogTkdSWF9GT1JNU19FTUFJTF9WQUxJREFUSU9OX1JFR0VYUC50b1N0cmluZygpLFxuICAgICAgYWN0dWFsOiB2YWx1ZSBhcyBzdHJpbmcsXG4gICAgfSxcbiAgfTtcbn1cbiJdfQ==