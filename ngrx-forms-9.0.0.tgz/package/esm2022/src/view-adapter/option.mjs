import { Directive, Host, Input, Optional, } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "./select";
import * as i2 from "./select-multiple";
// tslint:disable:directive-class-suffix
const NULL_RENDERER = {
    setProperty: () => void 0,
};
/**
 * This directive is necessary to restore the default behaviour of Angular
 * when an `option` is used without an **ngrx-forms** form state. Since it
 * is not possible to select an element with a selector that considers its
 * parent the `option` directives for `select` and `select[multiple]` will
 * always be applied and therefore overriding the `[value]` binding which
 * disabled Angular's normal behaviour. This directive restores this
 * behaviour if no `select` or `select[multiple]` view adapter is found.
 * This is not a perfect solution since it may interfere with other
 * directives that try to set the `[value]` but that is very unlikely.
 */
export class NgrxFallbackSelectOption {
    element;
    renderer;
    constructor(element, renderer, viewAdapter, multipleViewAdapter) {
        this.element = element;
        this.renderer = renderer;
        this.renderer = viewAdapter || multipleViewAdapter ? NULL_RENDERER : renderer;
    }
    set value(value) {
        this.renderer.setProperty(this.element.nativeElement, 'value', value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFallbackSelectOption, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i1.NgrxSelectViewAdapter, host: true, optional: true }, { token: i2.NgrxSelectMultipleViewAdapter, host: true, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxFallbackSelectOption, selector: "option", inputs: { value: "value" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFallbackSelectOption, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'option',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i1.NgrxSelectViewAdapter, decorators: [{
                    type: Host
                }, {
                    type: Optional
                }] }, { type: i2.NgrxSelectMultipleViewAdapter, decorators: [{
                    type: Host
                }, {
                    type: Optional
                }] }], propDecorators: { value: [{
                type: Input,
                args: ['value']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3ZpZXctYWRhcHRlci9vcHRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNMLFNBQVMsRUFFVCxJQUFJLEVBQ0osS0FBSyxFQUNMLFFBQVEsR0FFVCxNQUFNLGVBQWUsQ0FBQzs7OztBQUt2Qix3Q0FBd0M7QUFFeEMsTUFBTSxhQUFhLEdBQWM7SUFDL0IsV0FBVyxFQUFFLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQztDQUNuQixDQUFDO0FBRVQ7Ozs7Ozs7Ozs7R0FVRztBQUtILE1BQU0sT0FBTyx3QkFBd0I7SUFFekI7SUFDQTtJQUZWLFlBQ1UsT0FBbUIsRUFDbkIsUUFBbUIsRUFDUCxXQUFrQyxFQUNsQyxtQkFBa0Q7UUFIOUQsWUFBTyxHQUFQLE9BQU8sQ0FBWTtRQUNuQixhQUFRLEdBQVIsUUFBUSxDQUFXO1FBSTNCLElBQUksQ0FBQyxRQUFRLEdBQUcsV0FBVyxJQUFJLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztJQUNoRixDQUFDO0lBRUQsSUFDSSxLQUFLLENBQUMsS0FBVTtRQUNsQixJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEUsQ0FBQzt1R0FiVSx3QkFBd0I7MkZBQXhCLHdCQUF3Qjs7MkZBQXhCLHdCQUF3QjtrQkFKcEMsU0FBUzttQkFBQztvQkFDVCw4Q0FBOEM7b0JBQzlDLFFBQVEsRUFBRSxRQUFRO2lCQUNuQjs7MEJBS0ksSUFBSTs7MEJBQUksUUFBUTs7MEJBQ2hCLElBQUk7OzBCQUFJLFFBQVE7eUNBTWYsS0FBSztzQkFEUixLQUFLO3VCQUFDLE9BQU8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBEaXJlY3RpdmUsXG4gIEVsZW1lbnRSZWYsXG4gIEhvc3QsXG4gIElucHV0LFxuICBPcHRpb25hbCxcbiAgUmVuZGVyZXIyLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgTmdyeFNlbGVjdFZpZXdBZGFwdGVyIH0gZnJvbSAnLi9zZWxlY3QnO1xuaW1wb3J0IHsgTmdyeFNlbGVjdE11bHRpcGxlVmlld0FkYXB0ZXIgfSBmcm9tICcuL3NlbGVjdC1tdWx0aXBsZSc7XG5cbi8vIHRzbGludDpkaXNhYmxlOmRpcmVjdGl2ZS1jbGFzcy1zdWZmaXhcblxuY29uc3QgTlVMTF9SRU5ERVJFUjogUmVuZGVyZXIyID0ge1xuICBzZXRQcm9wZXJ0eTogKCkgPT4gdm9pZCAwLFxufSBhcyBhbnk7XG5cbi8qKlxuICogVGhpcyBkaXJlY3RpdmUgaXMgbmVjZXNzYXJ5IHRvIHJlc3RvcmUgdGhlIGRlZmF1bHQgYmVoYXZpb3VyIG9mIEFuZ3VsYXJcbiAqIHdoZW4gYW4gYG9wdGlvbmAgaXMgdXNlZCB3aXRob3V0IGFuICoqbmdyeC1mb3JtcyoqIGZvcm0gc3RhdGUuIFNpbmNlIGl0XG4gKiBpcyBub3QgcG9zc2libGUgdG8gc2VsZWN0IGFuIGVsZW1lbnQgd2l0aCBhIHNlbGVjdG9yIHRoYXQgY29uc2lkZXJzIGl0c1xuICogcGFyZW50IHRoZSBgb3B0aW9uYCBkaXJlY3RpdmVzIGZvciBgc2VsZWN0YCBhbmQgYHNlbGVjdFttdWx0aXBsZV1gIHdpbGxcbiAqIGFsd2F5cyBiZSBhcHBsaWVkIGFuZCB0aGVyZWZvcmUgb3ZlcnJpZGluZyB0aGUgYFt2YWx1ZV1gIGJpbmRpbmcgd2hpY2hcbiAqIGRpc2FibGVkIEFuZ3VsYXIncyBub3JtYWwgYmVoYXZpb3VyLiBUaGlzIGRpcmVjdGl2ZSByZXN0b3JlcyB0aGlzXG4gKiBiZWhhdmlvdXIgaWYgbm8gYHNlbGVjdGAgb3IgYHNlbGVjdFttdWx0aXBsZV1gIHZpZXcgYWRhcHRlciBpcyBmb3VuZC5cbiAqIFRoaXMgaXMgbm90IGEgcGVyZmVjdCBzb2x1dGlvbiBzaW5jZSBpdCBtYXkgaW50ZXJmZXJlIHdpdGggb3RoZXJcbiAqIGRpcmVjdGl2ZXMgdGhhdCB0cnkgdG8gc2V0IHRoZSBgW3ZhbHVlXWAgYnV0IHRoYXQgaXMgdmVyeSB1bmxpa2VseS5cbiAqL1xuQERpcmVjdGl2ZSh7XG4gIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpkaXJlY3RpdmUtc2VsZWN0b3JcbiAgc2VsZWN0b3I6ICdvcHRpb24nLFxufSlcbmV4cG9ydCBjbGFzcyBOZ3J4RmFsbGJhY2tTZWxlY3RPcHRpb24ge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGVsZW1lbnQ6IEVsZW1lbnRSZWYsXG4gICAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyLFxuICAgIEBIb3N0KCkgQE9wdGlvbmFsKCkgdmlld0FkYXB0ZXI6IE5ncnhTZWxlY3RWaWV3QWRhcHRlcixcbiAgICBASG9zdCgpIEBPcHRpb25hbCgpIG11bHRpcGxlVmlld0FkYXB0ZXI6IE5ncnhTZWxlY3RNdWx0aXBsZVZpZXdBZGFwdGVyLFxuICApIHtcbiAgICB0aGlzLnJlbmRlcmVyID0gdmlld0FkYXB0ZXIgfHwgbXVsdGlwbGVWaWV3QWRhcHRlciA/IE5VTExfUkVOREVSRVIgOiByZW5kZXJlcjtcbiAgfVxuXG4gIEBJbnB1dCgndmFsdWUnKVxuICBzZXQgdmFsdWUodmFsdWU6IGFueSkge1xuICAgIHRoaXMucmVuZGVyZXIuc2V0UHJvcGVydHkodGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICd2YWx1ZScsIHZhbHVlKTtcbiAgfVxufVxuIl19