import { Directive, forwardRef, Host, HostListener, Input, Optional, } from '@angular/core';
import { NGRX_FORM_VIEW_ADAPTER } from './view-adapter';
import * as i0 from "@angular/core";
// tslint:disable:directive-class-suffix
export class NgrxSelectViewAdapter {
    renderer;
    elementRef;
    state;
    optionMap = {};
    idCounter = 0;
    selectedId = null;
    value = undefined;
    nativeIdWasSet = false;
    onChangeFn = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        this.value = value;
        this.selectedId = this.getOptionId(value);
        if (this.selectedId === null) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'selectedIndex', -1);
        }
        this.renderer.setProperty(this.elementRef.nativeElement, 'value', this.selectedId);
    }
    onChange({ target }) {
        this.selectedId = target.value;
        const value = this.optionMap[this.selectedId];
        this.value = value;
        this.onChangeFn(value);
    }
    setOnChangeCallback(fn) {
        this.onChangeFn = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    createOptionId() {
        const id = this.idCounter.toString();
        this.idCounter += 1;
        return id;
    }
    updateOptionValue(id, value) {
        this.optionMap[id] = value;
        if (this.selectedId === id) {
            this.onChangeFn(value);
        }
        else if (value === this.value) {
            this.setViewValue(value);
        }
    }
    deregisterOption(id) {
        delete this.optionMap[id];
    }
    getOptionId(value) {
        for (const id of Array.from(Object.keys(this.optionMap))) {
            if (this.optionMap[id] === value) {
                return id;
            }
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxSelectViewAdapter, selector: "select:not([multiple])[ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "change": "onChange($event)" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxSelectViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'select:not([multiple])[ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxSelectViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], onChange: [{
                type: HostListener,
                args: ['change', ['$event']]
            }] } });
const NULL_VIEW_ADAPTER = {
    createOptionId: () => '',
    deregisterOption: () => void 0,
    updateOptionValue: () => void 0,
};
const NULL_RENDERER = {
    setProperty: () => void 0,
};
export class NgrxSelectOption {
    element;
    renderer;
    viewAdapter;
    isInitialized = false;
    id;
    constructor(element, renderer, viewAdapter) {
        this.element = element;
        this.renderer = renderer;
        this.viewAdapter = viewAdapter;
        this.renderer = viewAdapter ? renderer : NULL_RENDERER;
        this.viewAdapter = viewAdapter || NULL_VIEW_ADAPTER;
        this.id = this.viewAdapter.createOptionId();
    }
    set value(value) {
        // this cannot be done inside ngOnInit since the value property
        // must be already set when the option value is updated in the view
        // adapter and the initial binding of 'value' happens before
        // ngOnInit runs
        if (!this.isInitialized) {
            this.isInitialized = true;
            this.renderer.setProperty(this.element.nativeElement, 'value', this.id);
        }
        this.viewAdapter.updateOptionValue(this.id, value);
    }
    ngOnDestroy() {
        this.viewAdapter.deregisterOption(this.id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectOption, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: NgrxSelectViewAdapter, host: true, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxSelectOption, selector: "option", inputs: { value: "value" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectOption, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'option',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: NgrxSelectViewAdapter, decorators: [{
                    type: Host
                }, {
                    type: Optional
                }] }], propDecorators: { value: [{
                type: Input,
                args: ['value']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3ZpZXctYWRhcHRlci9zZWxlY3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLFNBQVMsRUFFVCxVQUFVLEVBQ1YsSUFBSSxFQUNKLFlBQVksRUFDWixLQUFLLEVBRUwsUUFBUSxHQUVULE1BQU0sZUFBZSxDQUFDO0FBR3ZCLE9BQU8sRUFBbUIsc0JBQXNCLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7QUFFekUsd0NBQXdDO0FBV3hDLE1BQU0sT0FBTyxxQkFBcUI7SUEwQlo7SUFBNkI7SUF6QnpDLEtBQUssQ0FBd0I7SUFDN0IsU0FBUyxHQUEwQixFQUFFLENBQUM7SUFDdEMsU0FBUyxHQUFHLENBQUMsQ0FBQztJQUNkLFVBQVUsR0FBa0IsSUFBSSxDQUFDO0lBQ2pDLEtBQUssR0FBUSxTQUFTLENBQUM7SUFDdkIsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUUvQixVQUFVLEdBQXlCLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBR2hELFNBQVMsR0FBZSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUVwQyxJQUFhLG9CQUFvQixDQUFDLEtBQTRCO1FBQzVELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNYLE1BQU0sSUFBSSxLQUFLLENBQUMsMENBQTBDLENBQUMsQ0FBQztRQUM5RCxDQUFDO1FBRUQsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO1FBQ2xELE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLEVBQUUsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUN2RSxJQUFJLGlCQUFpQixFQUFFLENBQUM7WUFDdEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMzRSxDQUFDO0lBQ0gsQ0FBQztJQUVELFlBQW9CLFFBQW1CLEVBQVUsVUFBc0I7UUFBbkQsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQUFVLGVBQVUsR0FBVixVQUFVLENBQVk7SUFBSSxDQUFDO0lBRTVFLGVBQWU7UUFDYixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUM7UUFDbEQsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsS0FBSyxRQUFRLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDbEUsSUFBSSxpQkFBaUIsRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzlFLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQzdCLENBQUM7SUFDSCxDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQVU7UUFDckIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzFDLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoRixDQUFDO1FBRUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNyRixDQUFDO0lBR0QsUUFBUSxDQUFDLEVBQUUsTUFBTSxFQUFpQztRQUNoRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDL0IsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDOUMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBRUQsbUJBQW1CLENBQUMsRUFBd0I7UUFDMUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7SUFDdkIsQ0FBQztJQUVELG9CQUFvQixDQUFDLEVBQWM7UUFDakMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELGFBQWEsQ0FBQyxVQUFtQjtRQUMvQixJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDbkYsQ0FBQztJQUVELGNBQWM7UUFDWixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDO1FBQ3BCLE9BQU8sRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQVUsRUFBRSxLQUFVO1FBQ3RDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBRTNCLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxFQUFFLEVBQUUsQ0FBQztZQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pCLENBQUM7YUFBTSxJQUFJLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDaEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzQixDQUFDO0lBQ0gsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQVU7UUFDekIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFFTyxXQUFXLENBQUMsS0FBVTtRQUM1QixLQUFLLE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ3pELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsS0FBSyxLQUFLLEVBQUUsQ0FBQztnQkFDakMsT0FBTyxFQUFFLENBQUM7WUFDWixDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQzt1R0EvRlUscUJBQXFCOzJGQUFyQixxQkFBcUIsK01BTnJCLENBQUM7Z0JBQ1YsT0FBTyxFQUFFLHNCQUFzQjtnQkFDL0IsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQztnQkFDcEQsS0FBSyxFQUFFLElBQUk7YUFDWixDQUFDOzsyRkFFUyxxQkFBcUI7a0JBVGpDLFNBQVM7bUJBQUM7b0JBQ1QsOENBQThDO29CQUM5QyxRQUFRLEVBQUUsOENBQThDO29CQUN4RCxTQUFTLEVBQUUsQ0FBQzs0QkFDVixPQUFPLEVBQUUsc0JBQXNCOzRCQUMvQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxzQkFBc0IsQ0FBQzs0QkFDcEQsS0FBSyxFQUFFLElBQUk7eUJBQ1osQ0FBQztpQkFDSDt1R0FZQyxTQUFTO3NCQURSLFlBQVk7dUJBQUMsTUFBTTtnQkFHUCxvQkFBb0I7c0JBQWhDLEtBQUs7Z0JBbUNOLFFBQVE7c0JBRFAsWUFBWTt1QkFBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLENBQUM7O0FBbURwQyxNQUFNLGlCQUFpQixHQUEwQjtJQUMvQyxjQUFjLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRTtJQUN4QixnQkFBZ0IsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO0NBQ3pCLENBQUM7QUFFVCxNQUFNLGFBQWEsR0FBYztJQUMvQixXQUFXLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO0NBQ25CLENBQUM7QUFNVCxNQUFNLE9BQU8sZ0JBQWdCO0lBS2pCO0lBQ0E7SUFDb0I7SUFOdEIsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM5QixFQUFFLENBQVM7SUFFWCxZQUNVLE9BQW1CLEVBQ25CLFFBQW1CLEVBQ0MsV0FBa0M7UUFGdEQsWUFBTyxHQUFQLE9BQU8sQ0FBWTtRQUNuQixhQUFRLEdBQVIsUUFBUSxDQUFXO1FBQ0MsZ0JBQVcsR0FBWCxXQUFXLENBQXVCO1FBRTlELElBQUksQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztRQUN2RCxJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsSUFBSSxpQkFBaUIsQ0FBQztRQUNwRCxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDOUMsQ0FBQztJQUVELElBQ0ksS0FBSyxDQUFDLEtBQVU7UUFDbEIsK0RBQStEO1FBQy9ELG1FQUFtRTtRQUNuRSw0REFBNEQ7UUFDNUQsZ0JBQWdCO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7WUFDMUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMxRSxDQUFDO1FBRUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFRCxXQUFXO1FBQ1QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDN0MsQ0FBQzt1R0E5QlUsZ0JBQWdCOzJGQUFoQixnQkFBZ0I7OzJGQUFoQixnQkFBZ0I7a0JBSjVCLFNBQVM7bUJBQUM7b0JBQ1QsOENBQThDO29CQUM5QyxRQUFRLEVBQUUsUUFBUTtpQkFDbkI7OzBCQVFJLElBQUk7OzBCQUFJLFFBQVE7eUNBUWYsS0FBSztzQkFEUixLQUFLO3VCQUFDLE9BQU8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBEaXJlY3RpdmUsXG4gIEVsZW1lbnRSZWYsXG4gIGZvcndhcmRSZWYsXG4gIEhvc3QsXG4gIEhvc3RMaXN0ZW5lcixcbiAgSW5wdXQsXG4gIE9uRGVzdHJveSxcbiAgT3B0aW9uYWwsXG4gIFJlbmRlcmVyMixcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IEZvcm1Db250cm9sU3RhdGUgfSBmcm9tICcuLi9zdGF0ZSc7XG5pbXBvcnQgeyBGb3JtVmlld0FkYXB0ZXIsIE5HUlhfRk9STV9WSUVXX0FEQVBURVIgfSBmcm9tICcuL3ZpZXctYWRhcHRlcic7XG5cbi8vIHRzbGludDpkaXNhYmxlOmRpcmVjdGl2ZS1jbGFzcy1zdWZmaXhcblxuQERpcmVjdGl2ZSh7XG4gIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpkaXJlY3RpdmUtc2VsZWN0b3JcbiAgc2VsZWN0b3I6ICdzZWxlY3Q6bm90KFttdWx0aXBsZV0pW25ncnhGb3JtQ29udHJvbFN0YXRlXScsXG4gIHByb3ZpZGVyczogW3tcbiAgICBwcm92aWRlOiBOR1JYX0ZPUk1fVklFV19BREFQVEVSLFxuICAgIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IE5ncnhTZWxlY3RWaWV3QWRhcHRlciksXG4gICAgbXVsdGk6IHRydWUsXG4gIH1dLFxufSlcbmV4cG9ydCBjbGFzcyBOZ3J4U2VsZWN0Vmlld0FkYXB0ZXIgaW1wbGVtZW50cyBGb3JtVmlld0FkYXB0ZXIsIEFmdGVyVmlld0luaXQge1xuICBwcml2YXRlIHN0YXRlOiBGb3JtQ29udHJvbFN0YXRlPGFueT47XG4gIHByaXZhdGUgb3B0aW9uTWFwOiB7IFtpZDogc3RyaW5nXTogYW55IH0gPSB7fTtcbiAgcHJpdmF0ZSBpZENvdW50ZXIgPSAwO1xuICBwcml2YXRlIHNlbGVjdGVkSWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIHZhbHVlOiBhbnkgPSB1bmRlZmluZWQ7XG4gIHByaXZhdGUgbmF0aXZlSWRXYXNTZXQgPSBmYWxzZTtcblxuICBvbkNoYW5nZUZuOiAodmFsdWU6IGFueSkgPT4gdm9pZCA9ICgpID0+IHZvaWQgMDtcblxuICBASG9zdExpc3RlbmVyKCdibHVyJylcbiAgb25Ub3VjaGVkOiAoKSA9PiB2b2lkID0gKCkgPT4gdm9pZCAwXG5cbiAgQElucHV0KCkgc2V0IG5ncnhGb3JtQ29udHJvbFN0YXRlKHZhbHVlOiBGb3JtQ29udHJvbFN0YXRlPGFueT4pIHtcbiAgICBpZiAoIXZhbHVlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoZSBjb250cm9sIHN0YXRlIG11c3Qgbm90IGJlIHVuZGVmaW5lZCEnKTtcbiAgICB9XG5cbiAgICB0aGlzLnN0YXRlID0gdmFsdWU7XG4gICAgY29uc3QgbmF0aXZlSWQgPSB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5pZDtcbiAgICBjb25zdCBzaG91bGRTZXROYXRpdmVJZCA9IHZhbHVlLmlkICE9PSBuYXRpdmVJZCAmJiB0aGlzLm5hdGl2ZUlkV2FzU2V0O1xuICAgIGlmIChzaG91bGRTZXROYXRpdmVJZCkge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRQcm9wZXJ0eSh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ2lkJywgdmFsdWUuaWQpO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVuZGVyZXI6IFJlbmRlcmVyMiwgcHJpdmF0ZSBlbGVtZW50UmVmOiBFbGVtZW50UmVmKSB7IH1cblxuICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgY29uc3QgbmF0aXZlSWQgPSB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5pZDtcbiAgICBjb25zdCBzaG91bGRTZXROYXRpdmVJZCA9IHRoaXMuc3RhdGUuaWQgIT09IG5hdGl2ZUlkICYmICFuYXRpdmVJZDtcbiAgICBpZiAoc2hvdWxkU2V0TmF0aXZlSWQpIHtcbiAgICAgIHRoaXMucmVuZGVyZXIuc2V0UHJvcGVydHkodGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsICdpZCcsIHRoaXMuc3RhdGUuaWQpO1xuICAgICAgdGhpcy5uYXRpdmVJZFdhc1NldCA9IHRydWU7XG4gICAgfVxuICB9XG5cbiAgc2V0Vmlld1ZhbHVlKHZhbHVlOiBhbnkpIHtcbiAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gICAgdGhpcy5zZWxlY3RlZElkID0gdGhpcy5nZXRPcHRpb25JZCh2YWx1ZSk7XG4gICAgaWYgKHRoaXMuc2VsZWN0ZWRJZCA9PT0gbnVsbCkge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRQcm9wZXJ0eSh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ3NlbGVjdGVkSW5kZXgnLCAtMSk7XG4gICAgfVxuXG4gICAgdGhpcy5yZW5kZXJlci5zZXRQcm9wZXJ0eSh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ3ZhbHVlJywgdGhpcy5zZWxlY3RlZElkKTtcbiAgfVxuXG4gIEBIb3N0TGlzdGVuZXIoJ2NoYW5nZScsIFsnJGV2ZW50J10pXG4gIG9uQ2hhbmdlKHsgdGFyZ2V0IH06IHsgdGFyZ2V0OiBIVE1MT3B0aW9uRWxlbWVudCB9KSB7XG4gICAgdGhpcy5zZWxlY3RlZElkID0gdGFyZ2V0LnZhbHVlO1xuICAgIGNvbnN0IHZhbHVlID0gdGhpcy5vcHRpb25NYXBbdGhpcy5zZWxlY3RlZElkXTtcbiAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gICAgdGhpcy5vbkNoYW5nZUZuKHZhbHVlKTtcbiAgfVxuXG4gIHNldE9uQ2hhbmdlQ2FsbGJhY2soZm46ICh2YWx1ZTogYW55KSA9PiB2b2lkKSB7XG4gICAgdGhpcy5vbkNoYW5nZUZuID0gZm47XG4gIH1cblxuICBzZXRPblRvdWNoZWRDYWxsYmFjayhmbjogKCkgPT4gdm9pZCkge1xuICAgIHRoaXMub25Ub3VjaGVkID0gZm47XG4gIH1cblxuICBzZXRJc0Rpc2FibGVkKGlzRGlzYWJsZWQ6IGJvb2xlYW4pIHtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFByb3BlcnR5KHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCAnZGlzYWJsZWQnLCBpc0Rpc2FibGVkKTtcbiAgfVxuXG4gIGNyZWF0ZU9wdGlvbklkKCkge1xuICAgIGNvbnN0IGlkID0gdGhpcy5pZENvdW50ZXIudG9TdHJpbmcoKTtcbiAgICB0aGlzLmlkQ291bnRlciArPSAxO1xuICAgIHJldHVybiBpZDtcbiAgfVxuXG4gIHVwZGF0ZU9wdGlvblZhbHVlKGlkOiBzdHJpbmcsIHZhbHVlOiBhbnkpIHtcbiAgICB0aGlzLm9wdGlvbk1hcFtpZF0gPSB2YWx1ZTtcblxuICAgIGlmICh0aGlzLnNlbGVjdGVkSWQgPT09IGlkKSB7XG4gICAgICB0aGlzLm9uQ2hhbmdlRm4odmFsdWUpO1xuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IHRoaXMudmFsdWUpIHtcbiAgICAgIHRoaXMuc2V0Vmlld1ZhbHVlKHZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBkZXJlZ2lzdGVyT3B0aW9uKGlkOiBzdHJpbmcpIHtcbiAgICBkZWxldGUgdGhpcy5vcHRpb25NYXBbaWRdO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRPcHRpb25JZCh2YWx1ZTogYW55KSB7XG4gICAgZm9yIChjb25zdCBpZCBvZiBBcnJheS5mcm9tKE9iamVjdC5rZXlzKHRoaXMub3B0aW9uTWFwKSkpIHtcbiAgICAgIGlmICh0aGlzLm9wdGlvbk1hcFtpZF0gPT09IHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpZDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5jb25zdCBOVUxMX1ZJRVdfQURBUFRFUjogTmdyeFNlbGVjdFZpZXdBZGFwdGVyID0ge1xuICBjcmVhdGVPcHRpb25JZDogKCkgPT4gJycsXG4gIGRlcmVnaXN0ZXJPcHRpb246ICgpID0+IHZvaWQgMCxcbiAgdXBkYXRlT3B0aW9uVmFsdWU6ICgpID0+IHZvaWQgMCxcbn0gYXMgYW55O1xuXG5jb25zdCBOVUxMX1JFTkRFUkVSOiBSZW5kZXJlcjIgPSB7XG4gIHNldFByb3BlcnR5OiAoKSA9PiB2b2lkIDAsXG59IGFzIGFueTtcblxuQERpcmVjdGl2ZSh7XG4gIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpkaXJlY3RpdmUtc2VsZWN0b3JcbiAgc2VsZWN0b3I6ICdvcHRpb24nLFxufSlcbmV4cG9ydCBjbGFzcyBOZ3J4U2VsZWN0T3B0aW9uIGltcGxlbWVudHMgT25EZXN0cm95IHtcbiAgcHJpdmF0ZSBpc0luaXRpYWxpemVkID0gZmFsc2U7XG4gIGlkOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBlbGVtZW50OiBFbGVtZW50UmVmLFxuICAgIHByaXZhdGUgcmVuZGVyZXI6IFJlbmRlcmVyMixcbiAgICBASG9zdCgpIEBPcHRpb25hbCgpIHByaXZhdGUgdmlld0FkYXB0ZXI6IE5ncnhTZWxlY3RWaWV3QWRhcHRlcixcbiAgKSB7XG4gICAgdGhpcy5yZW5kZXJlciA9IHZpZXdBZGFwdGVyID8gcmVuZGVyZXIgOiBOVUxMX1JFTkRFUkVSO1xuICAgIHRoaXMudmlld0FkYXB0ZXIgPSB2aWV3QWRhcHRlciB8fCBOVUxMX1ZJRVdfQURBUFRFUjtcbiAgICB0aGlzLmlkID0gdGhpcy52aWV3QWRhcHRlci5jcmVhdGVPcHRpb25JZCgpO1xuICB9XG5cbiAgQElucHV0KCd2YWx1ZScpXG4gIHNldCB2YWx1ZSh2YWx1ZTogYW55KSB7XG4gICAgLy8gdGhpcyBjYW5ub3QgYmUgZG9uZSBpbnNpZGUgbmdPbkluaXQgc2luY2UgdGhlIHZhbHVlIHByb3BlcnR5XG4gICAgLy8gbXVzdCBiZSBhbHJlYWR5IHNldCB3aGVuIHRoZSBvcHRpb24gdmFsdWUgaXMgdXBkYXRlZCBpbiB0aGUgdmlld1xuICAgIC8vIGFkYXB0ZXIgYW5kIHRoZSBpbml0aWFsIGJpbmRpbmcgb2YgJ3ZhbHVlJyBoYXBwZW5zIGJlZm9yZVxuICAgIC8vIG5nT25Jbml0IHJ1bnNcbiAgICBpZiAoIXRoaXMuaXNJbml0aWFsaXplZCkge1xuICAgICAgdGhpcy5pc0luaXRpYWxpemVkID0gdHJ1ZTtcbiAgICAgIHRoaXMucmVuZGVyZXIuc2V0UHJvcGVydHkodGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICd2YWx1ZScsIHRoaXMuaWQpO1xuICAgIH1cblxuICAgIHRoaXMudmlld0FkYXB0ZXIudXBkYXRlT3B0aW9uVmFsdWUodGhpcy5pZCwgdmFsdWUpO1xuICB9XG5cbiAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgdGhpcy52aWV3QWRhcHRlci5kZXJlZ2lzdGVyT3B0aW9uKHRoaXMuaWQpO1xuICB9XG59XG4iXX0=