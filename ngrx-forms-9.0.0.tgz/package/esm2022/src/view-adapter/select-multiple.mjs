import { Directive, forwardRef, Host, HostListener, Input, Optional, } from '@angular/core';
import { NGRX_FORM_VIEW_ADAPTER } from './view-adapter';
import * as i0 from "@angular/core";
// tslint:disable:directive-class-suffix
export class NgrxSelectMultipleViewAdapter {
    renderer;
    elementRef;
    state;
    options = {};
    optionValues = {};
    idCounter = 0;
    selectedIds = [];
    nativeIdWasSet = false;
    onChangeFn = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        if (value === null) {
            value = [];
        }
        if (!Array.isArray(value)) {
            throw new Error(`the value provided to a NgrxSelectMultipleViewAdapter must be null or an array; got ${value} of type ${typeof value}`); // `
        }
        this.selectedIds = value.map(v => this.getOptionId(v)).filter(id => id !== null).map(id => id);
        Object.keys(this.options).forEach(id => this.options[id].isSelected = this.selectedIds.indexOf(id) >= 0);
    }
    onChange() {
        this.selectedIds = Object.keys(this.options).filter(id => this.options[id].isSelected);
        const value = this.selectedIds.map(id => this.optionValues[id]);
        this.onChangeFn(value);
    }
    setOnChangeCallback(fn) {
        this.onChangeFn = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    registerOption(option) {
        const id = this.idCounter.toString();
        this.options[id] = option;
        this.idCounter += 1;
        return id;
    }
    updateOptionValue(id, value) {
        this.optionValues[id] = value;
        if (this.selectedIds.indexOf(id) >= 0) {
            this.onChange();
        }
    }
    deregisterOption(id) {
        delete this.options[id];
        delete this.optionValues[id];
    }
    getOptionId(value) {
        for (const id of Array.from(Object.keys(this.optionValues))) {
            if (this.optionValues[id] === value) {
                return id;
            }
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectMultipleViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxSelectMultipleViewAdapter, selector: "select[multiple][ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "change": "onChange()" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxSelectMultipleViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectMultipleViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'select[multiple][ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxSelectMultipleViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], onChange: [{
                type: HostListener,
                args: ['change']
            }] } });
const NULL_VIEW_ADAPTER = {
    registerOption: () => '',
    deregisterOption: () => void 0,
    updateOptionValue: () => void 0,
};
const NULL_RENDERER = {
    setProperty: () => void 0,
};
export class NgrxSelectMultipleOption {
    element;
    renderer;
    viewAdapter;
    id;
    constructor(element, renderer, viewAdapter) {
        this.element = element;
        this.renderer = renderer;
        this.viewAdapter = viewAdapter;
        this.renderer = viewAdapter ? renderer : NULL_RENDERER;
        this.viewAdapter = viewAdapter || NULL_VIEW_ADAPTER;
        this.id = this.viewAdapter.registerOption(this);
    }
    set value(value) {
        this.viewAdapter.updateOptionValue(this.id, value);
    }
    set isSelected(selected) {
        this.renderer.setProperty(this.element.nativeElement, 'selected', selected);
    }
    get isSelected() {
        return this.element.nativeElement.selected;
    }
    ngOnInit() {
        this.renderer.setProperty(this.element.nativeElement, 'value', this.id);
    }
    ngOnDestroy() {
        this.viewAdapter.deregisterOption(this.id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectMultipleOption, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: NgrxSelectMultipleViewAdapter, host: true, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxSelectMultipleOption, selector: "option", inputs: { value: "value" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxSelectMultipleOption, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'option',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: NgrxSelectMultipleViewAdapter, decorators: [{
                    type: Host
                }, {
                    type: Optional
                }] }], propDecorators: { value: [{
                type: Input,
                args: ['value']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0LW11bHRpcGxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3ZpZXctYWRhcHRlci9zZWxlY3QtbXVsdGlwbGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLFNBQVMsRUFFVCxVQUFVLEVBQ1YsSUFBSSxFQUNKLFlBQVksRUFDWixLQUFLLEVBR0wsUUFBUSxHQUVULE1BQU0sZUFBZSxDQUFDO0FBR3ZCLE9BQU8sRUFBbUIsc0JBQXNCLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7QUFFekUsd0NBQXdDO0FBV3hDLE1BQU0sT0FBTyw2QkFBNkI7SUEwQnBCO0lBQTZCO0lBekJ6QyxLQUFLLENBQXdCO0lBQzdCLE9BQU8sR0FBK0MsRUFBRSxDQUFDO0lBQ3pELFlBQVksR0FBMEIsRUFBRSxDQUFDO0lBQ3pDLFNBQVMsR0FBRyxDQUFDLENBQUM7SUFDZCxXQUFXLEdBQWEsRUFBRSxDQUFDO0lBQzNCLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFFL0IsVUFBVSxHQUF5QixHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUdoRCxTQUFTLEdBQWUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFcEMsSUFBYSxvQkFBb0IsQ0FBQyxLQUE0QjtRQUM1RCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDWCxNQUFNLElBQUksS0FBSyxDQUFDLDBDQUEwQyxDQUFDLENBQUM7UUFDOUQsQ0FBQztRQUVELElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ25CLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztRQUNsRCxNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxFQUFFLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDdkUsSUFBSSxpQkFBaUIsRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDM0UsQ0FBQztJQUNILENBQUM7SUFFRCxZQUFvQixRQUFtQixFQUFVLFVBQXNCO1FBQW5ELGFBQVEsR0FBUixRQUFRLENBQVc7UUFBVSxlQUFVLEdBQVYsVUFBVSxDQUFZO0lBQUksQ0FBQztJQUU1RSxlQUFlO1FBQ2IsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO1FBQ2xELE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLEtBQUssUUFBUSxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ2xFLElBQUksaUJBQWlCLEVBQUUsQ0FBQztZQUN0QixJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUM5RSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztRQUM3QixDQUFDO0lBQ0gsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFVO1FBQ3JCLElBQUksS0FBSyxLQUFLLElBQUksRUFBRSxDQUFDO1lBQ25CLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDYixDQUFDO1FBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUMxQixNQUFNLElBQUksS0FBSyxDQUFDLHVGQUF1RixLQUFLLFlBQVksT0FBTyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSTtRQUMvSSxDQUFDO1FBRUQsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFZLENBQUMsQ0FBQztRQUN6RyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUMzRyxDQUFDO0lBR0QsUUFBUTtRQUNOLElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN2RixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3pCLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxFQUF3QjtRQUMxQyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRUQsb0JBQW9CLENBQUMsRUFBYztRQUNqQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsYUFBYSxDQUFDLFVBQW1CO1FBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUNuRixDQUFDO0lBRUQsY0FBYyxDQUFDLE1BQWdDO1FBQzdDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDckMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUM7UUFDMUIsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUM7UUFDcEIsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0lBRUQsaUJBQWlCLENBQUMsRUFBVSxFQUFFLEtBQVU7UUFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUM7UUFFOUIsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDbEIsQ0FBQztJQUNILENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUFVO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN4QixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVPLFdBQVcsQ0FBQyxLQUFVO1FBQzVCLEtBQUssTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDNUQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLEtBQUssRUFBRSxDQUFDO2dCQUNwQyxPQUFPLEVBQUUsQ0FBQztZQUNaLENBQUM7UUFDSCxDQUFDO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO3VHQWpHVSw2QkFBNkI7MkZBQTdCLDZCQUE2QixtTUFON0IsQ0FBQztnQkFDVixPQUFPLEVBQUUsc0JBQXNCO2dCQUMvQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLDZCQUE2QixDQUFDO2dCQUM1RCxLQUFLLEVBQUUsSUFBSTthQUNaLENBQUM7OzJGQUVTLDZCQUE2QjtrQkFUekMsU0FBUzttQkFBQztvQkFDVCw4Q0FBOEM7b0JBQzlDLFFBQVEsRUFBRSx3Q0FBd0M7b0JBQ2xELFNBQVMsRUFBRSxDQUFDOzRCQUNWLE9BQU8sRUFBRSxzQkFBc0I7NEJBQy9CLFdBQVcsRUFBRSxVQUFVLENBQUMsR0FBRyxFQUFFLDhCQUE4QixDQUFDOzRCQUM1RCxLQUFLLEVBQUUsSUFBSTt5QkFDWixDQUFDO2lCQUNIO3VHQVlDLFNBQVM7c0JBRFIsWUFBWTt1QkFBQyxNQUFNO2dCQUdQLG9CQUFvQjtzQkFBaEMsS0FBSztnQkFzQ04sUUFBUTtzQkFEUCxZQUFZO3VCQUFDLFFBQVE7O0FBa0R4QixNQUFNLGlCQUFpQixHQUFrQztJQUN2RCxjQUFjLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRTtJQUN4QixnQkFBZ0IsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO0NBQ3pCLENBQUM7QUFFVCxNQUFNLGFBQWEsR0FBYztJQUMvQixXQUFXLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO0NBQ25CLENBQUM7QUFNVCxNQUFNLE9BQU8sd0JBQXdCO0lBSXpCO0lBQ0E7SUFDb0I7SUFMOUIsRUFBRSxDQUFTO0lBRVgsWUFDVSxPQUFtQixFQUNuQixRQUFtQixFQUNDLFdBQTBDO1FBRjlELFlBQU8sR0FBUCxPQUFPLENBQVk7UUFDbkIsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQUNDLGdCQUFXLEdBQVgsV0FBVyxDQUErQjtRQUV0RSxJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7UUFDdkQsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLElBQUksaUJBQWlCLENBQUM7UUFDcEQsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRUQsSUFDSSxLQUFLLENBQUMsS0FBVTtRQUNsQixJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVELElBQUksVUFBVSxDQUFDLFFBQWlCO1FBQzlCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztJQUM5RSxDQUFDO0lBRUQsSUFBSSxVQUFVO1FBQ1osT0FBUSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQW1DLENBQUMsUUFBUSxDQUFDO0lBQ3BFLENBQUM7SUFFRCxRQUFRO1FBQ04sSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMxRSxDQUFDO0lBRUQsV0FBVztRQUNULElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzdDLENBQUM7dUdBaENVLHdCQUF3QjsyRkFBeEIsd0JBQXdCOzsyRkFBeEIsd0JBQXdCO2tCQUpwQyxTQUFTO21CQUFDO29CQUNULDhDQUE4QztvQkFDOUMsUUFBUSxFQUFFLFFBQVE7aUJBQ25COzswQkFPSSxJQUFJOzswQkFBSSxRQUFRO3lDQVFmLEtBQUs7c0JBRFIsS0FBSzt1QkFBQyxPQUFPIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgRGlyZWN0aXZlLFxuICBFbGVtZW50UmVmLFxuICBmb3J3YXJkUmVmLFxuICBIb3N0LFxuICBIb3N0TGlzdGVuZXIsXG4gIElucHV0LFxuICBPbkRlc3Ryb3ksXG4gIE9uSW5pdCxcbiAgT3B0aW9uYWwsXG4gIFJlbmRlcmVyMixcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IEZvcm1Db250cm9sU3RhdGUgfSBmcm9tICcuLi9zdGF0ZSc7XG5pbXBvcnQgeyBGb3JtVmlld0FkYXB0ZXIsIE5HUlhfRk9STV9WSUVXX0FEQVBURVIgfSBmcm9tICcuL3ZpZXctYWRhcHRlcic7XG5cbi8vIHRzbGludDpkaXNhYmxlOmRpcmVjdGl2ZS1jbGFzcy1zdWZmaXhcblxuQERpcmVjdGl2ZSh7XG4gIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpkaXJlY3RpdmUtc2VsZWN0b3JcbiAgc2VsZWN0b3I6ICdzZWxlY3RbbXVsdGlwbGVdW25ncnhGb3JtQ29udHJvbFN0YXRlXScsXG4gIHByb3ZpZGVyczogW3tcbiAgICBwcm92aWRlOiBOR1JYX0ZPUk1fVklFV19BREFQVEVSLFxuICAgIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IE5ncnhTZWxlY3RNdWx0aXBsZVZpZXdBZGFwdGVyKSxcbiAgICBtdWx0aTogdHJ1ZSxcbiAgfV0sXG59KVxuZXhwb3J0IGNsYXNzIE5ncnhTZWxlY3RNdWx0aXBsZVZpZXdBZGFwdGVyIGltcGxlbWVudHMgRm9ybVZpZXdBZGFwdGVyLCBBZnRlclZpZXdJbml0IHtcbiAgcHJpdmF0ZSBzdGF0ZTogRm9ybUNvbnRyb2xTdGF0ZTxhbnk+O1xuICBwcml2YXRlIG9wdGlvbnM6IHsgW2lkOiBzdHJpbmddOiBOZ3J4U2VsZWN0TXVsdGlwbGVPcHRpb24gfSA9IHt9O1xuICBwcml2YXRlIG9wdGlvblZhbHVlczogeyBbaWQ6IHN0cmluZ106IGFueSB9ID0ge307XG4gIHByaXZhdGUgaWRDb3VudGVyID0gMDtcbiAgcHJpdmF0ZSBzZWxlY3RlZElkczogc3RyaW5nW10gPSBbXTtcbiAgcHJpdmF0ZSBuYXRpdmVJZFdhc1NldCA9IGZhbHNlO1xuXG4gIG9uQ2hhbmdlRm46ICh2YWx1ZTogYW55KSA9PiB2b2lkID0gKCkgPT4gdm9pZCAwO1xuXG4gIEBIb3N0TGlzdGVuZXIoJ2JsdXInKVxuICBvblRvdWNoZWQ6ICgpID0+IHZvaWQgPSAoKSA9PiB2b2lkIDBcblxuICBASW5wdXQoKSBzZXQgbmdyeEZvcm1Db250cm9sU3RhdGUodmFsdWU6IEZvcm1Db250cm9sU3RhdGU8YW55Pikge1xuICAgIGlmICghdmFsdWUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVGhlIGNvbnRyb2wgc3RhdGUgbXVzdCBub3QgYmUgdW5kZWZpbmVkIScpO1xuICAgIH1cblxuICAgIHRoaXMuc3RhdGUgPSB2YWx1ZTtcbiAgICBjb25zdCBuYXRpdmVJZCA9IHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmlkO1xuICAgIGNvbnN0IHNob3VsZFNldE5hdGl2ZUlkID0gdmFsdWUuaWQgIT09IG5hdGl2ZUlkICYmIHRoaXMubmF0aXZlSWRXYXNTZXQ7XG4gICAgaWYgKHNob3VsZFNldE5hdGl2ZUlkKSB7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldFByb3BlcnR5KHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCAnaWQnLCB2YWx1ZS5pZCk7XG4gICAgfVxuICB9XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyLCBwcml2YXRlIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYpIHsgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICBjb25zdCBuYXRpdmVJZCA9IHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmlkO1xuICAgIGNvbnN0IHNob3VsZFNldE5hdGl2ZUlkID0gdGhpcy5zdGF0ZS5pZCAhPT0gbmF0aXZlSWQgJiYgIW5hdGl2ZUlkO1xuICAgIGlmIChzaG91bGRTZXROYXRpdmVJZCkge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRQcm9wZXJ0eSh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ2lkJywgdGhpcy5zdGF0ZS5pZCk7XG4gICAgICB0aGlzLm5hdGl2ZUlkV2FzU2V0ID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICBzZXRWaWV3VmFsdWUodmFsdWU6IGFueSkge1xuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgdmFsdWUgPSBbXTtcbiAgICB9XG5cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYHRoZSB2YWx1ZSBwcm92aWRlZCB0byBhIE5ncnhTZWxlY3RNdWx0aXBsZVZpZXdBZGFwdGVyIG11c3QgYmUgbnVsbCBvciBhbiBhcnJheTsgZ290ICR7dmFsdWV9IG9mIHR5cGUgJHt0eXBlb2YgdmFsdWV9YCk7IC8vIGBcbiAgICB9XG5cbiAgICB0aGlzLnNlbGVjdGVkSWRzID0gdmFsdWUubWFwKHYgPT4gdGhpcy5nZXRPcHRpb25JZCh2KSkuZmlsdGVyKGlkID0+IGlkICE9PSBudWxsKS5tYXAoaWQgPT4gaWQgYXMgc3RyaW5nKTtcbiAgICBPYmplY3Qua2V5cyh0aGlzLm9wdGlvbnMpLmZvckVhY2goaWQgPT4gdGhpcy5vcHRpb25zW2lkXS5pc1NlbGVjdGVkID0gdGhpcy5zZWxlY3RlZElkcy5pbmRleE9mKGlkKSA+PSAwKTtcbiAgfVxuXG4gIEBIb3N0TGlzdGVuZXIoJ2NoYW5nZScpXG4gIG9uQ2hhbmdlKCkge1xuICAgIHRoaXMuc2VsZWN0ZWRJZHMgPSBPYmplY3Qua2V5cyh0aGlzLm9wdGlvbnMpLmZpbHRlcihpZCA9PiB0aGlzLm9wdGlvbnNbaWRdLmlzU2VsZWN0ZWQpO1xuICAgIGNvbnN0IHZhbHVlID0gdGhpcy5zZWxlY3RlZElkcy5tYXAoaWQgPT4gdGhpcy5vcHRpb25WYWx1ZXNbaWRdKTtcbiAgICB0aGlzLm9uQ2hhbmdlRm4odmFsdWUpO1xuICB9XG5cbiAgc2V0T25DaGFuZ2VDYWxsYmFjayhmbjogKHZhbHVlOiBhbnkpID0+IHZvaWQpIHtcbiAgICB0aGlzLm9uQ2hhbmdlRm4gPSBmbjtcbiAgfVxuXG4gIHNldE9uVG91Y2hlZENhbGxiYWNrKGZuOiAoKSA9PiB2b2lkKSB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmbjtcbiAgfVxuXG4gIHNldElzRGlzYWJsZWQoaXNEaXNhYmxlZDogYm9vbGVhbikge1xuICAgIHRoaXMucmVuZGVyZXIuc2V0UHJvcGVydHkodGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsICdkaXNhYmxlZCcsIGlzRGlzYWJsZWQpO1xuICB9XG5cbiAgcmVnaXN0ZXJPcHRpb24ob3B0aW9uOiBOZ3J4U2VsZWN0TXVsdGlwbGVPcHRpb24pIHtcbiAgICBjb25zdCBpZCA9IHRoaXMuaWRDb3VudGVyLnRvU3RyaW5nKCk7XG4gICAgdGhpcy5vcHRpb25zW2lkXSA9IG9wdGlvbjtcbiAgICB0aGlzLmlkQ291bnRlciArPSAxO1xuICAgIHJldHVybiBpZDtcbiAgfVxuXG4gIHVwZGF0ZU9wdGlvblZhbHVlKGlkOiBzdHJpbmcsIHZhbHVlOiBhbnkpIHtcbiAgICB0aGlzLm9wdGlvblZhbHVlc1tpZF0gPSB2YWx1ZTtcblxuICAgIGlmICh0aGlzLnNlbGVjdGVkSWRzLmluZGV4T2YoaWQpID49IDApIHtcbiAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICB9XG4gIH1cblxuICBkZXJlZ2lzdGVyT3B0aW9uKGlkOiBzdHJpbmcpIHtcbiAgICBkZWxldGUgdGhpcy5vcHRpb25zW2lkXTtcbiAgICBkZWxldGUgdGhpcy5vcHRpb25WYWx1ZXNbaWRdO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRPcHRpb25JZCh2YWx1ZTogYW55KSB7XG4gICAgZm9yIChjb25zdCBpZCBvZiBBcnJheS5mcm9tKE9iamVjdC5rZXlzKHRoaXMub3B0aW9uVmFsdWVzKSkpIHtcbiAgICAgIGlmICh0aGlzLm9wdGlvblZhbHVlc1tpZF0gPT09IHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpZDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5jb25zdCBOVUxMX1ZJRVdfQURBUFRFUjogTmdyeFNlbGVjdE11bHRpcGxlVmlld0FkYXB0ZXIgPSB7XG4gIHJlZ2lzdGVyT3B0aW9uOiAoKSA9PiAnJyxcbiAgZGVyZWdpc3Rlck9wdGlvbjogKCkgPT4gdm9pZCAwLFxuICB1cGRhdGVPcHRpb25WYWx1ZTogKCkgPT4gdm9pZCAwLFxufSBhcyBhbnk7XG5cbmNvbnN0IE5VTExfUkVOREVSRVI6IFJlbmRlcmVyMiA9IHtcbiAgc2V0UHJvcGVydHk6ICgpID0+IHZvaWQgMCxcbn0gYXMgYW55O1xuXG5ARGlyZWN0aXZlKHtcbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOmRpcmVjdGl2ZS1zZWxlY3RvclxuICBzZWxlY3RvcjogJ29wdGlvbicsXG59KVxuZXhwb3J0IGNsYXNzIE5ncnhTZWxlY3RNdWx0aXBsZU9wdGlvbiBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcbiAgaWQ6IHN0cmluZztcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGVsZW1lbnQ6IEVsZW1lbnRSZWYsXG4gICAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyLFxuICAgIEBIb3N0KCkgQE9wdGlvbmFsKCkgcHJpdmF0ZSB2aWV3QWRhcHRlcjogTmdyeFNlbGVjdE11bHRpcGxlVmlld0FkYXB0ZXIsXG4gICkge1xuICAgIHRoaXMucmVuZGVyZXIgPSB2aWV3QWRhcHRlciA/IHJlbmRlcmVyIDogTlVMTF9SRU5ERVJFUjtcbiAgICB0aGlzLnZpZXdBZGFwdGVyID0gdmlld0FkYXB0ZXIgfHwgTlVMTF9WSUVXX0FEQVBURVI7XG4gICAgdGhpcy5pZCA9IHRoaXMudmlld0FkYXB0ZXIucmVnaXN0ZXJPcHRpb24odGhpcyk7XG4gIH1cblxuICBASW5wdXQoJ3ZhbHVlJylcbiAgc2V0IHZhbHVlKHZhbHVlOiBhbnkpIHtcbiAgICB0aGlzLnZpZXdBZGFwdGVyLnVwZGF0ZU9wdGlvblZhbHVlKHRoaXMuaWQsIHZhbHVlKTtcbiAgfVxuXG4gIHNldCBpc1NlbGVjdGVkKHNlbGVjdGVkOiBib29sZWFuKSB7XG4gICAgdGhpcy5yZW5kZXJlci5zZXRQcm9wZXJ0eSh0aGlzLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ3NlbGVjdGVkJywgc2VsZWN0ZWQpO1xuICB9XG5cbiAgZ2V0IGlzU2VsZWN0ZWQoKSB7XG4gICAgcmV0dXJuICh0aGlzLmVsZW1lbnQubmF0aXZlRWxlbWVudCBhcyBIVE1MT3B0aW9uRWxlbWVudCkuc2VsZWN0ZWQ7XG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFByb3BlcnR5KHRoaXMuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAndmFsdWUnLCB0aGlzLmlkKTtcbiAgfVxuXG4gIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIHRoaXMudmlld0FkYXB0ZXIuZGVyZWdpc3Rlck9wdGlvbih0aGlzLmlkKTtcbiAgfVxufVxuIl19