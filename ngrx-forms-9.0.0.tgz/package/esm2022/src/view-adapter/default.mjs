import { isPlatformBrowser } from '@angular/common';
import { Directive, forwardRef, HostListener, Inject, Input, Optional, PLATFORM_ID } from '@angular/core';
import { NGRX_FORM_VIEW_ADAPTER } from './view-adapter';
import * as i0 from "@angular/core";
/**
 * We must check whether the agent is Android because composition events
 * behave differently between iOS and Android.
 */
function isAndroid(navigator) {
    return /android (\d+)/.test(navigator.userAgent.toLowerCase());
}
// tslint:disable:directive-class-suffix
// tslint:disable:directive-selector
// TODO: since this directive has a side-effect (setting the element's id attribute)
// it should not blacklist other types of inputs but instead it should somehow figure
// out whether it is the "active" view adapter and only perform its side effects if it
// is active
export class NgrxDefaultViewAdapter {
    renderer;
    elementRef;
    platformId;
    state;
    nativeIdWasSet = false;
    onChange = () => void 0;
    onTouched = () => void 0;
    set ngrxFormControlState(value) {
        if (!value) {
            throw new Error('The control state must not be undefined!');
        }
        this.state = value;
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = value.id !== nativeId && this.nativeIdWasSet;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', value.id);
        }
    }
    /** Whether the user is creating a composition string (IME events). */
    isComposing = false;
    isCompositionSupported;
    constructor(renderer, elementRef, platformId = null, 
    // we use a special injection string that should never exist at runtime to allow mocking this dependency for testing
    navigator = null) {
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.platformId = platformId;
        this.isCompositionSupported = isPlatformBrowser(this.platformId || '') && !isAndroid(navigator || window.navigator);
    }
    ngAfterViewInit() {
        const nativeId = this.elementRef.nativeElement.id;
        const shouldSetNativeId = this.state.id !== nativeId && !nativeId;
        if (shouldSetNativeId) {
            this.renderer.setProperty(this.elementRef.nativeElement, 'id', this.state.id);
            this.nativeIdWasSet = true;
        }
    }
    setViewValue(value) {
        const normalizedValue = value == null ? '' : value;
        this.renderer.setProperty(this.elementRef.nativeElement, 'value', normalizedValue);
    }
    setOnChangeCallback(fn) {
        this.onChange = fn;
    }
    setOnTouchedCallback(fn) {
        this.onTouched = fn;
    }
    setIsDisabled(isDisabled) {
        this.renderer.setProperty(this.elementRef.nativeElement, 'disabled', isDisabled);
    }
    handleInput({ target }) {
        if (this.isCompositionSupported && this.isComposing) {
            return;
        }
        this.onChange(target.value);
    }
    compositionStart() {
        this.isComposing = true;
    }
    compositionEnd({ target }) {
        this.isComposing = false;
        if (this.isCompositionSupported) {
            this.onChange(target.value);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxDefaultViewAdapter, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: PLATFORM_ID, optional: true }, { token: 'ngrx-forms/never', optional: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxDefaultViewAdapter, selector: "input:not([type=checkbox]):not([type=number]):not([type=radio]):not([type=range])[ngrxFormControlState],textarea[ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState" }, host: { listeners: { "blur": "onTouched()", "input": "handleInput($event)", "compositionstart": "compositionStart()", "compositionend": "compositionEnd($event)" } }, providers: [{
                provide: NGRX_FORM_VIEW_ADAPTER,
                useExisting: forwardRef(() => NgrxDefaultViewAdapter),
                multi: true,
            }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxDefaultViewAdapter, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input:not([type=checkbox]):not([type=number]):not([type=radio]):not([type=range])[ngrxFormControlState],textarea[ngrxFormControlState]',
                    providers: [{
                            provide: NGRX_FORM_VIEW_ADAPTER,
                            useExisting: forwardRef(() => NgrxDefaultViewAdapter),
                            multi: true,
                        }],
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: ['ngrx-forms/never']
                }] }], propDecorators: { onTouched: [{
                type: HostListener,
                args: ['blur']
            }], ngrxFormControlState: [{
                type: Input
            }], handleInput: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], compositionStart: [{
                type: HostListener,
                args: ['compositionstart']
            }], compositionEnd: [{
                type: HostListener,
                args: ['compositionend', ['$event']]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVmYXVsdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy92aWV3LWFkYXB0ZXIvZGVmYXVsdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNwRCxPQUFPLEVBQWlCLFNBQVMsRUFBYyxVQUFVLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBYSxNQUFNLGVBQWUsQ0FBQztBQUdoSixPQUFPLEVBQW1CLHNCQUFzQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7O0FBTXpFOzs7R0FHRztBQUNILFNBQVMsU0FBUyxDQUFDLFNBQW9CO0lBQ3JDLE9BQU8sZUFBZSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDakUsQ0FBQztBQUVELHdDQUF3QztBQUN4QyxvQ0FBb0M7QUFFcEMsb0ZBQW9GO0FBQ3BGLHFGQUFxRjtBQUNyRixzRkFBc0Y7QUFDdEYsWUFBWTtBQVNaLE1BQU0sT0FBTyxzQkFBc0I7SUEyQnZCO0lBQ0E7SUFDaUM7SUE1Qm5DLEtBQUssQ0FBd0I7SUFDN0IsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUUvQixRQUFRLEdBQXlCLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBRzlDLFNBQVMsR0FBZSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUVwQyxJQUFhLG9CQUFvQixDQUFDLEtBQTRCO1FBQzVELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNYLE1BQU0sSUFBSSxLQUFLLENBQUMsMENBQTBDLENBQUMsQ0FBQztRQUM5RCxDQUFDO1FBRUQsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO1FBQ2xELE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLEVBQUUsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUN2RSxJQUFJLGlCQUFpQixFQUFFLENBQUM7WUFDdEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMzRSxDQUFDO0lBQ0gsQ0FBQztJQUVELHNFQUFzRTtJQUM5RCxXQUFXLEdBQUcsS0FBSyxDQUFDO0lBQ3BCLHNCQUFzQixDQUFVO0lBRXhDLFlBQ1UsUUFBbUIsRUFDbkIsVUFBc0IsRUFDVyxhQUE0QixJQUFJO0lBQ3pFLG9IQUFvSDtJQUM1RSxZQUE4QixJQUFJO1FBSmxFLGFBQVEsR0FBUixRQUFRLENBQVc7UUFDbkIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUNXLGVBQVUsR0FBVixVQUFVLENBQXNCO1FBSXpFLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEgsQ0FBQztJQUVELGVBQWU7UUFDYixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUM7UUFDbEQsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsS0FBSyxRQUFRLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDbEUsSUFBSSxpQkFBaUIsRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzlFLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQzdCLENBQUM7SUFDSCxDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQVU7UUFDckIsTUFBTSxlQUFlLEdBQUcsS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDbkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxFQUF3QjtRQUMxQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQsb0JBQW9CLENBQUMsRUFBYztRQUNqQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsYUFBYSxDQUFDLFVBQW1CO1FBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUNuRixDQUFDO0lBR0QsV0FBVyxDQUFDLEVBQUUsTUFBTSxFQUFnQztRQUNsRCxJQUFJLElBQUksQ0FBQyxzQkFBc0IsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDcEQsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBR0QsZ0JBQWdCO1FBQ2QsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7SUFDMUIsQ0FBQztJQUdELGNBQWMsQ0FBQyxFQUFFLE1BQU0sRUFBZ0M7UUFDckQsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFDekIsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNoQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM5QixDQUFDO0lBQ0gsQ0FBQzt1R0FsRlUsc0JBQXNCLHFFQTZCWCxXQUFXLDZCQUVYLGtCQUFrQjsyRkEvQjdCLHNCQUFzQixpWUFOdEIsQ0FBQztnQkFDVixPQUFPLEVBQUUsc0JBQXNCO2dCQUMvQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLHNCQUFzQixDQUFDO2dCQUNyRCxLQUFLLEVBQUUsSUFBSTthQUNaLENBQUM7OzJGQUVTLHNCQUFzQjtrQkFSbEMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsd0lBQXdJO29CQUNsSixTQUFTLEVBQUUsQ0FBQzs0QkFDVixPQUFPLEVBQUUsc0JBQXNCOzRCQUMvQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSx1QkFBdUIsQ0FBQzs0QkFDckQsS0FBSyxFQUFFLElBQUk7eUJBQ1osQ0FBQztpQkFDSDs7MEJBOEJJLFFBQVE7OzBCQUFJLE1BQU07MkJBQUMsV0FBVzs7MEJBRTlCLFFBQVE7OzBCQUFJLE1BQU07MkJBQUMsa0JBQWtCO3lDQXhCeEMsU0FBUztzQkFEUixZQUFZO3VCQUFDLE1BQU07Z0JBR1Asb0JBQW9CO3NCQUFoQyxLQUFLO2dCQXNETixXQUFXO3NCQURWLFlBQVk7dUJBQUMsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDO2dCQVVqQyxnQkFBZ0I7c0JBRGYsWUFBWTt1QkFBQyxrQkFBa0I7Z0JBTWhDLGNBQWM7c0JBRGIsWUFBWTt1QkFBQyxnQkFBZ0IsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGlzUGxhdGZvcm1Ccm93c2VyIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IEFmdGVyVmlld0luaXQsIERpcmVjdGl2ZSwgRWxlbWVudFJlZiwgZm9yd2FyZFJlZiwgSG9zdExpc3RlbmVyLCBJbmplY3QsIElucHV0LCBPcHRpb25hbCwgUExBVEZPUk1fSUQsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBGb3JtQ29udHJvbFN0YXRlIH0gZnJvbSAnLi4vc3RhdGUnO1xuaW1wb3J0IHsgRm9ybVZpZXdBZGFwdGVyLCBOR1JYX0ZPUk1fVklFV19BREFQVEVSIH0gZnJvbSAnLi92aWV3LWFkYXB0ZXInO1xuXG5leHBvcnQgaW50ZXJmYWNlIE5hdmlnYXRvciB7XG4gIHVzZXJBZ2VudDogc3RyaW5nO1xufVxuXG4vKipcbiAqIFdlIG11c3QgY2hlY2sgd2hldGhlciB0aGUgYWdlbnQgaXMgQW5kcm9pZCBiZWNhdXNlIGNvbXBvc2l0aW9uIGV2ZW50c1xuICogYmVoYXZlIGRpZmZlcmVudGx5IGJldHdlZW4gaU9TIGFuZCBBbmRyb2lkLlxuICovXG5mdW5jdGlvbiBpc0FuZHJvaWQobmF2aWdhdG9yOiBOYXZpZ2F0b3IpOiBib29sZWFuIHtcbiAgcmV0dXJuIC9hbmRyb2lkIChcXGQrKS8udGVzdChuYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCkpO1xufVxuXG4vLyB0c2xpbnQ6ZGlzYWJsZTpkaXJlY3RpdmUtY2xhc3Mtc3VmZml4XG4vLyB0c2xpbnQ6ZGlzYWJsZTpkaXJlY3RpdmUtc2VsZWN0b3JcblxuLy8gVE9ETzogc2luY2UgdGhpcyBkaXJlY3RpdmUgaGFzIGEgc2lkZS1lZmZlY3QgKHNldHRpbmcgdGhlIGVsZW1lbnQncyBpZCBhdHRyaWJ1dGUpXG4vLyBpdCBzaG91bGQgbm90IGJsYWNrbGlzdCBvdGhlciB0eXBlcyBvZiBpbnB1dHMgYnV0IGluc3RlYWQgaXQgc2hvdWxkIHNvbWVob3cgZmlndXJlXG4vLyBvdXQgd2hldGhlciBpdCBpcyB0aGUgXCJhY3RpdmVcIiB2aWV3IGFkYXB0ZXIgYW5kIG9ubHkgcGVyZm9ybSBpdHMgc2lkZSBlZmZlY3RzIGlmIGl0XG4vLyBpcyBhY3RpdmVcbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ2lucHV0Om5vdChbdHlwZT1jaGVja2JveF0pOm5vdChbdHlwZT1udW1iZXJdKTpub3QoW3R5cGU9cmFkaW9dKTpub3QoW3R5cGU9cmFuZ2VdKVtuZ3J4Rm9ybUNvbnRyb2xTdGF0ZV0sdGV4dGFyZWFbbmdyeEZvcm1Db250cm9sU3RhdGVdJyxcbiAgcHJvdmlkZXJzOiBbe1xuICAgIHByb3ZpZGU6IE5HUlhfRk9STV9WSUVXX0FEQVBURVIsXG4gICAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gTmdyeERlZmF1bHRWaWV3QWRhcHRlciksXG4gICAgbXVsdGk6IHRydWUsXG4gIH1dLFxufSlcbmV4cG9ydCBjbGFzcyBOZ3J4RGVmYXVsdFZpZXdBZGFwdGVyIGltcGxlbWVudHMgRm9ybVZpZXdBZGFwdGVyLCBBZnRlclZpZXdJbml0IHtcbiAgcHJpdmF0ZSBzdGF0ZTogRm9ybUNvbnRyb2xTdGF0ZTxhbnk+O1xuICBwcml2YXRlIG5hdGl2ZUlkV2FzU2V0ID0gZmFsc2U7XG5cbiAgb25DaGFuZ2U6ICh2YWx1ZTogYW55KSA9PiB2b2lkID0gKCkgPT4gdm9pZCAwO1xuXG4gIEBIb3N0TGlzdGVuZXIoJ2JsdXInKVxuICBvblRvdWNoZWQ6ICgpID0+IHZvaWQgPSAoKSA9PiB2b2lkIDBcblxuICBASW5wdXQoKSBzZXQgbmdyeEZvcm1Db250cm9sU3RhdGUodmFsdWU6IEZvcm1Db250cm9sU3RhdGU8YW55Pikge1xuICAgIGlmICghdmFsdWUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVGhlIGNvbnRyb2wgc3RhdGUgbXVzdCBub3QgYmUgdW5kZWZpbmVkIScpO1xuICAgIH1cblxuICAgIHRoaXMuc3RhdGUgPSB2YWx1ZTtcbiAgICBjb25zdCBuYXRpdmVJZCA9IHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmlkO1xuICAgIGNvbnN0IHNob3VsZFNldE5hdGl2ZUlkID0gdmFsdWUuaWQgIT09IG5hdGl2ZUlkICYmIHRoaXMubmF0aXZlSWRXYXNTZXQ7XG4gICAgaWYgKHNob3VsZFNldE5hdGl2ZUlkKSB7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldFByb3BlcnR5KHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCAnaWQnLCB2YWx1ZS5pZCk7XG4gICAgfVxuICB9XG5cbiAgLyoqIFdoZXRoZXIgdGhlIHVzZXIgaXMgY3JlYXRpbmcgYSBjb21wb3NpdGlvbiBzdHJpbmcgKElNRSBldmVudHMpLiAqL1xuICBwcml2YXRlIGlzQ29tcG9zaW5nID0gZmFsc2U7XG4gIHByaXZhdGUgaXNDb21wb3NpdGlvblN1cHBvcnRlZDogYm9vbGVhbjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgcHJpdmF0ZSBlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuICAgIEBPcHRpb25hbCgpIEBJbmplY3QoUExBVEZPUk1fSUQpIHByaXZhdGUgcGxhdGZvcm1JZDogc3RyaW5nIHwgbnVsbCA9IG51bGwsXG4gICAgLy8gd2UgdXNlIGEgc3BlY2lhbCBpbmplY3Rpb24gc3RyaW5nIHRoYXQgc2hvdWxkIG5ldmVyIGV4aXN0IGF0IHJ1bnRpbWUgdG8gYWxsb3cgbW9ja2luZyB0aGlzIGRlcGVuZGVuY3kgZm9yIHRlc3RpbmdcbiAgICBAT3B0aW9uYWwoKSBASW5qZWN0KCduZ3J4LWZvcm1zL25ldmVyJykgbmF2aWdhdG9yOiBOYXZpZ2F0b3IgfCBudWxsID0gbnVsbCxcbiAgKSB7XG4gICAgdGhpcy5pc0NvbXBvc2l0aW9uU3VwcG9ydGVkID0gaXNQbGF0Zm9ybUJyb3dzZXIodGhpcy5wbGF0Zm9ybUlkIHx8ICcnKSAmJiAhaXNBbmRyb2lkKG5hdmlnYXRvciB8fCB3aW5kb3cubmF2aWdhdG9yKTtcbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICBjb25zdCBuYXRpdmVJZCA9IHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmlkO1xuICAgIGNvbnN0IHNob3VsZFNldE5hdGl2ZUlkID0gdGhpcy5zdGF0ZS5pZCAhPT0gbmF0aXZlSWQgJiYgIW5hdGl2ZUlkO1xuICAgIGlmIChzaG91bGRTZXROYXRpdmVJZCkge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRQcm9wZXJ0eSh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ2lkJywgdGhpcy5zdGF0ZS5pZCk7XG4gICAgICB0aGlzLm5hdGl2ZUlkV2FzU2V0ID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICBzZXRWaWV3VmFsdWUodmFsdWU6IGFueSk6IHZvaWQge1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRWYWx1ZSA9IHZhbHVlID09IG51bGwgPyAnJyA6IHZhbHVlO1xuICAgIHRoaXMucmVuZGVyZXIuc2V0UHJvcGVydHkodGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsICd2YWx1ZScsIG5vcm1hbGl6ZWRWYWx1ZSk7XG4gIH1cblxuICBzZXRPbkNoYW5nZUNhbGxiYWNrKGZuOiAodmFsdWU6IGFueSkgPT4gdm9pZCk6IHZvaWQge1xuICAgIHRoaXMub25DaGFuZ2UgPSBmbjtcbiAgfVxuXG4gIHNldE9uVG91Y2hlZENhbGxiYWNrKGZuOiAoKSA9PiB2b2lkKTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmbjtcbiAgfVxuXG4gIHNldElzRGlzYWJsZWQoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQge1xuICAgIHRoaXMucmVuZGVyZXIuc2V0UHJvcGVydHkodGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsICdkaXNhYmxlZCcsIGlzRGlzYWJsZWQpO1xuICB9XG5cbiAgQEhvc3RMaXN0ZW5lcignaW5wdXQnLCBbJyRldmVudCddKVxuICBoYW5kbGVJbnB1dCh7IHRhcmdldCB9OiB7IHRhcmdldDogSFRNTElucHV0RWxlbWVudCB9KTogdm9pZCB7XG4gICAgaWYgKHRoaXMuaXNDb21wb3NpdGlvblN1cHBvcnRlZCAmJiB0aGlzLmlzQ29tcG9zaW5nKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5vbkNoYW5nZSh0YXJnZXQudmFsdWUpO1xuICB9XG5cbiAgQEhvc3RMaXN0ZW5lcignY29tcG9zaXRpb25zdGFydCcpXG4gIGNvbXBvc2l0aW9uU3RhcnQoKTogdm9pZCB7XG4gICAgdGhpcy5pc0NvbXBvc2luZyA9IHRydWU7XG4gIH1cblxuICBASG9zdExpc3RlbmVyKCdjb21wb3NpdGlvbmVuZCcsIFsnJGV2ZW50J10pXG4gIGNvbXBvc2l0aW9uRW5kKHsgdGFyZ2V0IH06IHsgdGFyZ2V0OiBIVE1MSW5wdXRFbGVtZW50IH0pOiB2b2lkIHtcbiAgICB0aGlzLmlzQ29tcG9zaW5nID0gZmFsc2U7XG4gICAgaWYgKHRoaXMuaXNDb21wb3NpdGlvblN1cHBvcnRlZCkge1xuICAgICAgdGhpcy5vbkNoYW5nZSh0YXJnZXQudmFsdWUpO1xuICAgIH1cbiAgfVxufVxuIl19