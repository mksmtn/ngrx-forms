import { DOCUMENT } from "@angular/common";
import { Directive, EventEmitter, Inject, Optional, Output, Self, } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { NGRX_FORM_VIEW_ADAPTER, } from "../view-adapter/view-adapter";
import { NgrxFormControlDirective } from "./directive";
import * as i0 from "@angular/core";
export class NgrxLocalFormControlDirective extends NgrxFormControlDirective {
    ngrxFormsAction = new EventEmitter();
    constructor(el, dom, viewAdapters, valueAccessors) {
        super(el, dom, null, viewAdapters, valueAccessors);
    }
    dispatchAction(action) {
        this.ngrxFormsAction.emit(action);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxLocalFormControlDirective, deps: [{ token: i0.ElementRef }, { token: DOCUMENT, optional: true }, { token: NGRX_FORM_VIEW_ADAPTER, optional: true, self: true }, { token: NG_VALUE_ACCESSOR, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxLocalFormControlDirective, selector: "[ngrxFormControlState][ngrxFormsAction]", outputs: { ngrxFormsAction: "ngrxFormsAction" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxLocalFormControlDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: "[ngrxFormControlState][ngrxFormsAction]",
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: undefined, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [NGRX_FORM_VIEW_ADAPTER]
                }] }, { type: undefined, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [NG_VALUE_ACCESSOR]
                }] }], propDecorators: { ngrxFormsAction: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYWwtc3RhdGUtZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2NvbnRyb2wvbG9jYWwtc3RhdGUtZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMzQyxPQUFPLEVBQ0wsU0FBUyxFQUVULFlBQVksRUFDWixNQUFNLEVBQ04sUUFBUSxFQUNSLE1BQU0sRUFDTixJQUFJLEdBQ0wsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUF3QixpQkFBaUIsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBR3pFLE9BQU8sRUFFTCxzQkFBc0IsR0FDdkIsTUFBTSw4QkFBOEIsQ0FBQztBQUN0QyxPQUFPLEVBQVksd0JBQXdCLEVBQUUsTUFBTSxhQUFhLENBQUM7O0FBT2pFLE1BQU0sT0FBTyw2QkFHWCxTQUFRLHdCQUFpRDtJQUMvQyxlQUFlLEdBQUcsSUFBSSxZQUFZLEVBQXVCLENBQUM7SUFFcEUsWUFDRSxFQUFjLEVBQ2dCLEdBQW9CLEVBSWxELFlBQStCLEVBSS9CLGNBQXNDO1FBRXRDLEtBQUssQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsY0FBYyxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVTLGNBQWMsQ0FBQyxNQUEyQjtRQUNsRCxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNwQyxDQUFDO3VHQXZCVSw2QkFBNkIsNENBUWxCLFFBQVEsNkJBR3BCLHNCQUFzQix5Q0FJdEIsaUJBQWlCOzJGQWZoQiw2QkFBNkI7OzJGQUE3Qiw2QkFBNkI7a0JBSnpDLFNBQVM7bUJBQUM7b0JBQ1QsOENBQThDO29CQUM5QyxRQUFRLEVBQUUseUNBQXlDO2lCQUNwRDs7MEJBU0ksUUFBUTs7MEJBQUksTUFBTTsyQkFBQyxRQUFROzswQkFDM0IsSUFBSTs7MEJBQ0osUUFBUTs7MEJBQ1IsTUFBTTsyQkFBQyxzQkFBc0I7OzBCQUU3QixJQUFJOzswQkFDSixRQUFROzswQkFDUixNQUFNOzJCQUFDLGlCQUFpQjt5Q0FYakIsZUFBZTtzQkFBeEIsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0IHtcbiAgRGlyZWN0aXZlLFxuICBFbGVtZW50UmVmLFxuICBFdmVudEVtaXR0ZXIsXG4gIEluamVjdCxcbiAgT3B0aW9uYWwsXG4gIE91dHB1dCxcbiAgU2VsZixcbn0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOR19WQUxVRV9BQ0NFU1NPUiB9IGZyb20gXCJAYW5ndWxhci9mb3Jtc1wiO1xuXG5pbXBvcnQgeyBBY3Rpb25zIH0gZnJvbSBcIi4uL2FjdGlvbnNcIjtcbmltcG9ydCB7XG4gIEZvcm1WaWV3QWRhcHRlcixcbiAgTkdSWF9GT1JNX1ZJRVdfQURBUFRFUixcbn0gZnJvbSBcIi4uL3ZpZXctYWRhcHRlci92aWV3LWFkYXB0ZXJcIjtcbmltcG9ydCB7IERvY3VtZW50LCBOZ3J4Rm9ybUNvbnRyb2xEaXJlY3RpdmUgfSBmcm9tIFwiLi9kaXJlY3RpdmVcIjtcbmltcG9ydCB7IEFjdGlvblR5cGUgfSBmcm9tIFwiQG5ncngvc3RvcmVcIjtcblxuQERpcmVjdGl2ZSh7XG4gIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpkaXJlY3RpdmUtc2VsZWN0b3JcbiAgc2VsZWN0b3I6IFwiW25ncnhGb3JtQ29udHJvbFN0YXRlXVtuZ3J4Rm9ybXNBY3Rpb25dXCIsXG59KVxuZXhwb3J0IGNsYXNzIE5ncnhMb2NhbEZvcm1Db250cm9sRGlyZWN0aXZlPFxuICBUU3RhdGVWYWx1ZSxcbiAgVFZpZXdWYWx1ZSA9IFRTdGF0ZVZhbHVlXG4+IGV4dGVuZHMgTmdyeEZvcm1Db250cm9sRGlyZWN0aXZlPFRTdGF0ZVZhbHVlLCBUVmlld1ZhbHVlPiB7XG4gIEBPdXRwdXQoKSBuZ3J4Rm9ybXNBY3Rpb24gPSBuZXcgRXZlbnRFbWl0dGVyPEFjdGlvblR5cGU8QWN0aW9ucz4+KCk7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgZWw6IEVsZW1lbnRSZWYsXG4gICAgQE9wdGlvbmFsKCkgQEluamVjdChET0NVTUVOVCkgZG9tOiBEb2N1bWVudCB8IG51bGwsXG4gICAgQFNlbGYoKVxuICAgIEBPcHRpb25hbCgpXG4gICAgQEluamVjdChOR1JYX0ZPUk1fVklFV19BREFQVEVSKVxuICAgIHZpZXdBZGFwdGVyczogRm9ybVZpZXdBZGFwdGVyW10sXG4gICAgQFNlbGYoKVxuICAgIEBPcHRpb25hbCgpXG4gICAgQEluamVjdChOR19WQUxVRV9BQ0NFU1NPUilcbiAgICB2YWx1ZUFjY2Vzc29yczogQ29udHJvbFZhbHVlQWNjZXNzb3JbXVxuICApIHtcbiAgICBzdXBlcihlbCwgZG9tLCBudWxsLCB2aWV3QWRhcHRlcnMsIHZhbHVlQWNjZXNzb3JzKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBkaXNwYXRjaEFjdGlvbihhY3Rpb246IEFjdGlvblR5cGU8QWN0aW9ucz4pIHtcbiAgICB0aGlzLm5ncnhGb3Jtc0FjdGlvbi5lbWl0KGFjdGlvbik7XG4gIH1cbn1cbiJdfQ==