import { DOCUMENT } from "@angular/common";
import { Directive, HostBinding, HostListener, Inject, Input, Optional, Self, } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { ActionsSubject } from "@ngrx/store";
import { focusAction, markAsDirtyAction, markAsTouchedAction, setValueAction, unfocusAction, } from "../actions";
import { selectViewAdapter } from "../view-adapter/util";
import { NGRX_FORM_VIEW_ADAPTER, } from "../view-adapter/view-adapter";
import { NgrxValueConverters } from "./value-converter";
import * as i0 from "@angular/core";
import * as i1 from "@ngrx/store";
export var NGRX_UPDATE_ON_TYPE;
(function (NGRX_UPDATE_ON_TYPE) {
    NGRX_UPDATE_ON_TYPE["CHANGE"] = "change";
    NGRX_UPDATE_ON_TYPE["BLUR"] = "blur";
    NGRX_UPDATE_ON_TYPE["NEVER"] = "never";
})(NGRX_UPDATE_ON_TYPE || (NGRX_UPDATE_ON_TYPE = {}));
class ControlValueAccessorAdapter {
    valueAccessor;
    constructor(valueAccessor) {
        this.valueAccessor = valueAccessor;
    }
    setViewValue(value) {
        this.valueAccessor.writeValue(value);
    }
    setOnChangeCallback(fn) {
        this.valueAccessor.registerOnChange(fn);
    }
    setOnTouchedCallback(fn) {
        this.valueAccessor.registerOnTouched(fn);
    }
    setIsDisabled(isDisabled) {
        if (this.valueAccessor.setDisabledState) {
            this.valueAccessor.setDisabledState(isDisabled);
        }
    }
}
export class NgrxFormControlDirective {
    el;
    dom;
    actionsSubject;
    isInitialized = false;
    focusTrackingIsEnabled = false;
    set ngrxFormControlState(newState) {
        if (!newState) {
            throw new Error("The control state must not be undefined!");
        }
        const oldState = this.state;
        this.state = newState;
        if (this.isInitialized) {
            this.updateViewIfControlIdChanged(newState, oldState);
            this.updateViewIfValueChanged(newState, oldState);
            this.updateViewIfIsDisabledChanged(newState, oldState);
            this.updateViewIfIsFocusedChanged(newState, oldState);
        }
    }
    ngrxUpdateOn = NGRX_UPDATE_ON_TYPE.CHANGE;
    set ngrxEnableFocusTracking(value) {
        if (value && !this.dom) {
            throw new Error("focus tracking is only supported on the browser platform");
        }
        this.focusTrackingIsEnabled = value;
    }
    ngrxValueConverter = NgrxValueConverters.default();
    // TODO: move this into a separate directive
    // automatically apply the attribute that's used by the CDK to set initial focus
    get focusRegionStartAttr() {
        return this.state && this.state.isFocused ? "" : null;
    }
    state;
    viewAdapter;
    // we have to store the latest known state value since most input elements don't play nicely with
    // setting the same value again (e.g. input elements move the cursor to the end of the input when
    // a new value is set which means whenever the user types something the cursor is forced to the
    // end of the input) which would for example happen every time a new value is pushed to the state
    // since when the action to update the state is dispatched a new state will be received inside
    // the directive, which in turn would trigger a view update; to prevent this behavior we compare
    // the latest known state value with the value to be set and filter out those values that are equal
    // to the latest known value
    viewValue;
    stateValue;
    constructor(el, 
    // for the dom parameter the `null` type must be last to ensure that in the compiled output
    // there is no reference to the Document type to support non-browser platforms
    dom, actionsSubject, viewAdapters, valueAccessors) {
        this.el = el;
        this.dom = dom;
        this.actionsSubject = actionsSubject;
        viewAdapters = viewAdapters || [];
        valueAccessors = valueAccessors || [];
        if (valueAccessors.length > 1) {
            throw new Error("More than one custom control value accessor matches!");
        }
        this.viewAdapter =
            valueAccessors.length > 0
                ? new ControlValueAccessorAdapter(valueAccessors[0])
                : selectViewAdapter(viewAdapters);
    }
    updateViewIfControlIdChanged(newState, oldState) {
        if (oldState && newState.id === oldState.id) {
            return;
        }
        this.stateValue = newState.value;
        this.viewValue = this.ngrxValueConverter.convertStateToViewValue(this.stateValue);
        this.viewAdapter.setViewValue(this.viewValue);
        if (this.viewAdapter.setIsDisabled) {
            this.viewAdapter.setIsDisabled(newState.isDisabled);
        }
    }
    updateViewIfValueChanged(newState, _) {
        if (newState.value === this.stateValue) {
            return;
        }
        this.stateValue = newState.value;
        this.viewValue = this.ngrxValueConverter.convertStateToViewValue(newState.value);
        this.viewAdapter.setViewValue(this.viewValue);
    }
    updateViewIfIsDisabledChanged(newState, oldState) {
        if (!this.viewAdapter.setIsDisabled) {
            return;
        }
        if (oldState && newState.isDisabled === oldState.isDisabled) {
            return;
        }
        this.viewAdapter.setIsDisabled(newState.isDisabled);
    }
    updateViewIfIsFocusedChanged(newState, oldState) {
        if (!this.focusTrackingIsEnabled) {
            return;
        }
        if (oldState && newState.isFocused === oldState.isFocused) {
            return;
        }
        if (newState.isFocused) {
            this.el.nativeElement.focus();
        }
        else {
            this.el.nativeElement.blur();
        }
    }
    dispatchAction(action) {
        if (this.actionsSubject !== null) {
            this.actionsSubject.next(action);
        }
        else {
            throw new Error("ActionsSubject must be present in order to dispatch actions!");
        }
    }
    ngOnInit() {
        if (!this.state) {
            throw new Error("The form state must not be undefined!");
        }
        this.isInitialized = true;
        this.updateViewIfControlIdChanged(this.state, undefined);
        this.updateViewIfValueChanged(this.state, undefined);
        this.updateViewIfIsDisabledChanged(this.state, undefined);
        this.updateViewIfIsFocusedChanged(this.state, undefined);
        const dispatchMarkAsDirtyAction = () => {
            if (this.state.isPristine) {
                this.dispatchAction(markAsDirtyAction({ controlId: this.state.id }));
            }
        };
        const dispatchSetValueAction = () => {
            this.stateValue = this.ngrxValueConverter.convertViewToStateValue(this.viewValue);
            if (this.stateValue !== this.state.value) {
                this.dispatchAction(setValueAction({ controlId: this.state.id, value: this.stateValue }));
                dispatchMarkAsDirtyAction();
            }
        };
        this.viewAdapter.setOnChangeCallback((viewValue) => {
            this.viewValue = viewValue;
            if (this.ngrxUpdateOn === NGRX_UPDATE_ON_TYPE.CHANGE) {
                dispatchSetValueAction();
            }
        });
        this.viewAdapter.setOnTouchedCallback(() => {
            if (!this.state.isTouched &&
                this.ngrxUpdateOn !== NGRX_UPDATE_ON_TYPE.NEVER) {
                this.dispatchAction(markAsTouchedAction({ controlId: this.state.id }));
            }
            if (this.ngrxUpdateOn === NGRX_UPDATE_ON_TYPE.BLUR) {
                dispatchSetValueAction();
            }
        });
    }
    ngAfterViewInit() {
        // we need to update the view again after it was initialized since some
        // controls depend on child elements for setting the value (e.g. selects)
        this.viewAdapter.setViewValue(this.viewValue);
        if (this.viewAdapter.setIsDisabled) {
            this.viewAdapter.setIsDisabled(this.state.isDisabled);
        }
    }
    onFocusChange() {
        if (!this.focusTrackingIsEnabled) {
            return;
        }
        const isControlFocused = this.el.nativeElement === this.dom.activeElement;
        if (isControlFocused !== this.state.isFocused) {
            this.dispatchAction(isControlFocused
                ? focusAction({ controlId: this.state.id })
                : unfocusAction({ controlId: this.state.id }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormControlDirective, deps: [{ token: i0.ElementRef }, { token: DOCUMENT, optional: true }, { token: ActionsSubject, optional: true }, { token: NGRX_FORM_VIEW_ADAPTER, optional: true, self: true }, { token: NG_VALUE_ACCESSOR, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxFormControlDirective, selector: ":not([ngrxFormsAction])[ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState", ngrxUpdateOn: "ngrxUpdateOn", ngrxEnableFocusTracking: "ngrxEnableFocusTracking", ngrxValueConverter: "ngrxValueConverter" }, host: { listeners: { "focusin": "onFocusChange()", "focusout": "onFocusChange()" }, properties: { "attr.cdk-focus-region-start": "this.focusRegionStartAttr" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxFormControlDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: ":not([ngrxFormsAction])[ngrxFormControlState]",
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.ActionsSubject, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [ActionsSubject]
                }] }, { type: undefined, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [NGRX_FORM_VIEW_ADAPTER]
                }] }, { type: undefined, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }, {
                    type: Inject,
                    args: [NG_VALUE_ACCESSOR]
                }] }], propDecorators: { ngrxFormControlState: [{
                type: Input
            }], ngrxUpdateOn: [{
                type: Input
            }], ngrxEnableFocusTracking: [{
                type: Input
            }], ngrxValueConverter: [{
                type: Input
            }], focusRegionStartAttr: [{
                type: HostBinding,
                args: ["attr.cdk-focus-region-start"]
            }], onFocusChange: [{
                type: HostListener,
                args: ["focusin"]
            }, {
                type: HostListener,
                args: ["focusout"]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2NvbnRyb2wvZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMzQyxPQUFPLEVBRUwsU0FBUyxFQUVULFdBQVcsRUFDWCxZQUFZLEVBQ1osTUFBTSxFQUNOLEtBQUssRUFFTCxRQUFRLEVBQ1IsSUFBSSxHQUNMLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBd0IsaUJBQWlCLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUN6RSxPQUFPLEVBQUUsY0FBYyxFQUFjLE1BQU0sYUFBYSxDQUFDO0FBRXpELE9BQU8sRUFFTCxXQUFXLEVBQ1gsaUJBQWlCLEVBQ2pCLG1CQUFtQixFQUNuQixjQUFjLEVBQ2QsYUFBYSxHQUNkLE1BQU0sWUFBWSxDQUFDO0FBRXBCLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQ3pELE9BQU8sRUFFTCxzQkFBc0IsR0FDdkIsTUFBTSw4QkFBOEIsQ0FBQztBQUN0QyxPQUFPLEVBQXNCLG1CQUFtQixFQUFFLE1BQU0sbUJBQW1CLENBQUM7OztBQU01RSxNQUFNLENBQU4sSUFBWSxtQkFJWDtBQUpELFdBQVksbUJBQW1CO0lBQzdCLHdDQUFpQixDQUFBO0lBQ2pCLG9DQUFhLENBQUE7SUFDYixzQ0FBZSxDQUFBO0FBQ2pCLENBQUMsRUFKVyxtQkFBbUIsS0FBbkIsbUJBQW1CLFFBSTlCO0FBRUQsTUFBTSwyQkFBMkI7SUFDWDtJQUFwQixZQUFvQixhQUFtQztRQUFuQyxrQkFBYSxHQUFiLGFBQWEsQ0FBc0I7SUFBRyxDQUFDO0lBRTNELFlBQVksQ0FBQyxLQUFVO1FBQ3JCLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxFQUF3QjtRQUMxQyxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvQkFBb0IsQ0FBQyxFQUFjO1FBQ2pDLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVELGFBQWEsQ0FBQyxVQUFtQjtRQUMvQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2xELENBQUM7SUFDSCxDQUFDO0NBQ0Y7QUFTRCxNQUFNLE9BQU8sd0JBQXdCO0lBNER6QjtJQUc4QjtJQUc5QjtJQS9ERixhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQ3RCLHNCQUFzQixHQUFHLEtBQUssQ0FBQztJQUV2QyxJQUFhLG9CQUFvQixDQUMvQixRQUFpRTtRQUVqRSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDZCxNQUFNLElBQUksS0FBSyxDQUFDLDBDQUEwQyxDQUFDLENBQUM7UUFDOUQsQ0FBQztRQUVELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDNUIsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUM7UUFFdEIsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLDRCQUE0QixDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUMsd0JBQXdCLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ2xELElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDdkQsSUFBSSxDQUFDLDRCQUE0QixDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUN4RCxDQUFDO0lBQ0gsQ0FBQztJQUVRLFlBQVksR0FBd0IsbUJBQW1CLENBQUMsTUFBTSxDQUFDO0lBQ3hFLElBQWEsdUJBQXVCLENBQUMsS0FBYztRQUNqRCxJQUFJLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUN2QixNQUFNLElBQUksS0FBSyxDQUNiLDBEQUEwRCxDQUMzRCxDQUFDO1FBQ0osQ0FBQztRQUVELElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUVRLGtCQUFrQixHQUN6QixtQkFBbUIsQ0FBQyxPQUFPLEVBQU8sQ0FBQztJQUVyQyw0Q0FBNEM7SUFDNUMsZ0ZBQWdGO0lBQ2hGLElBQWdELG9CQUFvQjtRQUNsRSxPQUFPLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ3hELENBQUM7SUFFRCxLQUFLLENBQTBEO0lBRXZELFdBQVcsQ0FBa0I7SUFFckMsaUdBQWlHO0lBQ2pHLGlHQUFpRztJQUNqRywrRkFBK0Y7SUFDL0YsaUdBQWlHO0lBQ2pHLDhGQUE4RjtJQUM5RixnR0FBZ0c7SUFDaEcsbUdBQW1HO0lBQ25HLDRCQUE0QjtJQUNwQixTQUFTLENBQWE7SUFDdEIsVUFBVSxDQUFjO0lBRWhDLFlBQ1UsRUFBYztJQUN0QiwyRkFBMkY7SUFDM0YsOEVBQThFO0lBQ3hDLEdBQW9CLEVBR2xELGNBQXFDLEVBSTdDLFlBQStCLEVBSS9CLGNBQXNDO1FBZDlCLE9BQUUsR0FBRixFQUFFLENBQVk7UUFHZ0IsUUFBRyxHQUFILEdBQUcsQ0FBaUI7UUFHbEQsbUJBQWMsR0FBZCxjQUFjLENBQXVCO1FBVTdDLFlBQVksR0FBRyxZQUFZLElBQUksRUFBRSxDQUFDO1FBQ2xDLGNBQWMsR0FBRyxjQUFjLElBQUksRUFBRSxDQUFDO1FBRXRDLElBQUksY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUM5QixNQUFNLElBQUksS0FBSyxDQUFDLHNEQUFzRCxDQUFDLENBQUM7UUFDMUUsQ0FBQztRQUVELElBQUksQ0FBQyxXQUFXO1lBQ2QsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDO2dCQUN2QixDQUFDLENBQUMsSUFBSSwyQkFBMkIsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BELENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsNEJBQTRCLENBQzFCLFFBQWlFLEVBQ2pFLFFBRWE7UUFFYixJQUFJLFFBQVEsSUFBSSxRQUFRLENBQUMsRUFBRSxLQUFLLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUM1QyxPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztRQUNqQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBdUIsQ0FDOUQsSUFBSSxDQUFDLFVBQVUsQ0FDaEIsQ0FBQztRQUNGLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5QyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDbkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3RELENBQUM7SUFDSCxDQUFDO0lBRUQsd0JBQXdCLENBQ3RCLFFBQWlFLEVBQ2pFLENBQXNFO1FBRXRFLElBQUksUUFBUSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDdkMsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7UUFDakMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsdUJBQXVCLENBQzlELFFBQVEsQ0FBQyxLQUFLLENBQ2YsQ0FBQztRQUNGLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsNkJBQTZCLENBQzNCLFFBQWlFLEVBQ2pFLFFBRWE7UUFFYixJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNwQyxPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksUUFBUSxJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQzVELE9BQU87UUFDVCxDQUFDO1FBRUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFFRCw0QkFBNEIsQ0FDMUIsUUFBaUUsRUFDakUsUUFFYTtRQUViLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNqQyxPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksUUFBUSxJQUFJLFFBQVEsQ0FBQyxTQUFTLEtBQUssUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQzFELE9BQU87UUFDVCxDQUFDO1FBRUQsSUFBSSxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDaEMsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUMvQixDQUFDO0lBQ0gsQ0FBQztJQUVTLGNBQWMsQ0FBQyxNQUEyQjtRQUNsRCxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssSUFBSSxFQUFFLENBQUM7WUFDakMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDbkMsQ0FBQzthQUFNLENBQUM7WUFDTixNQUFNLElBQUksS0FBSyxDQUNiLDhEQUE4RCxDQUMvRCxDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFRCxRQUFRO1FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNoQixNQUFNLElBQUksS0FBSyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7UUFDM0QsQ0FBQztRQUVELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBRTFCLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3pELElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRXpELE1BQU0seUJBQXlCLEdBQUcsR0FBRyxFQUFFO1lBQ3JDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUN2RSxDQUFDO1FBQ0gsQ0FBQyxDQUFDO1FBRUYsTUFBTSxzQkFBc0IsR0FBRyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsdUJBQXVCLENBQy9ELElBQUksQ0FBQyxTQUFTLENBQ2YsQ0FBQztZQUNGLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUN6QyxJQUFJLENBQUMsY0FBYyxDQUNqQixjQUFjLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUNyRSxDQUFDO2dCQUVGLHlCQUF5QixFQUFFLENBQUM7WUFDOUIsQ0FBQztRQUNILENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxTQUFxQixFQUFFLEVBQUU7WUFDN0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7WUFFM0IsSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNyRCxzQkFBc0IsRUFBRSxDQUFDO1lBQzNCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsR0FBRyxFQUFFO1lBQ3pDLElBQ0UsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVM7Z0JBQ3JCLElBQUksQ0FBQyxZQUFZLEtBQUssbUJBQW1CLENBQUMsS0FBSyxFQUMvQyxDQUFDO2dCQUNELElBQUksQ0FBQyxjQUFjLENBQUMsbUJBQW1CLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDekUsQ0FBQztZQUVELElBQUksSUFBSSxDQUFDLFlBQVksS0FBSyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDbkQsc0JBQXNCLEVBQUUsQ0FBQztZQUMzQixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsZUFBZTtRQUNiLHVFQUF1RTtRQUN2RSx5RUFBeUU7UUFDekUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuQyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3hELENBQUM7SUFDSCxDQUFDO0lBSUQsYUFBYTtRQUNYLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNqQyxPQUFPO1FBQ1QsQ0FBQztRQUVELE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLEtBQUssSUFBSSxDQUFDLEdBQUksQ0FBQyxhQUFhLENBQUM7UUFDM0UsSUFBSSxnQkFBZ0IsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQzlDLElBQUksQ0FBQyxjQUFjLENBQ2pCLGdCQUFnQjtnQkFDZCxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQzNDLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUNoRCxDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7dUdBelBVLHdCQUF3Qiw0Q0ErRGIsUUFBUSw2QkFFcEIsY0FBYyw2QkFJZCxzQkFBc0IseUNBSXRCLGlCQUFpQjsyRkF6RWhCLHdCQUF3Qjs7MkZBQXhCLHdCQUF3QjtrQkFKcEMsU0FBUzttQkFBQztvQkFDVCw4Q0FBOEM7b0JBQzlDLFFBQVEsRUFBRSwrQ0FBK0M7aUJBQzFEOzswQkFnRUksUUFBUTs7MEJBQUksTUFBTTsyQkFBQyxRQUFROzswQkFDM0IsUUFBUTs7MEJBQ1IsTUFBTTsyQkFBQyxjQUFjOzswQkFFckIsSUFBSTs7MEJBQ0osUUFBUTs7MEJBQ1IsTUFBTTsyQkFBQyxzQkFBc0I7OzBCQUU3QixJQUFJOzswQkFDSixRQUFROzswQkFDUixNQUFNOzJCQUFDLGlCQUFpQjt5Q0FuRWQsb0JBQW9CO3NCQUFoQyxLQUFLO2dCQWtCRyxZQUFZO3NCQUFwQixLQUFLO2dCQUNPLHVCQUF1QjtzQkFBbkMsS0FBSztnQkFVRyxrQkFBa0I7c0JBQTFCLEtBQUs7Z0JBSzBDLG9CQUFvQjtzQkFBbkUsV0FBVzt1QkFBQyw2QkFBNkI7Z0JBb00xQyxhQUFhO3NCQUZaLFlBQVk7dUJBQUMsU0FBUzs7c0JBQ3RCLFlBQVk7dUJBQUMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgRGlyZWN0aXZlLFxuICBFbGVtZW50UmVmLFxuICBIb3N0QmluZGluZyxcbiAgSG9zdExpc3RlbmVyLFxuICBJbmplY3QsXG4gIElucHV0LFxuICBPbkluaXQsXG4gIE9wdGlvbmFsLFxuICBTZWxmLFxufSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5HX1ZBTFVFX0FDQ0VTU09SIH0gZnJvbSBcIkBhbmd1bGFyL2Zvcm1zXCI7XG5pbXBvcnQgeyBBY3Rpb25zU3ViamVjdCwgQWN0aW9uVHlwZSB9IGZyb20gXCJAbmdyeC9zdG9yZVwiO1xuXG5pbXBvcnQge1xuICBBY3Rpb25zLFxuICBmb2N1c0FjdGlvbixcbiAgbWFya0FzRGlydHlBY3Rpb24sXG4gIG1hcmtBc1RvdWNoZWRBY3Rpb24sXG4gIHNldFZhbHVlQWN0aW9uLFxuICB1bmZvY3VzQWN0aW9uLFxufSBmcm9tIFwiLi4vYWN0aW9uc1wiO1xuaW1wb3J0IHsgRm9ybUNvbnRyb2xTdGF0ZSwgRm9ybUNvbnRyb2xWYWx1ZVR5cGVzIH0gZnJvbSBcIi4uL3N0YXRlXCI7XG5pbXBvcnQgeyBzZWxlY3RWaWV3QWRhcHRlciB9IGZyb20gXCIuLi92aWV3LWFkYXB0ZXIvdXRpbFwiO1xuaW1wb3J0IHtcbiAgRm9ybVZpZXdBZGFwdGVyLFxuICBOR1JYX0ZPUk1fVklFV19BREFQVEVSLFxufSBmcm9tIFwiLi4vdmlldy1hZGFwdGVyL3ZpZXctYWRhcHRlclwiO1xuaW1wb3J0IHsgTmdyeFZhbHVlQ29udmVydGVyLCBOZ3J4VmFsdWVDb252ZXJ0ZXJzIH0gZnJvbSBcIi4vdmFsdWUtY29udmVydGVyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRG9jdW1lbnQge1xuICBhY3RpdmVFbGVtZW50OiBhbnk7XG59XG5cbmV4cG9ydCBlbnVtIE5HUlhfVVBEQVRFX09OX1RZUEUge1xuICBDSEFOR0UgPSBcImNoYW5nZVwiLFxuICBCTFVSID0gXCJibHVyXCIsXG4gIE5FVkVSID0gXCJuZXZlclwiLFxufVxuXG5jbGFzcyBDb250cm9sVmFsdWVBY2Nlc3NvckFkYXB0ZXIgaW1wbGVtZW50cyBGb3JtVmlld0FkYXB0ZXIge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHZhbHVlQWNjZXNzb3I6IENvbnRyb2xWYWx1ZUFjY2Vzc29yKSB7fVxuXG4gIHNldFZpZXdWYWx1ZSh2YWx1ZTogYW55KTogdm9pZCB7XG4gICAgdGhpcy52YWx1ZUFjY2Vzc29yLndyaXRlVmFsdWUodmFsdWUpO1xuICB9XG5cbiAgc2V0T25DaGFuZ2VDYWxsYmFjayhmbjogKHZhbHVlOiBhbnkpID0+IHZvaWQpOiB2b2lkIHtcbiAgICB0aGlzLnZhbHVlQWNjZXNzb3IucmVnaXN0ZXJPbkNoYW5nZShmbik7XG4gIH1cbiAgc2V0T25Ub3VjaGVkQ2FsbGJhY2soZm46ICgpID0+IHZvaWQpOiB2b2lkIHtcbiAgICB0aGlzLnZhbHVlQWNjZXNzb3IucmVnaXN0ZXJPblRvdWNoZWQoZm4pO1xuICB9XG5cbiAgc2V0SXNEaXNhYmxlZChpc0Rpc2FibGVkOiBib29sZWFuKSB7XG4gICAgaWYgKHRoaXMudmFsdWVBY2Nlc3Nvci5zZXREaXNhYmxlZFN0YXRlKSB7XG4gICAgICB0aGlzLnZhbHVlQWNjZXNzb3Iuc2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IHR5cGUgTmdyeEZvcm1Db250cm9sVmFsdWVUeXBlPFRTdGF0ZVZhbHVlPiA9XG4gIFRTdGF0ZVZhbHVlIGV4dGVuZHMgRm9ybUNvbnRyb2xWYWx1ZVR5cGVzID8gVFN0YXRlVmFsdWUgOiBuZXZlcjtcblxuQERpcmVjdGl2ZSh7XG4gIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpkaXJlY3RpdmUtc2VsZWN0b3JcbiAgc2VsZWN0b3I6IFwiOm5vdChbbmdyeEZvcm1zQWN0aW9uXSlbbmdyeEZvcm1Db250cm9sU3RhdGVdXCIsXG59KVxuZXhwb3J0IGNsYXNzIE5ncnhGb3JtQ29udHJvbERpcmVjdGl2ZTxUU3RhdGVWYWx1ZSwgVFZpZXdWYWx1ZSA9IFRTdGF0ZVZhbHVlPlxuICBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uSW5pdFxue1xuICBwcml2YXRlIGlzSW5pdGlhbGl6ZWQgPSBmYWxzZTtcbiAgcHJpdmF0ZSBmb2N1c1RyYWNraW5nSXNFbmFibGVkID0gZmFsc2U7XG5cbiAgQElucHV0KCkgc2V0IG5ncnhGb3JtQ29udHJvbFN0YXRlKFxuICAgIG5ld1N0YXRlOiBGb3JtQ29udHJvbFN0YXRlPE5ncnhGb3JtQ29udHJvbFZhbHVlVHlwZTxUU3RhdGVWYWx1ZT4+XG4gICkge1xuICAgIGlmICghbmV3U3RhdGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoZSBjb250cm9sIHN0YXRlIG11c3Qgbm90IGJlIHVuZGVmaW5lZCFcIik7XG4gICAgfVxuXG4gICAgY29uc3Qgb2xkU3RhdGUgPSB0aGlzLnN0YXRlO1xuICAgIHRoaXMuc3RhdGUgPSBuZXdTdGF0ZTtcblxuICAgIGlmICh0aGlzLmlzSW5pdGlhbGl6ZWQpIHtcbiAgICAgIHRoaXMudXBkYXRlVmlld0lmQ29udHJvbElkQ2hhbmdlZChuZXdTdGF0ZSwgb2xkU3RhdGUpO1xuICAgICAgdGhpcy51cGRhdGVWaWV3SWZWYWx1ZUNoYW5nZWQobmV3U3RhdGUsIG9sZFN0YXRlKTtcbiAgICAgIHRoaXMudXBkYXRlVmlld0lmSXNEaXNhYmxlZENoYW5nZWQobmV3U3RhdGUsIG9sZFN0YXRlKTtcbiAgICAgIHRoaXMudXBkYXRlVmlld0lmSXNGb2N1c2VkQ2hhbmdlZChuZXdTdGF0ZSwgb2xkU3RhdGUpO1xuICAgIH1cbiAgfVxuXG4gIEBJbnB1dCgpIG5ncnhVcGRhdGVPbjogTkdSWF9VUERBVEVfT05fVFlQRSA9IE5HUlhfVVBEQVRFX09OX1RZUEUuQ0hBTkdFO1xuICBASW5wdXQoKSBzZXQgbmdyeEVuYWJsZUZvY3VzVHJhY2tpbmcodmFsdWU6IGJvb2xlYW4pIHtcbiAgICBpZiAodmFsdWUgJiYgIXRoaXMuZG9tKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIFwiZm9jdXMgdHJhY2tpbmcgaXMgb25seSBzdXBwb3J0ZWQgb24gdGhlIGJyb3dzZXIgcGxhdGZvcm1cIlxuICAgICAgKTtcbiAgICB9XG5cbiAgICB0aGlzLmZvY3VzVHJhY2tpbmdJc0VuYWJsZWQgPSB2YWx1ZTtcbiAgfVxuXG4gIEBJbnB1dCgpIG5ncnhWYWx1ZUNvbnZlcnRlcjogTmdyeFZhbHVlQ29udmVydGVyPFRWaWV3VmFsdWUsIFRTdGF0ZVZhbHVlPiA9XG4gICAgTmdyeFZhbHVlQ29udmVydGVycy5kZWZhdWx0PGFueT4oKTtcblxuICAvLyBUT0RPOiBtb3ZlIHRoaXMgaW50byBhIHNlcGFyYXRlIGRpcmVjdGl2ZVxuICAvLyBhdXRvbWF0aWNhbGx5IGFwcGx5IHRoZSBhdHRyaWJ1dGUgdGhhdCdzIHVzZWQgYnkgdGhlIENESyB0byBzZXQgaW5pdGlhbCBmb2N1c1xuICBASG9zdEJpbmRpbmcoXCJhdHRyLmNkay1mb2N1cy1yZWdpb24tc3RhcnRcIikgZ2V0IGZvY3VzUmVnaW9uU3RhcnRBdHRyKCkge1xuICAgIHJldHVybiB0aGlzLnN0YXRlICYmIHRoaXMuc3RhdGUuaXNGb2N1c2VkID8gXCJcIiA6IG51bGw7XG4gIH1cblxuICBzdGF0ZTogRm9ybUNvbnRyb2xTdGF0ZTxOZ3J4Rm9ybUNvbnRyb2xWYWx1ZVR5cGU8VFN0YXRlVmFsdWU+PjtcblxuICBwcml2YXRlIHZpZXdBZGFwdGVyOiBGb3JtVmlld0FkYXB0ZXI7XG5cbiAgLy8gd2UgaGF2ZSB0byBzdG9yZSB0aGUgbGF0ZXN0IGtub3duIHN0YXRlIHZhbHVlIHNpbmNlIG1vc3QgaW5wdXQgZWxlbWVudHMgZG9uJ3QgcGxheSBuaWNlbHkgd2l0aFxuICAvLyBzZXR0aW5nIHRoZSBzYW1lIHZhbHVlIGFnYWluIChlLmcuIGlucHV0IGVsZW1lbnRzIG1vdmUgdGhlIGN1cnNvciB0byB0aGUgZW5kIG9mIHRoZSBpbnB1dCB3aGVuXG4gIC8vIGEgbmV3IHZhbHVlIGlzIHNldCB3aGljaCBtZWFucyB3aGVuZXZlciB0aGUgdXNlciB0eXBlcyBzb21ldGhpbmcgdGhlIGN1cnNvciBpcyBmb3JjZWQgdG8gdGhlXG4gIC8vIGVuZCBvZiB0aGUgaW5wdXQpIHdoaWNoIHdvdWxkIGZvciBleGFtcGxlIGhhcHBlbiBldmVyeSB0aW1lIGEgbmV3IHZhbHVlIGlzIHB1c2hlZCB0byB0aGUgc3RhdGVcbiAgLy8gc2luY2Ugd2hlbiB0aGUgYWN0aW9uIHRvIHVwZGF0ZSB0aGUgc3RhdGUgaXMgZGlzcGF0Y2hlZCBhIG5ldyBzdGF0ZSB3aWxsIGJlIHJlY2VpdmVkIGluc2lkZVxuICAvLyB0aGUgZGlyZWN0aXZlLCB3aGljaCBpbiB0dXJuIHdvdWxkIHRyaWdnZXIgYSB2aWV3IHVwZGF0ZTsgdG8gcHJldmVudCB0aGlzIGJlaGF2aW9yIHdlIGNvbXBhcmVcbiAgLy8gdGhlIGxhdGVzdCBrbm93biBzdGF0ZSB2YWx1ZSB3aXRoIHRoZSB2YWx1ZSB0byBiZSBzZXQgYW5kIGZpbHRlciBvdXQgdGhvc2UgdmFsdWVzIHRoYXQgYXJlIGVxdWFsXG4gIC8vIHRvIHRoZSBsYXRlc3Qga25vd24gdmFsdWVcbiAgcHJpdmF0ZSB2aWV3VmFsdWU6IFRWaWV3VmFsdWU7XG4gIHByaXZhdGUgc3RhdGVWYWx1ZTogVFN0YXRlVmFsdWU7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBlbDogRWxlbWVudFJlZixcbiAgICAvLyBmb3IgdGhlIGRvbSBwYXJhbWV0ZXIgdGhlIGBudWxsYCB0eXBlIG11c3QgYmUgbGFzdCB0byBlbnN1cmUgdGhhdCBpbiB0aGUgY29tcGlsZWQgb3V0cHV0XG4gICAgLy8gdGhlcmUgaXMgbm8gcmVmZXJlbmNlIHRvIHRoZSBEb2N1bWVudCB0eXBlIHRvIHN1cHBvcnQgbm9uLWJyb3dzZXIgcGxhdGZvcm1zXG4gICAgQE9wdGlvbmFsKCkgQEluamVjdChET0NVTUVOVCkgcHJpdmF0ZSBkb206IERvY3VtZW50IHwgbnVsbCxcbiAgICBAT3B0aW9uYWwoKVxuICAgIEBJbmplY3QoQWN0aW9uc1N1YmplY3QpXG4gICAgcHJpdmF0ZSBhY3Rpb25zU3ViamVjdDogQWN0aW9uc1N1YmplY3QgfCBudWxsLFxuICAgIEBTZWxmKClcbiAgICBAT3B0aW9uYWwoKVxuICAgIEBJbmplY3QoTkdSWF9GT1JNX1ZJRVdfQURBUFRFUilcbiAgICB2aWV3QWRhcHRlcnM6IEZvcm1WaWV3QWRhcHRlcltdLFxuICAgIEBTZWxmKClcbiAgICBAT3B0aW9uYWwoKVxuICAgIEBJbmplY3QoTkdfVkFMVUVfQUNDRVNTT1IpXG4gICAgdmFsdWVBY2Nlc3NvcnM6IENvbnRyb2xWYWx1ZUFjY2Vzc29yW11cbiAgKSB7XG4gICAgdmlld0FkYXB0ZXJzID0gdmlld0FkYXB0ZXJzIHx8IFtdO1xuICAgIHZhbHVlQWNjZXNzb3JzID0gdmFsdWVBY2Nlc3NvcnMgfHwgW107XG5cbiAgICBpZiAodmFsdWVBY2Nlc3NvcnMubGVuZ3RoID4gMSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTW9yZSB0aGFuIG9uZSBjdXN0b20gY29udHJvbCB2YWx1ZSBhY2Nlc3NvciBtYXRjaGVzIVwiKTtcbiAgICB9XG5cbiAgICB0aGlzLnZpZXdBZGFwdGVyID1cbiAgICAgIHZhbHVlQWNjZXNzb3JzLmxlbmd0aCA+IDBcbiAgICAgICAgPyBuZXcgQ29udHJvbFZhbHVlQWNjZXNzb3JBZGFwdGVyKHZhbHVlQWNjZXNzb3JzWzBdKVxuICAgICAgICA6IHNlbGVjdFZpZXdBZGFwdGVyKHZpZXdBZGFwdGVycyk7XG4gIH1cblxuICB1cGRhdGVWaWV3SWZDb250cm9sSWRDaGFuZ2VkKFxuICAgIG5ld1N0YXRlOiBGb3JtQ29udHJvbFN0YXRlPE5ncnhGb3JtQ29udHJvbFZhbHVlVHlwZTxUU3RhdGVWYWx1ZT4+LFxuICAgIG9sZFN0YXRlOlxuICAgICAgfCBGb3JtQ29udHJvbFN0YXRlPE5ncnhGb3JtQ29udHJvbFZhbHVlVHlwZTxUU3RhdGVWYWx1ZT4+XG4gICAgICB8IHVuZGVmaW5lZFxuICApIHtcbiAgICBpZiAob2xkU3RhdGUgJiYgbmV3U3RhdGUuaWQgPT09IG9sZFN0YXRlLmlkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5zdGF0ZVZhbHVlID0gbmV3U3RhdGUudmFsdWU7XG4gICAgdGhpcy52aWV3VmFsdWUgPSB0aGlzLm5ncnhWYWx1ZUNvbnZlcnRlci5jb252ZXJ0U3RhdGVUb1ZpZXdWYWx1ZShcbiAgICAgIHRoaXMuc3RhdGVWYWx1ZVxuICAgICk7XG4gICAgdGhpcy52aWV3QWRhcHRlci5zZXRWaWV3VmFsdWUodGhpcy52aWV3VmFsdWUpO1xuICAgIGlmICh0aGlzLnZpZXdBZGFwdGVyLnNldElzRGlzYWJsZWQpIHtcbiAgICAgIHRoaXMudmlld0FkYXB0ZXIuc2V0SXNEaXNhYmxlZChuZXdTdGF0ZS5pc0Rpc2FibGVkKTtcbiAgICB9XG4gIH1cblxuICB1cGRhdGVWaWV3SWZWYWx1ZUNoYW5nZWQoXG4gICAgbmV3U3RhdGU6IEZvcm1Db250cm9sU3RhdGU8TmdyeEZvcm1Db250cm9sVmFsdWVUeXBlPFRTdGF0ZVZhbHVlPj4sXG4gICAgXzogRm9ybUNvbnRyb2xTdGF0ZTxOZ3J4Rm9ybUNvbnRyb2xWYWx1ZVR5cGU8VFN0YXRlVmFsdWU+PiB8IHVuZGVmaW5lZFxuICApIHtcbiAgICBpZiAobmV3U3RhdGUudmFsdWUgPT09IHRoaXMuc3RhdGVWYWx1ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMuc3RhdGVWYWx1ZSA9IG5ld1N0YXRlLnZhbHVlO1xuICAgIHRoaXMudmlld1ZhbHVlID0gdGhpcy5uZ3J4VmFsdWVDb252ZXJ0ZXIuY29udmVydFN0YXRlVG9WaWV3VmFsdWUoXG4gICAgICBuZXdTdGF0ZS52YWx1ZVxuICAgICk7XG4gICAgdGhpcy52aWV3QWRhcHRlci5zZXRWaWV3VmFsdWUodGhpcy52aWV3VmFsdWUpO1xuICB9XG5cbiAgdXBkYXRlVmlld0lmSXNEaXNhYmxlZENoYW5nZWQoXG4gICAgbmV3U3RhdGU6IEZvcm1Db250cm9sU3RhdGU8TmdyeEZvcm1Db250cm9sVmFsdWVUeXBlPFRTdGF0ZVZhbHVlPj4sXG4gICAgb2xkU3RhdGU6XG4gICAgICB8IEZvcm1Db250cm9sU3RhdGU8TmdyeEZvcm1Db250cm9sVmFsdWVUeXBlPFRTdGF0ZVZhbHVlPj5cbiAgICAgIHwgdW5kZWZpbmVkXG4gICkge1xuICAgIGlmICghdGhpcy52aWV3QWRhcHRlci5zZXRJc0Rpc2FibGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKG9sZFN0YXRlICYmIG5ld1N0YXRlLmlzRGlzYWJsZWQgPT09IG9sZFN0YXRlLmlzRGlzYWJsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLnZpZXdBZGFwdGVyLnNldElzRGlzYWJsZWQobmV3U3RhdGUuaXNEaXNhYmxlZCk7XG4gIH1cblxuICB1cGRhdGVWaWV3SWZJc0ZvY3VzZWRDaGFuZ2VkKFxuICAgIG5ld1N0YXRlOiBGb3JtQ29udHJvbFN0YXRlPE5ncnhGb3JtQ29udHJvbFZhbHVlVHlwZTxUU3RhdGVWYWx1ZT4+LFxuICAgIG9sZFN0YXRlOlxuICAgICAgfCBGb3JtQ29udHJvbFN0YXRlPE5ncnhGb3JtQ29udHJvbFZhbHVlVHlwZTxUU3RhdGVWYWx1ZT4+XG4gICAgICB8IHVuZGVmaW5lZFxuICApIHtcbiAgICBpZiAoIXRoaXMuZm9jdXNUcmFja2luZ0lzRW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChvbGRTdGF0ZSAmJiBuZXdTdGF0ZS5pc0ZvY3VzZWQgPT09IG9sZFN0YXRlLmlzRm9jdXNlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChuZXdTdGF0ZS5pc0ZvY3VzZWQpIHtcbiAgICAgIHRoaXMuZWwubmF0aXZlRWxlbWVudC5mb2N1cygpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQuYmx1cigpO1xuICAgIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBkaXNwYXRjaEFjdGlvbihhY3Rpb246IEFjdGlvblR5cGU8QWN0aW9ucz4pIHtcbiAgICBpZiAodGhpcy5hY3Rpb25zU3ViamVjdCAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5hY3Rpb25zU3ViamVjdC5uZXh0KGFjdGlvbik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgXCJBY3Rpb25zU3ViamVjdCBtdXN0IGJlIHByZXNlbnQgaW4gb3JkZXIgdG8gZGlzcGF0Y2ggYWN0aW9ucyFcIlxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICBpZiAoIXRoaXMuc3RhdGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoZSBmb3JtIHN0YXRlIG11c3Qgbm90IGJlIHVuZGVmaW5lZCFcIik7XG4gICAgfVxuXG4gICAgdGhpcy5pc0luaXRpYWxpemVkID0gdHJ1ZTtcblxuICAgIHRoaXMudXBkYXRlVmlld0lmQ29udHJvbElkQ2hhbmdlZCh0aGlzLnN0YXRlLCB1bmRlZmluZWQpO1xuICAgIHRoaXMudXBkYXRlVmlld0lmVmFsdWVDaGFuZ2VkKHRoaXMuc3RhdGUsIHVuZGVmaW5lZCk7XG4gICAgdGhpcy51cGRhdGVWaWV3SWZJc0Rpc2FibGVkQ2hhbmdlZCh0aGlzLnN0YXRlLCB1bmRlZmluZWQpO1xuICAgIHRoaXMudXBkYXRlVmlld0lmSXNGb2N1c2VkQ2hhbmdlZCh0aGlzLnN0YXRlLCB1bmRlZmluZWQpO1xuXG4gICAgY29uc3QgZGlzcGF0Y2hNYXJrQXNEaXJ0eUFjdGlvbiA9ICgpID0+IHtcbiAgICAgIGlmICh0aGlzLnN0YXRlLmlzUHJpc3RpbmUpIHtcbiAgICAgICAgdGhpcy5kaXNwYXRjaEFjdGlvbihtYXJrQXNEaXJ0eUFjdGlvbih7IGNvbnRyb2xJZDogdGhpcy5zdGF0ZS5pZCB9KSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGRpc3BhdGNoU2V0VmFsdWVBY3Rpb24gPSAoKSA9PiB7XG4gICAgICB0aGlzLnN0YXRlVmFsdWUgPSB0aGlzLm5ncnhWYWx1ZUNvbnZlcnRlci5jb252ZXJ0Vmlld1RvU3RhdGVWYWx1ZShcbiAgICAgICAgdGhpcy52aWV3VmFsdWVcbiAgICAgICk7XG4gICAgICBpZiAodGhpcy5zdGF0ZVZhbHVlICE9PSB0aGlzLnN0YXRlLnZhbHVlKSB7XG4gICAgICAgIHRoaXMuZGlzcGF0Y2hBY3Rpb24oXG4gICAgICAgICAgc2V0VmFsdWVBY3Rpb24oeyBjb250cm9sSWQ6IHRoaXMuc3RhdGUuaWQsIHZhbHVlOiB0aGlzLnN0YXRlVmFsdWUgfSlcbiAgICAgICAgKTtcblxuICAgICAgICBkaXNwYXRjaE1hcmtBc0RpcnR5QWN0aW9uKCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHRoaXMudmlld0FkYXB0ZXIuc2V0T25DaGFuZ2VDYWxsYmFjaygodmlld1ZhbHVlOiBUVmlld1ZhbHVlKSA9PiB7XG4gICAgICB0aGlzLnZpZXdWYWx1ZSA9IHZpZXdWYWx1ZTtcblxuICAgICAgaWYgKHRoaXMubmdyeFVwZGF0ZU9uID09PSBOR1JYX1VQREFURV9PTl9UWVBFLkNIQU5HRSkge1xuICAgICAgICBkaXNwYXRjaFNldFZhbHVlQWN0aW9uKCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICB0aGlzLnZpZXdBZGFwdGVyLnNldE9uVG91Y2hlZENhbGxiYWNrKCgpID0+IHtcbiAgICAgIGlmIChcbiAgICAgICAgIXRoaXMuc3RhdGUuaXNUb3VjaGVkICYmXG4gICAgICAgIHRoaXMubmdyeFVwZGF0ZU9uICE9PSBOR1JYX1VQREFURV9PTl9UWVBFLk5FVkVSXG4gICAgICApIHtcbiAgICAgICAgdGhpcy5kaXNwYXRjaEFjdGlvbihtYXJrQXNUb3VjaGVkQWN0aW9uKHsgY29udHJvbElkOiB0aGlzLnN0YXRlLmlkIH0pKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHRoaXMubmdyeFVwZGF0ZU9uID09PSBOR1JYX1VQREFURV9PTl9UWVBFLkJMVVIpIHtcbiAgICAgICAgZGlzcGF0Y2hTZXRWYWx1ZUFjdGlvbigpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIC8vIHdlIG5lZWQgdG8gdXBkYXRlIHRoZSB2aWV3IGFnYWluIGFmdGVyIGl0IHdhcyBpbml0aWFsaXplZCBzaW5jZSBzb21lXG4gICAgLy8gY29udHJvbHMgZGVwZW5kIG9uIGNoaWxkIGVsZW1lbnRzIGZvciBzZXR0aW5nIHRoZSB2YWx1ZSAoZS5nLiBzZWxlY3RzKVxuICAgIHRoaXMudmlld0FkYXB0ZXIuc2V0Vmlld1ZhbHVlKHRoaXMudmlld1ZhbHVlKTtcbiAgICBpZiAodGhpcy52aWV3QWRhcHRlci5zZXRJc0Rpc2FibGVkKSB7XG4gICAgICB0aGlzLnZpZXdBZGFwdGVyLnNldElzRGlzYWJsZWQodGhpcy5zdGF0ZS5pc0Rpc2FibGVkKTtcbiAgICB9XG4gIH1cblxuICBASG9zdExpc3RlbmVyKFwiZm9jdXNpblwiKVxuICBASG9zdExpc3RlbmVyKFwiZm9jdXNvdXRcIilcbiAgb25Gb2N1c0NoYW5nZSgpIHtcbiAgICBpZiAoIXRoaXMuZm9jdXNUcmFja2luZ0lzRW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGlzQ29udHJvbEZvY3VzZWQgPSB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQgPT09IHRoaXMuZG9tIS5hY3RpdmVFbGVtZW50O1xuICAgIGlmIChpc0NvbnRyb2xGb2N1c2VkICE9PSB0aGlzLnN0YXRlLmlzRm9jdXNlZCkge1xuICAgICAgdGhpcy5kaXNwYXRjaEFjdGlvbihcbiAgICAgICAgaXNDb250cm9sRm9jdXNlZFxuICAgICAgICAgID8gZm9jdXNBY3Rpb24oeyBjb250cm9sSWQ6IHRoaXMuc3RhdGUuaWQgfSlcbiAgICAgICAgICA6IHVuZm9jdXNBY3Rpb24oeyBjb250cm9sSWQ6IHRoaXMuc3RhdGUuaWQgfSlcbiAgICAgICk7XG4gICAgfVxuICB9XG59XG4iXX0=