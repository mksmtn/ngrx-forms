import { Directive, HostBinding, Input } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Lists the available status class names based on the property
 * they are depending on.
 */
export const NGRX_STATUS_CLASS_NAMES = {
    isValid: 'ngrx-forms-valid',
    isInvalid: 'ngrx-forms-invalid',
    isDirty: 'ngrx-forms-dirty',
    isPristine: 'ngrx-forms-pristine',
    isTouched: 'ngrx-forms-touched',
    isUntouched: 'ngrx-forms-untouched',
    isSubmitted: 'ngrx-forms-submitted',
    isUnsubmitted: 'ngrx-forms-unsubmitted',
    isValidationPending: 'ngrx-forms-validation-pending',
};
export class NgrxStatusCssClassesDirective {
    state;
    set ngrxFormControlState(state) {
        this.state = state;
    }
    set ngrxFormState(state) {
        this.state = state;
    }
    get isValid() {
        return this.state.isValid;
    }
    get isInvalid() {
        return this.state.isInvalid;
    }
    get isDirty() {
        return this.state.isDirty;
    }
    get isPristine() {
        return this.state.isPristine;
    }
    get isTouched() {
        return this.state.isTouched;
    }
    get isUntouched() {
        return this.state.isUntouched;
    }
    get isSubmitted() {
        return this.state.isSubmitted;
    }
    get isUnsubmitted() {
        return this.state.isUnsubmitted;
    }
    get isValidationPending() {
        return this.state.isValidationPending;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxStatusCssClassesDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgrxStatusCssClassesDirective, selector: "form[ngrxFormState],[ngrxFormControlState]", inputs: { ngrxFormControlState: "ngrxFormControlState", ngrxFormState: "ngrxFormState" }, host: { properties: { "class.ngrx-forms-valid": "this.isValid", "class.ngrx-forms-invalid": "this.isInvalid", "class.ngrx-forms-dirty": "this.isDirty", "class.ngrx-forms-pristine": "this.isPristine", "class.ngrx-forms-touched": "this.isTouched", "class.ngrx-forms-untouched": "this.isUntouched", "class.ngrx-forms-submitted": "this.isSubmitted", "class.ngrx-forms-unsubmitted": "this.isUnsubmitted", "class.ngrx-forms-validation-pending": "this.isValidationPending" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgrxStatusCssClassesDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line:directive-selector
                    selector: 'form[ngrxFormState],[ngrxFormControlState]',
                }]
        }], propDecorators: { ngrxFormControlState: [{
                type: Input
            }], ngrxFormState: [{
                type: Input
            }], isValid: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isValid}`]
            }], isInvalid: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isInvalid}`]
            }], isDirty: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isDirty}`]
            }], isPristine: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isPristine}`]
            }], isTouched: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isTouched}`]
            }], isUntouched: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isUntouched}`]
            }], isSubmitted: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isSubmitted}`]
            }], isUnsubmitted: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isUnsubmitted}`]
            }], isValidationPending: [{
                type: HostBinding,
                args: [`class.${NGRX_STATUS_CLASS_NAMES.isValidationPending}`]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdHVzLWNzcy1jbGFzc2VzLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9zdGF0dXMtY3NzLWNsYXNzZXMuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFHOUQ7OztHQUdHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sdUJBQXVCLEdBQUc7SUFDckMsT0FBTyxFQUFFLGtCQUFrQjtJQUMzQixTQUFTLEVBQUUsb0JBQW9CO0lBQy9CLE9BQU8sRUFBRSxrQkFBa0I7SUFDM0IsVUFBVSxFQUFFLHFCQUFxQjtJQUNqQyxTQUFTLEVBQUUsb0JBQW9CO0lBQy9CLFdBQVcsRUFBRSxzQkFBc0I7SUFDbkMsV0FBVyxFQUFFLHNCQUFzQjtJQUNuQyxhQUFhLEVBQUUsd0JBQXdCO0lBQ3ZDLG1CQUFtQixFQUFFLCtCQUErQjtDQUNyRCxDQUFDO0FBTUYsTUFBTSxPQUFPLDZCQUE2QjtJQUNoQyxLQUFLLENBQTRCO0lBRXpDLElBQ0ksb0JBQW9CLENBQUMsS0FBZ0M7UUFDdkQsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7SUFDckIsQ0FBQztJQUVELElBQ0ksYUFBYSxDQUFDLEtBQWdDO1FBQ2hELElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxJQUNJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0lBQzVCLENBQUM7SUFFRCxJQUNJLFNBQVM7UUFDWCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO0lBQzlCLENBQUM7SUFFRCxJQUNJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0lBQzVCLENBQUM7SUFFRCxJQUNJLFVBQVU7UUFDWixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO0lBQy9CLENBQUM7SUFFRCxJQUNJLFNBQVM7UUFDWCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO0lBQzlCLENBQUM7SUFFRCxJQUNJLFdBQVc7UUFDYixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO0lBQ2hDLENBQUM7SUFFRCxJQUNJLFdBQVc7UUFDYixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO0lBQ2hDLENBQUM7SUFFRCxJQUNJLGFBQWE7UUFDZixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDO0lBQ2xDLENBQUM7SUFFRCxJQUNJLG1CQUFtQjtRQUNyQixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUM7SUFDeEMsQ0FBQzt1R0F4RFUsNkJBQTZCOzJGQUE3Qiw2QkFBNkI7OzJGQUE3Qiw2QkFBNkI7a0JBSnpDLFNBQVM7bUJBQUM7b0JBQ1QsOENBQThDO29CQUM5QyxRQUFRLEVBQUUsNENBQTRDO2lCQUN2RDs4QkFLSyxvQkFBb0I7c0JBRHZCLEtBQUs7Z0JBTUYsYUFBYTtzQkFEaEIsS0FBSztnQkFNRixPQUFPO3NCQURWLFdBQVc7dUJBQUMsU0FBUyx1QkFBdUIsQ0FBQyxPQUFPLEVBQUU7Z0JBTW5ELFNBQVM7c0JBRFosV0FBVzt1QkFBQyxTQUFTLHVCQUF1QixDQUFDLFNBQVMsRUFBRTtnQkFNckQsT0FBTztzQkFEVixXQUFXO3VCQUFDLFNBQVMsdUJBQXVCLENBQUMsT0FBTyxFQUFFO2dCQU1uRCxVQUFVO3NCQURiLFdBQVc7dUJBQUMsU0FBUyx1QkFBdUIsQ0FBQyxVQUFVLEVBQUU7Z0JBTXRELFNBQVM7c0JBRFosV0FBVzt1QkFBQyxTQUFTLHVCQUF1QixDQUFDLFNBQVMsRUFBRTtnQkFNckQsV0FBVztzQkFEZCxXQUFXO3VCQUFDLFNBQVMsdUJBQXVCLENBQUMsV0FBVyxFQUFFO2dCQU12RCxXQUFXO3NCQURkLFdBQVc7dUJBQUMsU0FBUyx1QkFBdUIsQ0FBQyxXQUFXLEVBQUU7Z0JBTXZELGFBQWE7c0JBRGhCLFdBQVc7dUJBQUMsU0FBUyx1QkFBdUIsQ0FBQyxhQUFhLEVBQUU7Z0JBTXpELG1CQUFtQjtzQkFEdEIsV0FBVzt1QkFBQyxTQUFTLHVCQUF1QixDQUFDLG1CQUFtQixFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBIb3N0QmluZGluZywgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFic3RyYWN0Q29udHJvbFN0YXRlIH0gZnJvbSAnLi9zdGF0ZSc7XG5cbi8qKlxuICogTGlzdHMgdGhlIGF2YWlsYWJsZSBzdGF0dXMgY2xhc3MgbmFtZXMgYmFzZWQgb24gdGhlIHByb3BlcnR5XG4gKiB0aGV5IGFyZSBkZXBlbmRpbmcgb24uXG4gKi9cbmV4cG9ydCBjb25zdCBOR1JYX1NUQVRVU19DTEFTU19OQU1FUyA9IHtcbiAgaXNWYWxpZDogJ25ncngtZm9ybXMtdmFsaWQnLFxuICBpc0ludmFsaWQ6ICduZ3J4LWZvcm1zLWludmFsaWQnLFxuICBpc0RpcnR5OiAnbmdyeC1mb3Jtcy1kaXJ0eScsXG4gIGlzUHJpc3RpbmU6ICduZ3J4LWZvcm1zLXByaXN0aW5lJyxcbiAgaXNUb3VjaGVkOiAnbmdyeC1mb3Jtcy10b3VjaGVkJyxcbiAgaXNVbnRvdWNoZWQ6ICduZ3J4LWZvcm1zLXVudG91Y2hlZCcsXG4gIGlzU3VibWl0dGVkOiAnbmdyeC1mb3Jtcy1zdWJtaXR0ZWQnLFxuICBpc1Vuc3VibWl0dGVkOiAnbmdyeC1mb3Jtcy11bnN1Ym1pdHRlZCcsXG4gIGlzVmFsaWRhdGlvblBlbmRpbmc6ICduZ3J4LWZvcm1zLXZhbGlkYXRpb24tcGVuZGluZycsXG59O1xuXG5ARGlyZWN0aXZlKHtcbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOmRpcmVjdGl2ZS1zZWxlY3RvclxuICBzZWxlY3RvcjogJ2Zvcm1bbmdyeEZvcm1TdGF0ZV0sW25ncnhGb3JtQ29udHJvbFN0YXRlXScsXG59KVxuZXhwb3J0IGNsYXNzIE5ncnhTdGF0dXNDc3NDbGFzc2VzRGlyZWN0aXZlIHtcbiAgcHJpdmF0ZSBzdGF0ZTogQWJzdHJhY3RDb250cm9sU3RhdGU8YW55PjtcblxuICBASW5wdXQoKVxuICBzZXQgbmdyeEZvcm1Db250cm9sU3RhdGUoc3RhdGU6IEFic3RyYWN0Q29udHJvbFN0YXRlPGFueT4pIHtcbiAgICB0aGlzLnN0YXRlID0gc3RhdGU7XG4gIH1cblxuICBASW5wdXQoKVxuICBzZXQgbmdyeEZvcm1TdGF0ZShzdGF0ZTogQWJzdHJhY3RDb250cm9sU3RhdGU8YW55Pikge1xuICAgIHRoaXMuc3RhdGUgPSBzdGF0ZTtcbiAgfVxuXG4gIEBIb3N0QmluZGluZyhgY2xhc3MuJHtOR1JYX1NUQVRVU19DTEFTU19OQU1FUy5pc1ZhbGlkfWApXG4gIGdldCBpc1ZhbGlkKCkge1xuICAgIHJldHVybiB0aGlzLnN0YXRlLmlzVmFsaWQ7XG4gIH1cblxuICBASG9zdEJpbmRpbmcoYGNsYXNzLiR7TkdSWF9TVEFUVVNfQ0xBU1NfTkFNRVMuaXNJbnZhbGlkfWApXG4gIGdldCBpc0ludmFsaWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGUuaXNJbnZhbGlkO1xuICB9XG5cbiAgQEhvc3RCaW5kaW5nKGBjbGFzcy4ke05HUlhfU1RBVFVTX0NMQVNTX05BTUVTLmlzRGlydHl9YClcbiAgZ2V0IGlzRGlydHkoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGUuaXNEaXJ0eTtcbiAgfVxuXG4gIEBIb3N0QmluZGluZyhgY2xhc3MuJHtOR1JYX1NUQVRVU19DTEFTU19OQU1FUy5pc1ByaXN0aW5lfWApXG4gIGdldCBpc1ByaXN0aW5lKCkge1xuICAgIHJldHVybiB0aGlzLnN0YXRlLmlzUHJpc3RpbmU7XG4gIH1cblxuICBASG9zdEJpbmRpbmcoYGNsYXNzLiR7TkdSWF9TVEFUVVNfQ0xBU1NfTkFNRVMuaXNUb3VjaGVkfWApXG4gIGdldCBpc1RvdWNoZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGUuaXNUb3VjaGVkO1xuICB9XG5cbiAgQEhvc3RCaW5kaW5nKGBjbGFzcy4ke05HUlhfU1RBVFVTX0NMQVNTX05BTUVTLmlzVW50b3VjaGVkfWApXG4gIGdldCBpc1VudG91Y2hlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZS5pc1VudG91Y2hlZDtcbiAgfVxuXG4gIEBIb3N0QmluZGluZyhgY2xhc3MuJHtOR1JYX1NUQVRVU19DTEFTU19OQU1FUy5pc1N1Ym1pdHRlZH1gKVxuICBnZXQgaXNTdWJtaXR0ZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGUuaXNTdWJtaXR0ZWQ7XG4gIH1cblxuICBASG9zdEJpbmRpbmcoYGNsYXNzLiR7TkdSWF9TVEFUVVNfQ0xBU1NfTkFNRVMuaXNVbnN1Ym1pdHRlZH1gKVxuICBnZXQgaXNVbnN1Ym1pdHRlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZS5pc1Vuc3VibWl0dGVkO1xuICB9XG5cbiAgQEhvc3RCaW5kaW5nKGBjbGFzcy4ke05HUlhfU1RBVFVTX0NMQVNTX05BTUVTLmlzVmFsaWRhdGlvblBlbmRpbmd9YClcbiAgZ2V0IGlzVmFsaWRhdGlvblBlbmRpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGUuaXNWYWxpZGF0aW9uUGVuZGluZztcbiAgfVxufVxuIl19